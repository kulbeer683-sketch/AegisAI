# Aegis AI — Next-Gen Autonomous Android Assistant

**Version:** 1.0.0 · **Target SDK:** 35 · **Min SDK:** 26 · **Kotlin + Jetpack Compose**
**Builds and runs entirely on-device via Termux.**

Aegis is an offline-first Android assistant built across 30 days. This archive is the production master, produced on the phone that built it.

## Quick Start

```bash
termux-setup-storage
pkg install -y git unzip zip curl wget
unzip /sdcard/AegisAI/AegisAI_v1.0_Production_Master.zip -d ~/aegis
cd ~/aegis/AegisAI
chmod +x scripts/*.sh
./scripts/setup_mobile_env.sh
./scripts/deploy_aegis.sh --full
