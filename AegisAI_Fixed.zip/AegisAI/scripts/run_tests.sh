#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

GRADLE_HEAP="${AEGIS_TEST_HEAP:-1536m}"
aegis_require_project

cd "${AEGIS_PROJECT}"
pkill -f GradleDaemon 2>/dev/null || true

set +e
./gradlew --no-daemon --console=plain --continue \
    -Dorg.gradle.jvmargs=-Xmx${GRADLE_HEAP} \
    -Dorg.gradle.workers.max=1 \
    -Dkotlin.daemon.jvmargs=-Xmx768m \
    testDebugUnitTest
rc=$?
set -e

results="${AEGIS_PROJECT}/app/build/test-results/testDebugUnitTest"
if [ ! -d "${results}" ]; then
    echo "[aegis] No test results"; exit ${rc}
fi

total=0; failed=0; skipped=0
for xml in $(find "${results}" -name "*.xml" -type f 2>/dev/null | sort); do
    line=$(grep -m1 "<testsuite " "${xml}" || true)
    [ -z "${line}" ] && continue
    t=$(echo "${line}" | sed -n 's/.*tests="\([0-9]*\)".*/\1/p'); t=${t:-0}
    f=$(echo "${line}" | sed -n 's/.*failures="\([0-9]*\)".*/\1/p'); f=${f:-0}
    e=$(echo "${line}" | sed -n 's/.*errors="\([0-9]*\)".*/\1/p'); e=${e:-0}
    s=$(echo "${line}" | sed -n 's/.*skipped="\([0-9]*\)".*/\1/p'); s=${s:-0}
    total=$(( total + t )); failed=$(( failed + f + e )); skipped=$(( skipped + s ))
done

echo ""
echo "  Tests:   ${total}"
echo "  Passed:  $(( total - failed - skipped ))"
echo "  Failed:  ${failed}"
echo "  Skipped: ${skipped}"

[ ${failed} -eq 0 ] && exit 0 || exit 1
