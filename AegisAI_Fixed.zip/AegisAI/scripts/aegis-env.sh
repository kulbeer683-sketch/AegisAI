#!/data/data/com.termux/files/usr/bin/bash
# Shared configuration for all Aegis build scripts.
if [ -n "${AEGIS_ENV_LOADED:-}" ]; then return 0; fi
AEGIS_ENV_LOADED=1

export TERMUX_PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
export AEGIS_HOME="${HOME}/aegis"
export AEGIS_PROJECT="${AEGIS_HOME}/AegisAI"
export AEGIS_TOOLS="${AEGIS_HOME}/tools"
export ANDROID_SDK_ROOT="${AEGIS_TOOLS}/android-sdk"
export ANDROID_HOME="${ANDROID_SDK_ROOT}"
export ANDROID_USER_HOME="${AEGIS_HOME}/.android"
export GRADLE_USER_HOME="${AEGIS_HOME}/.gradle"

export CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
export CMDLINE_TOOLS_ZIP="${AEGIS_TOOLS}/cmdline-tools.zip"
export BUILD_TOOLS_VERSION="35.0.0"
export PLATFORM_VERSION="android-35"

export AEGIS_OUTPUT_DIR="${AEGIS_PROJECT}/app/build/outputs/apk"
export AEGIS_DEPLOY_DIR="/sdcard/AegisAI"
export AEGIS_APK_DEBUG="${AEGIS_OUTPUT_DIR}/debug/app-debug.apk"
export AEGIS_APK_RELEASE_UNSIGNED="${AEGIS_OUTPUT_DIR}/release/app-release-unsigned.apk"
export AEGIS_APK_RELEASE_SIGNED="${AEGIS_OUTPUT_DIR}/release/app-release-signed.apk"

export AEGIS_KEYSTORE_DIR="${AEGIS_HOME}/keystore"
export AEGIS_KEYSTORE_FILE="${AEGIS_KEYSTORE_DIR}/aegis-release.jks"
export AEGIS_KEYSTORE_ALIAS="aegis-release"
export AEGIS_KEYSTORE_VALIDITY_DAYS="10950"

if [ -x "${TERMUX_PREFIX}/bin/java" ]; then
    export JAVA_HOME="${TERMUX_PREFIX}/lib/jvm/java-17-openjdk"
fi
export PATH="${JAVA_HOME:+${JAVA_HOME}/bin:}${PATH}"

export AAPT2_BIN="${TERMUX_PREFIX}/bin/aapt2"
export APKSIGNER_BIN="${TERMUX_PREFIX}/bin/apksigner"
export ZIPALIGN_BIN="${TERMUX_PREFIX}/bin/zipalign"
export D8_BIN="${TERMUX_PREFIX}/bin/d8"

if [ -t 1 ]; then
    C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'
    C_RED=$'\033[31m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'
    C_BLUE=$'\033[34m'; C_CYAN=$'\033[36m'
else
    C_RESET=""; C_BOLD=""; C_DIM=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_BLUE=""; C_CYAN=""
fi

log()      { printf '%s[aegis]%s %s\n' "${C_CYAN}" "${C_RESET}" "$*"; }
log_ok()   { printf '%s[ ok ]%s %s\n' "${C_GREEN}" "${C_RESET}" "$*"; }
log_warn() { printf '%s[warn]%s %s\n' "${C_YELLOW}" "${C_RESET}" "$*" >&2; }
log_err()  { printf '%s[fail]%s %s\n' "${C_RED}" "${C_RESET}" "$*" >&2; }
log_step() { printf '\n%s%s==> %s%s\n' "${C_BOLD}" "${C_BLUE}" "$*" "${C_RESET}"; }
die() { log_err "$*"; exit 1; }

aegis_require_project() {
    [ -d "${AEGIS_PROJECT}" ] || die "Project not found: ${AEGIS_PROJECT}"
    [ -f "${AEGIS_PROJECT}/settings.gradle.kts" ] || die "Not a Gradle project"
    [ -f "${AEGIS_PROJECT}/app/build.gradle.kts" ] || die "Module build file missing"
}

aegis_ensure_deploy_dir() {
    [ -d "/sdcard" ] || { log_warn "/sdcard not accessible"; return 1; }
    mkdir -p "${AEGIS_DEPLOY_DIR}" 2>/dev/null || return 1
    return 0
}
