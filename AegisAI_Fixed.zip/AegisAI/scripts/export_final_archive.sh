#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

VERSION="v1.0"
NAME="AegisAI_${VERSION}_Production_Master"
ARCHIVE="${AEGIS_DEPLOY_DIR}/${NAME}.zip"

aegis_require_project
aegis_ensure_deploy_dir || die "Cannot write to ${AEGIS_DEPLOY_DIR}"

STAGING=$(mktemp -d)
trap 'rm -rf "${STAGING}"' EXIT

EXCLUDE=$(mktemp)
cat > "${EXCLUDE}" <<'EXCL'
build/
app/build/
.gradle/
.idea/
*.iml
local.properties
keystore/
*.jks
*.apk
*.aab
*.dex
*.class
app/schemas/
EXCL

DEST="${STAGING}/AegisAI"
mkdir -p "${DEST}"
( cd "${AEGIS_PROJECT}" && tar --exclude-from="${EXCLUDE}" -cf - . ) | ( cd "${DEST}" && tar -xf - )
rm -f "${EXCLUDE}"
chmod +x "${DEST}/scripts/"*.sh 2>/dev/null || true

# Checksums
if command -v sha256sum >/dev/null 2>&1; then
    ( cd "${DEST}" && find . -type f \( -name '*.kt' -o -name '*.kts' -o -name '*.xml' -o -name '*.sh' \) -print0 \
        | sort -z | xargs -0 sha256sum > MANIFEST.sha256 2>/dev/null || true )
fi

# Manifest
{
    echo "Aegis AI — Production Master Archive"
    echo "Version: ${VERSION}"
    echo "Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "Device: $(getprop ro.product.model 2>/dev/null || echo unknown)"
    echo "Android: $(getprop ro.build.version.release 2>/dev/null || echo unknown)"
    echo "Kotlin files: $(find "${DEST}" -name '*.kt' | wc -l | tr -d ' ')"
    echo "Total files: $(find "${DEST}" -type f | wc -l | tr -d ' ')"
    echo ""
    echo "To build: see README.md"
} > "${STAGING}/MANIFEST.txt"

[ -f "${AEGIS_PROJECT}/README.md" ] && cp "${AEGIS_PROJECT}/README.md" "${DEST}/README.md"

rm -f "${ARCHIVE}"
( cd "${STAGING}" && zip -r -q -9 "${ARCHIVE}" AegisAI MANIFEST.txt )
sha256sum "${ARCHIVE}" > "${ARCHIVE}.sha256" 2>/dev/null || true

echo "[aegis] Archive: ${ARCHIVE} ($(du -h "${ARCHIVE}" | cut -f1))"
echo "[aegis] Checksum: ${ARCHIVE}.sha256"
