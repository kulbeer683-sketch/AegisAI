#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

VARIANT="debug"
SKIP_TESTS=0
SKIP_INSTALL=0
LAUNCH=0

for a in "$@"; do
    case "$a" in
        --release) VARIANT="release" ;;
        --skip-tests) SKIP_TESTS=1 ;;
        --no-install) SKIP_INSTALL=1 ;;
        --launch) LAUNCH=1 ;;
        --full) VARIANT="release"; LAUNCH=1 ;;
    esac
done

aegis_require_project

echo "===> Step 1/6 — Pre-flight"
for t in java curl unzip zip; do command -v "$t" >/dev/null || die "Missing: $t"; done
aegis_ensure_deploy_dir

if [ ${SKIP_TESTS} -eq 0 ]; then
    echo "===> Step 2/6 — Tests"
    "${SCRIPT_DIR}/run_tests.sh" || die "Tests failed"
fi

echo "===> Step 3/6 — Build"
"${SCRIPT_DIR}/build_apk.sh" "${VARIANT}" || die "Build failed"

APK="${AEGIS_APK_DEBUG}"
if [ "${VARIANT}" = "release" ]; then
    echo "===> Step 4/6 — Sign"
    "${SCRIPT_DIR}/sign_apk.sh" sign || die "Signing failed"
    APK="${AEGIS_APK_RELEASE_SIGNED}"
fi

if [ ${SKIP_INSTALL} -eq 0 ]; then
    echo "===> Step 5/6 — Install"
    STAGED="${AEGIS_DEPLOY_DIR}/$(basename "${APK}")"
    [ "${APK}" != "${STAGED}" ] && cp -f "${APK}" "${STAGED}"
    if command -v pm >/dev/null 2>&1; then
        pm install -r "${STAGED}" && echo "[aegis] Installed via pm"
    elif command -v adb >/dev/null 2>&1; then
        adb install -r "${STAGED}" && echo "[aegis] Installed via adb"
    elif command -v termux-open >/dev/null 2>&1; then
        termux-open --content-type application/vnd.android.package-archive "${STAGED}"
        echo "[aegis] Installer opened"
        read -r -p "Press Enter once installed... " _
    else
        die "No install method available"
    fi
fi

if [ ${LAUNCH} -eq 1 ] && command -v am >/dev/null 2>&1; then
    echo "===> Step 6/6 — Launch"
    am start -n "com.aegis.ai/com.aegis.ai.MainActivity" || true
fi

echo "[aegis] Deployment complete."
