#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

ACTION="${1:-sign}"

find_tool() {
    for c in "$@"; do [ -x "${c}" ] && { echo "${c}"; return 0; }; done
    return 1
}

create_keystore() {
    mkdir -p "${AEGIS_KEYSTORE_DIR}"
    command -v keytool >/dev/null || die "keytool missing"
    [ -f "${AEGIS_KEYSTORE_FILE}" ] && { echo "Exists: ${AEGIS_KEYSTORE_FILE}"; return 0; }
    printf 'Keystore password: '; read -rs KS; echo
    printf 'Key password (Enter for same): '; read -rs KP; echo
    [ -z "${KP}" ] && KP="${KS}"
    printf 'Common Name [Aegis AI]: '; read -r CN; [ -z "${CN}" ] && CN="Aegis AI"
    keytool -genkeypair -v -keystore "${AEGIS_KEYSTORE_FILE}" -alias "${AEGIS_KEYSTORE_ALIAS}" \
        -keyalg RSA -keysize 4096 -validity "${AEGIS_KEYSTORE_VALIDITY_DAYS}" \
        -storepass "${KS}" -keypass "${KP}" \
        -dname "CN=${CN}, OU=Personal, O=Aegis, L=Unknown, ST=Unknown, C=IN"
    chmod 600 "${AEGIS_KEYSTORE_FILE}"
    echo "[aegis] Keystore created: ${AEGIS_KEYSTORE_FILE}"
    unset KS KP
}

sign_release() {
    [ -f "${AEGIS_APK_RELEASE_UNSIGNED}" ] || die "Unsigned APK missing. Run build_apk.sh release first."
    [ -f "${AEGIS_KEYSTORE_FILE}" ] || { echo "No keystore — running create…"; create_keystore; }

    AS=$(find_tool "${APKSIGNER_BIN}" "${ANDROID_SDK_ROOT}/build-tools/${BUILD_TOOLS_VERSION}/apksigner") || die "apksigner missing"
    ZA=$(find_tool "${ZIPALIGN_BIN}" "${ANDROID_SDK_ROOT}/build-tools/${BUILD_TOOLS_VERSION}/zipalign") || true

    printf 'Keystore password: '; read -rs KS; echo
    printf 'Key password (Enter for same): '; read -rs KP; echo
    [ -z "${KP}" ] && KP="${KS}"

    ALIGNED="${AEGIS_OUTPUT_DIR}/release/app-release-aligned.apk"
    if [ -n "${ZA}" ]; then
        "${ZA}" -f -p 4 "${AEGIS_APK_RELEASE_UNSIGNED}" "${ALIGNED}"
    else
        ALIGNED="${AEGIS_APK_RELEASE_UNSIGNED}"
    fi

    "${AS}" sign --ks "${AEGIS_KEYSTORE_FILE}" --ks-key-alias "${AEGIS_KEYSTORE_ALIAS}" \
        --ks-pass "pass:${KS}" --key-pass "pass:${KP}" \
        --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
        --out "${AEGIS_APK_RELEASE_SIGNED}" "${ALIGNED}"

    echo "[aegis] Signed: ${AEGIS_APK_RELEASE_SIGNED}"
    "${AS}" verify --verbose "${AEGIS_APK_RELEASE_SIGNED}" || true
    aegis_ensure_deploy_dir && cp -f "${AEGIS_APK_RELEASE_SIGNED}" "${AEGIS_DEPLOY_DIR}/aegis-release-signed.apk" 2>/dev/null || true
    unset KS KP
}

case "${ACTION}" in
    keystore) create_keystore ;;
    sign) sign_release ;;
    *) echo "Usage: $0 {keystore|sign}" >&2; exit 2 ;;
esac
