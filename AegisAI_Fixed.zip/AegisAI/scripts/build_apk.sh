#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

GRADLE_HEAP="${AEGIS_GRADLE_HEAP:-1536m}"
TASK="${1:-debug}"

aegis_require_project
mkdir -p "${ANDROID_USER_HOME}"
[ -f "${ANDROID_USER_HOME}/repositories.cfg" ] || touch "${ANDROID_USER_HOME}/repositories.cfg"

cd "${AEGIS_PROJECT}"
pkill -f GradleDaemon 2>/dev/null || true
pkill -f KotlinCompileDaemon 2>/dev/null || true

OPTS=(
    "--no-daemon"
    "--console=plain"
    "--stacktrace"
    "-Dorg.gradle.jvmargs=-Xmx${GRADLE_HEAP} -XX:MaxMetaspaceSize=384m"
    "-Dorg.gradle.workers.max=1"
    "-Dorg.gradle.parallel=false"
    "-Dorg.gradle.configuration-cache=false"
    "-Dkotlin.daemon.jvmargs=-Xmx768m"
)

case "${TASK}" in
    debug)
        ./gradlew "${OPTS[@]}" assembleDebug
        APK="${AEGIS_APK_DEBUG}"
        ;;
    release)
        ./gradlew "${OPTS[@]}" assembleRelease
        APK="${AEGIS_APK_RELEASE_UNSIGNED}"
        ;;
    both)
        ./gradlew "${OPTS[@]}" assembleDebug assembleRelease
        APK="${AEGIS_APK_DEBUG}"
        ;;
    clean)
        ./gradlew "${OPTS[@]}" clean || true
        rm -rf app/build .gradle 2>/dev/null || true
        echo "[aegis] Clean complete"
        exit 0
        ;;
    *)
        echo "Usage: $0 {debug|release|both|clean}" >&2
        exit 2
        ;;
esac

if [ -f "${APK}" ]; then
    sz=$(du -h "${APK}" | cut -f1)
    echo "[aegis] APK: ${APK} (${sz})"
    aegis_ensure_deploy_dir && cp -f "${APK}" "${AEGIS_DEPLOY_DIR}/" 2>/dev/null && echo "[aegis] Deployed to ${AEGIS_DEPLOY_DIR}/"
else
    echo "[aegis] APK not found at ${APK}" >&2
    exit 1
fi
