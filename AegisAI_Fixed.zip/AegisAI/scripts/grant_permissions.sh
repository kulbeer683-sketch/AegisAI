#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

PKG="com.aegis.ai"
METHOD="${2:-auto}"
[ "${1:-}" = "--method" ] && METHOD="${2:-auto}"

if [ "${METHOD}" = "auto" ]; then
    if command -v adb >/dev/null 2>&1 && adb get-state 2>/dev/null | grep -q device; then
        METHOD="adb"
    elif command -v rish >/dev/null 2>&1; then
        METHOD="rish"
    elif command -v su >/dev/null 2>&1 && su -c id 2>/dev/null | grep -q uid=0; then
        METHOD="root"
    else
        die "No backend. Enable Wireless Debugging + adb connect localhost:PORT"
    fi
fi

run() {
    case "${METHOD}" in
        adb) adb shell "$@" ;;
        rish) rish -c "$*" ;;
        root) su -c "$*" ;;
    esac
}

echo "[aegis] Runtime permissions…"
for p in RECORD_AUDIO MODIFY_AUDIO_SETTINGS READ_PHONE_STATE READ_CONTACTS \
         ANSWER_PHONE_CALLS CAMERA ACCESS_FINE_LOCATION ACCESS_COARSE_LOCATION \
         BLUETOOTH_CONNECT POST_NOTIFICATIONS ACCESS_BACKGROUND_LOCATION; do
    run "pm grant ${PKG} android.permission.${p}" >/dev/null 2>&1 || true
done

echo "[aegis] Overlay + Write Settings…"
run "appops set ${PKG} SYSTEM_ALERT_WINDOW allow" 2>/dev/null || true
run "appops set ${PKG} WRITE_SETTINGS allow" 2>/dev/null || true

echo "[aegis] Battery exemption…"
run "dumpsys deviceidle whitelist +${PKG}" 2>/dev/null || true

echo "[aegis] Accessibility service…"
CURRENT=$(run "settings get secure enabled_accessibility_services" 2>/dev/null | tr -d '\r')
CURRENT="${CURRENT//null/}"
COMP="${PKG}/com.aegis.ai.service.AegisAccessibilityService"
if ! echo "${CURRENT}" | grep -q "${COMP}"; then
    NEW="${CURRENT:+${CURRENT}:}${COMP}"
    run "settings put secure enabled_accessibility_services '${NEW}'" 2>/dev/null || true
    run "settings put secure accessibility_enabled 1" 2>/dev/null || true
fi

echo "[aegis] Notification listener…"
CURRENT=$(run "settings get secure enabled_notification_listeners" 2>/dev/null | tr -d '\r')
CURRENT="${CURRENT//null/}"
COMP2="${PKG}/com.aegis.ai.notifications.SmartNotificationListener"
if ! echo "${CURRENT}" | grep -q "${COMP2}"; then
    NEW="${CURRENT:+${CURRENT}:}${COMP2}"
    run "settings put secure enabled_notification_listeners '${NEW}'" 2>/dev/null || true
fi

echo "[aegis] Done. Backend: ${METHOD}"
