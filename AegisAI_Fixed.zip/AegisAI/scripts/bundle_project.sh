#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

aegis_require_project
aegis_ensure_deploy_dir || die "Cannot write to ${AEGIS_DEPLOY_DIR}"

TS=$(date +%Y%m%d_%H%M%S)
ARCHIVE="${AEGIS_DEPLOY_DIR}/AegisAI_Project_Source_${TS}.zip"
STABLE="${AEGIS_DEPLOY_DIR}/AegisAI_Project_Source.zip"

STAGING=$(mktemp -d)
trap 'rm -rf "${STAGING}"' EXIT

EXCLUDE=$(mktemp)
cat > "${EXCLUDE}" <<'EXCL'
build/
app/build/
.gradle/
.idea/
*.iml
local.properties
keystore/
*.jks
*.apk
*.aab
*.dex
*.class
EXCL

DEST="${STAGING}/AegisAI"
mkdir -p "${DEST}"

( cd "${AEGIS_PROJECT}" && tar --exclude-from="${EXCLUDE}" -cf - . ) | ( cd "${DEST}" && tar -xf - )
rm -f "${EXCLUDE}"
chmod +x "${DEST}/scripts/"*.sh 2>/dev/null || true

( cd "${STAGING}" && zip -r -q -9 "${ARCHIVE}" AegisAI )
cp -f "${ARCHIVE}" "${STABLE}"

echo "[aegis] Archive: ${ARCHIVE} ($(du -h "${ARCHIVE}" | cut -f1))"
echo "[aegis] Stable:  ${STABLE}"
