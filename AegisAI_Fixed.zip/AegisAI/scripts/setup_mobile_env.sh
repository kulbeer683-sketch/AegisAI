#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/aegis-env.sh"

echo "[aegis] Installing Termux packages…"
pkg update -y >/dev/null 2>&1 || true
yes | pkg install -y openjdk-17 aapt2 apksigner zipalign dx unzip zip curl git openssl termux-api 2>/dev/null || true

mkdir -p "${AEGIS_TOOLS}" "${ANDROID_SDK_ROOT}/cmdline-tools"

if [ ! -x "${ANDROID_SDK_ROOT}/cmdline-tools/latest/bin/sdkmanager" ]; then
    echo "[aegis] Downloading command-line tools…"
    curl -fL --retry 3 -o "${CMDLINE_TOOLS_ZIP}" "${CMDLINE_TOOLS_URL}" || die "Download failed"
    tmp="$(mktemp -d)"
    unzip -q -o "${CMDLINE_TOOLS_ZIP}" -d "${tmp}"
    rm -rf "${ANDROID_SDK_ROOT}/cmdline-tools/latest"
    mv "${tmp}/cmdline-tools" "${ANDROID_SDK_ROOT}/cmdline-tools/latest"
    rm -rf "${tmp}" "${CMDLINE_TOOLS_ZIP}"
    chmod +x "${ANDROID_SDK_ROOT}/cmdline-tools/latest/bin/"* 2>/dev/null || true
fi

sdkmanager="${ANDROID_SDK_ROOT}/cmdline-tools/latest/bin/sdkmanager"
mkdir -p "${ANDROID_USER_HOME}"
[ -f "${ANDROID_USER_HOME}/repositories.cfg" ] || touch "${ANDROID_USER_HOME}/repositories.cfg"

echo "[aegis] Accepting SDK licences…"
yes | "${sdkmanager}" --sdk_root="${ANDROID_SDK_ROOT}" --licenses >/dev/null 2>&1 || true
"${sdkmanager}" --sdk_root="${ANDROID_SDK_ROOT}" "platform-tools" "platforms;${PLATFORM_VERSION}" "build-tools;${BUILD_TOOLS_VERSION}" || die "SDK install failed"

if [ -x "${AAPT2_BIN}" ]; then
    sdk_aapt2_dir="${ANDROID_SDK_ROOT}/build-tools/${BUILD_TOOLS_VERSION}"
    mkdir -p "${sdk_aapt2_dir}"
    [ -f "${sdk_aapt2_dir}/aapt2" ] && [ ! -L "${sdk_aapt2_dir}/aapt2" ] && mv "${sdk_aapt2_dir}/aapt2" "${sdk_aapt2_dir}/aapt2.x86_64.orig" 2>/dev/null || true
    ln -sf "${AAPT2_BIN}" "${sdk_aapt2_dir}/aapt2"
fi

local_props="${AEGIS_PROJECT}/local.properties"
echo "sdk.dir=${ANDROID_SDK_ROOT}" > "${local_props}"

gradle_props="${AEGIS_PROJECT}/gradle.properties"
if ! grep -q "android.aapt2FromMavenOverride" "${gradle_props}" 2>/dev/null; then
    echo "" >> "${gradle_props}"
    echo "android.aapt2FromMavenOverride=${AAPT2_BIN}" >> "${gradle_props}"
fi

echo "[aegis] Validating…"
java -version 2>&1 | head -n1
[ -x "${AAPT2_BIN}" ] && "${AAPT2_BIN}" version 2>&1 | head -n1
echo "[aegis] Environment ready. Next: ./scripts/build_apk.sh debug"
