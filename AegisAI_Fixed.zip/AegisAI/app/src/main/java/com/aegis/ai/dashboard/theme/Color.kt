package com.aegis.ai.dashboard.theme

import androidx.compose.ui.graphics.Color

object AegisPalette {
    val Black = Color(0xFF000000)
    val Surface = Color(0xFF0A0D12)
    val SurfaceElevated = Color(0xFF131A22)
    val SurfaceOutline = Color(0xFF1E2732)
    val Accent = Color(0xFF2FE6A8)
    val AccentDim = Color(0xFF1B8F69)
    val AccentFaint = Color(0x332FE6A8)
    val TextPrimary = Color(0xFFE7EEF5)
    val TextSecondary = Color(0xFF8A9AAB)
    val TextTertiary = Color(0xFF5A6A7B)
    val Success = Color(0xFF2FE6A8)
    val Warning = Color(0xFFF2A03D)
    val Danger = Color(0xFFE5484D)
    val Info = Color(0xFF4A9EFF)
}
