package com.aegis.ai.vision

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

class CameraVisionEngine(
    context: Context,
    private val powerCoordinator: com.aegis.ai.power.PowerBudgetCoordinator? = null
) {

    private val appContext = context.applicationContext
    private val cameraManager = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val mutex = Mutex()

    data class CaptureResult(val jpegBytes: ByteArray, val width: Int, val height: Int, val capturedAtMs: Long) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is CaptureResult) return false
            return jpegBytes.contentEquals(other.jpegBytes) && width == other.width
        }
        override fun hashCode(): Int = jpegBytes.contentHashCode()
    }

    sealed class CaptureError {
        data object NoPermission : CaptureError()
        data object NoRearCamera : CaptureError()
        data object CameraBusy : CaptureError()
        data object CameraUnavailable : CaptureError()
        data class Timeout(val ms: Long) : CaptureError()
        data class CameraOpenFailed(val code: Int, val message: String?) : CaptureError()
        data class SessionFailed(val code: Int, val message: String?) : CaptureError()
        data class CaptureFailed(val message: String) : CaptureError()
        data class Internal(val message: String) : CaptureError()
    }

    sealed class Outcome {
        data class Success(val result: CaptureResult) : Outcome()
        data class Failure(val error: CaptureError) : Outcome()
    }

    fun hasPermission(): Boolean = ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    suspend fun captureSingleFrame(
        targetMaxWidth: Int = 1280,
        jpegQuality: Int = 82,
        timeoutMs: Long = 4_000L
    ): Outcome = mutex.withLock {
        if (powerCoordinator?.allowsCapability(com.aegis.ai.power.PowerBudgetCoordinator.Capability.CAMERA_VISION) == false) {
            return@withLock Outcome.Failure(CaptureError.Internal("power_critical"))
        }
        if (!hasPermission()) return@withLock Outcome.Failure(CaptureError.NoPermission)
        val camId = findRearCameraId() ?: return@withLock Outcome.Failure(CaptureError.NoRearCamera)
        try {
            withTimeoutOrNull(timeoutMs) { performCapture(camId, targetMaxWidth, jpegQuality) }
                ?: Outcome.Failure(CaptureError.Timeout(timeoutMs))
        } catch (ce: CancellationException) { throw ce }
        catch (t: Throwable) { Outcome.Failure(CaptureError.Internal(t.message ?: "unknown")) }
    }

    private suspend fun performCapture(camId: String, targetMaxWidth: Int, jpegQuality: Int): Outcome = withContext(Dispatchers.IO) {
        val chars = try { cameraManager.getCameraCharacteristics(camId) } catch (t: Throwable) { return@withContext Outcome.Failure(CaptureError.Internal("chars")) }
        val configMap = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?: return@withContext Outcome.Failure(CaptureError.CameraUnavailable)
        val sizes = runCatching { configMap.getOutputSizes(ImageFormat.JPEG) }.getOrNull()
            ?: return@withContext Outcome.Failure(CaptureError.CameraUnavailable)
        val chosen = chooseBestSize(sizes, targetMaxWidth)
        val sensor = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val jpegOrientation = (sensor - displayRotation() + 360) % 360

        val ht = HandlerThread("aegis-camera").apply { start() }
        val bh = Handler(ht.looper)

        val reader = try { ImageReader.newInstance(chosen.width, chosen.height, ImageFormat.JPEG, 2) }
        catch (t: Throwable) { ht.quitSafely(); return@withContext Outcome.Failure(CaptureError.Internal("reader")) }

        val deviceDef = CompletableDeferred<CameraDevice>()
        val sessionDef = CompletableDeferred<CameraCaptureSession>()
        val imgDef = CompletableDeferred<Image>()
        val accepting = AtomicBoolean(false)
        val deviceHolder = arrayOfNulls<CameraDevice>(1)
        val sessionHolder = arrayOfNulls<CameraCaptureSession>(1)

        val openCb = object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { deviceHolder[0] = d; if (!deviceDef.isCompleted) deviceDef.complete(d) }
            override fun onDisconnected(d: CameraDevice) { runCatching { d.close() }; if (!deviceDef.isCompleted) deviceDef.completeExceptionally(IllegalStateException("disconnected")) }
            override fun onError(d: CameraDevice, e: Int) { runCatching { d.close() }; if (!deviceDef.isCompleted) deviceDef.completeExceptionally(IllegalStateException("err$e")) }
        }
        val sessionCb = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) { sessionHolder[0] = s; if (!sessionDef.isCompleted) sessionDef.complete(s) }
            override fun onConfigureFailed(s: CameraCaptureSession) { if (!sessionDef.isCompleted) sessionDef.completeExceptionally(IllegalStateException("cfg")) }
        }

        reader.setOnImageAvailableListener({ r ->
            val img = runCatching { r.acquireNextImage() }.getOrNull() ?: return@setOnImageAvailableListener
            if (accepting.get() && !imgDef.isCompleted) imgDef.complete(img) else runCatching { img.close() }
        }, bh)

        try {
            try { cameraManager.openCamera(camId, openCb, bh) }
            catch (e: SecurityException) { return@withContext Outcome.Failure(CaptureError.NoPermission) }
            catch (e: CameraAccessException) { return@withContext Outcome.Failure(mapAccess(e.reason, e.message)) }
            catch (e: IllegalArgumentException) { return@withContext Outcome.Failure(CaptureError.Internal(e.message ?: "bad id")) }

            val device = try { withTimeoutOrNull(1500L) { deviceDef.await() } ?: return@withContext Outcome.Failure(CaptureError.CameraUnavailable) }
            catch (_: Throwable) { return@withContext Outcome.Failure(CaptureError.CameraBusy) }

            try { device.createCaptureSession(listOf(reader.surface), sessionCb, bh) }
            catch (e: CameraAccessException) { runCatching { device.close() }; return@withContext Outcome.Failure(mapAccess(e.reason, e.message)) }
            catch (t: Throwable) { runCatching { device.close() }; return@withContext Outcome.Failure(CaptureError.SessionFailed(-1, t.message)) }

            val session = try { withTimeoutOrNull(1200L) { sessionDef.await() } ?: return@withContext Outcome.Failure(CaptureError.SessionFailed(-1, "session timeout")) }
            catch (_: Throwable) { return@withContext Outcome.Failure(CaptureError.CameraBusy) }

            val req = try {
                device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                    addTarget(reader.surface)
                    set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                    set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                    set(CaptureRequest.CONTROL_AE_LOCK, false)
                    set(CaptureRequest.JPEG_QUALITY, jpegQuality.toByte())
                    set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation)
                }.build()
            } catch (t: Throwable) { return@withContext Outcome.Failure(CaptureError.CaptureFailed(t.message ?: "request")) }

            runCatching { session.setRepeatingRequest(req, null, bh) }
            delay(500L)
            runCatching { session.stopRepeating() }
            accepting.set(true)

            try { session.capture(req, null, bh) }
            catch (e: CameraAccessException) { return@withContext Outcome.Failure(CaptureError.CaptureFailed("capture rejected")) }
            catch (t: Throwable) { return@withContext Outcome.Failure(CaptureError.CaptureFailed(t.message ?: "capture")) }

            val img = try { withTimeoutOrNull(1800L) { imgDef.await() } ?: return@withContext Outcome.Failure(CaptureError.CaptureFailed("image timeout")) }
            catch (_: Throwable) { return@withContext Outcome.Failure(CaptureError.CaptureFailed("await")) }

            try {
                val plane = img.planes.firstOrNull() ?: return@withContext Outcome.Failure(CaptureError.CaptureFailed("no plane"))
                val buf = plane.buffer
                val bytes = ByteArray(buf.remaining())
                buf.rewind(); buf.get(bytes)
                if (bytes.isEmpty()) return@withContext Outcome.Failure(CaptureError.CaptureFailed("empty jpeg"))
                Outcome.Success(CaptureResult(bytes, img.width, img.height, SystemClock.elapsedRealtime()))
            } finally { runCatching { img.close() } }
        } finally {
            runCatching { sessionHolder[0]?.let { it.stopRepeating(); it.close() } }
            runCatching { deviceHolder[0]?.close() }
            runCatching { reader.setOnImageAvailableListener(null, null); reader.close() }
            runCatching { ht.quitSafely() }
        }
    }

    private fun findRearCameraId(): String? = try {
        val ids = cameraManager.cameraIdList ?: emptyArray()
        ids.firstOrNull { id -> cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK }
            ?: ids.firstOrNull()
    } catch (_: Throwable) { null }

    private fun chooseBestSize(sizes: Array<Size>, targetW: Int): Size {
        val preferred = listOf(Size(1920, 1080), Size(1280, 720), Size(1440, 1080), Size(1280, 960))
        for (p in preferred) if (sizes.any { it.width == p.width && it.height == p.height }) return p
        for (p in preferred) { val portrait = sizes.firstOrNull { it.width == p.height && it.height == p.width }; if (portrait != null) return portrait }
        val cap = (targetW * 2).coerceAtLeast(1920)
        return sizes.filter { it.width <= cap && it.height <= cap }.maxByOrNull { it.width.toLong() * it.height }
            ?: sizes.minByOrNull { it.width.toLong() * it.height } ?: Size(1280, 720)
    }

    private fun displayRotation(): Int = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val dm = appContext.getSystemService(DisplayManager::class.java)
            when (dm.displays.firstOrNull()?.rotation ?: Surface.ROTATION_0) {
                Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0
            }
        } else {
            @Suppress("DEPRECATION") val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION") when (wm.defaultDisplay.rotation) {
                Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0
            }
        }
    } catch (_: Throwable) { 0 }

    private fun mapAccess(reason: Int, msg: String?): CaptureError = when (reason) {
        CameraAccessException.CAMERA_IN_USE, CameraAccessException.CAMERA_DISCONNECTED, CameraAccessException.MAX_CAMERAS_IN_USE -> CaptureError.CameraBusy
        CameraAccessException.CAMERA_DISABLED, CameraAccessException.CAMERA_ERROR -> CaptureError.CameraUnavailable
        else -> CaptureError.Internal(msg ?: "access$reason")
    }

    private companion object { const val TAG = AudioConfig.TAG }
}
