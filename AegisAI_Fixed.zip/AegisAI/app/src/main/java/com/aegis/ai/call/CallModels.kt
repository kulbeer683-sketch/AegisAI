package com.aegis.ai.call

sealed class CallState {
    data object Idle : CallState()
    data class Ringing(val number: String?, val contactName: String?) : CallState() {
        fun displayIdentity(): String = contactName ?: number ?: "an unknown number"
    }
    data class OffHook(val number: String?, val contactName: String?) : CallState() {
        fun displayIdentity(): String = contactName ?: number ?: "an unknown caller"
    }
}

sealed class CallEvent {
    data class IncomingStarted(val number: String?) : CallEvent()
    data class IncomingAnnouncementReady(val identity: String, val number: String?) : CallEvent()
    data object Answered : CallEvent()
    data object Ended : CallEvent()
    data object Rejected : CallEvent()
}

enum class CallCommand { ACCEPT, REJECT }
