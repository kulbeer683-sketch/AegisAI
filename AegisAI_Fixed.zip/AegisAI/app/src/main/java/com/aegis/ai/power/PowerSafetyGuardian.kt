package com.aegis.ai.power

import android.content.Context
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class PowerSafetyGuardian(
    context: Context,
    private val scope: CoroutineScope
) : AutoCloseable {

    private val appContext = context.applicationContext
    private val powerManager = appContext.getSystemService(Context.POWER_SERVICE) as PowerManager

    private val locks = ConcurrentHashMap<Long, TrackedLock>()
    private val nextId = AtomicLong(0L)
    private val leaks = AtomicLong(0L)

    private val _leakReleases = MutableSharedFlow<LeakRelease>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val leakReleases: SharedFlow<LeakRelease> = _leakReleases.asSharedFlow()

    private val sweepMutex = Mutex()
    private var watchdogJob: Job? = null

    @Volatile private var closed = false

    init { startWatchdog() }

    fun activeLockCount(): Int = locks.size
    fun totalLeakReleases(): Long = leaks.get()

    fun acquireSpeechWakeLock(owner: String, tag: String = "aegis:speech"): ScopedWakeLock =
        acquire(owner, tag, SPEECH_WAKE_LOCK_TIMEOUT_MS)

    fun acquireSystemWakeLock(owner: String, tag: String = "aegis:system"): ScopedWakeLock =
        acquire(owner, tag, SYSTEM_WAKE_LOCK_TIMEOUT_MS)

    fun releaseAll(): Int {
        var n = 0
        for ((id, t) in locks) if (locks.remove(id) != null) { t.forceRelease(); n++ }
        if (n > 0) Log.w(TAG, "releaseAll: force-released $n lock(s)")
        return n
    }

    override fun close() {
        if (closed) return
        closed = true
        watchdogJob?.cancel(); watchdogJob = null
        releaseAll()
    }

    inner class ScopedWakeLock internal constructor(
        private val id: Long,
        private val tag: String,
        private val owner: String
    ) : AutoCloseable {
        private val released = AtomicLong(0L)
        private val at = SystemClock.elapsedRealtime()
        fun isReleased(): Boolean = released.get() != 0L || !locks.containsKey(id)
        fun heldMs(): Long = SystemClock.elapsedRealtime() - at
        override fun close() {
            if (released.compareAndSet(0L, 1L)) {
                locks.remove(id)?.safeRelease()
            }
        }
    }

    private fun acquire(owner: String, tag: String, timeoutMs: Long): ScopedWakeLock {
        val id = nextId.incrementAndGet()
        val wl = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, tag).apply {
            setReferenceCounted(false)
            runCatching { acquire(timeoutMs + GRACE_MS) }
        }
        locks[id] = TrackedLock(id, tag, owner, SystemClock.elapsedRealtime(), timeoutMs, wl)
        return ScopedWakeLock(id, tag, owner)
    }

    private fun startWatchdog() {
        watchdogJob = scope.launch(Dispatchers.Default) {
            while (isActive && !closed) {
                delay(WATCHDOG_INTERVAL_MS)
                runCatching { sweep() }
            }
        }
    }

    private suspend fun sweep() = sweepMutex.withLock {
        val now = SystemClock.elapsedRealtime()
        for ((id, t) in locks.entries.toList()) {
            val age = t.ageMs(now)
            if (age > ORPHAN_THRESHOLD_MS) {
                Log.w(TAG, "WakeLock leak tag='${t.tag}' owner='${t.owner}' held=${age}ms")
                if (locks.remove(id) != null) {
                    t.forceRelease()
                    leaks.incrementAndGet()
                    _leakReleases.tryEmit(LeakRelease(t.tag, t.owner, age, forced = true))
                }
            }
        }
    }

    private class TrackedLock(
        val id: Long, val tag: String, val owner: String,
        val acquiredAtMs: Long, val timeoutMs: Long,
        private val wakeLock: PowerManager.WakeLock
    ) {
        private val released = AtomicBoolean(false)
        fun ageMs(now: Long): Long = now - acquiredAtMs
        fun safeRelease() {
            if (released.compareAndSet(false, true)) {
                runCatching { if (wakeLock.isHeld) wakeLock.release() }
            }
        }
        fun forceRelease() = safeRelease()
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val SPEECH_WAKE_LOCK_TIMEOUT_MS = 10_000L
        const val SYSTEM_WAKE_LOCK_TIMEOUT_MS = 30_000L
        const val WATCHDOG_INTERVAL_MS = 5_000L
        const val ORPHAN_THRESHOLD_MS = 15_000L
        private const val GRACE_MS = 500L
    }
}
