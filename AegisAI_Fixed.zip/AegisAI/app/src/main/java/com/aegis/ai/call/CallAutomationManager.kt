package com.aegis.ai.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.hardware.ControllerResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

class CallAutomationManager(
    context: Context,
    private val scope: CoroutineScope
) : AutoCloseable {

    private val appContext = context.applicationContext
    private val telephony =
        appContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val telecom =
        appContext.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "aegis-tel").apply { isDaemon = true } }

    private val _state = MutableStateFlow<CallState>(CallState.Idle)
    val state: StateFlow<CallState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<CallEvent>(
        extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<CallEvent> = _events.asSharedFlow()

    @Volatile private var lastNumber: String? = null
    @Volatile private var lastContact: String? = null
    private var lookupJob: Job? = null
    private var announceJob: Job? = null

    private val modern: TelephonyCallback? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) { handle(state, null) }
            }
        else null

    @Suppress("DEPRECATION")
    private val legacy: PhoneStateListener? =
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S)
            object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, phoneNumber: String?) { handle(state, phoneNumber) }
            }
        else null

    fun start() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modern?.let { telephony.registerTelephonyCallback(exec, it) }
            } else {
                @Suppress("DEPRECATION")
                telephony.listen(legacy, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (t: Throwable) { Log.e(AudioConfig.TAG, "telephony register failed", t) }
    }

    fun stop() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modern?.let { telephony.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                telephony.listen(legacy, PhoneStateListener.LISTEN_NONE)
            }
        }
        lookupJob?.cancel(); announceJob?.cancel()
    }

    override fun close() { stop(); exec.shutdownNow() }

    suspend fun answerCall(): ControllerResult = withContext(Dispatchers.Main.immediate) {
        if (!hasAnswer()) return@withContext ControllerResult.Failure("ANSWER_PHONE_CALLS not granted")
        if (_state.value !is CallState.Ringing) return@withContext ControllerResult.Failure("No ringing call")
        try {
            @Suppress("DEPRECATION")
            telecom.acceptRingingCall()
            ControllerResult.Success("Call answered")
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "answer failed") }
    }

    suspend fun rejectCall(): ControllerResult = withContext(Dispatchers.Main.immediate) {
        if (!hasAnswer()) return@withContext ControllerResult.Failure("ANSWER_PHONE_CALLS not granted")
        if (_state.value !is CallState.Ringing) return@withContext ControllerResult.Failure("No ringing call")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && telecom.endCall()) {
                _events.tryEmit(CallEvent.Rejected)
                return@withContext ControllerResult.Success("Call rejected")
            }
        } catch (_: Throwable) {}
        try {
            @Suppress("DEPRECATION") telecom.silenceRinger()
            _events.tryEmit(CallEvent.Rejected)
            ControllerResult.Success("Ringer silenced")
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "reject failed") }
    }

    private fun handle(state: Int, number: String?) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> onRinging(number)
            TelephonyManager.CALL_STATE_OFFHOOK -> onOffhook()
            TelephonyManager.CALL_STATE_IDLE -> onIdle()
        }
    }

    private fun onRinging(raw: String?) {
        lastNumber = raw; lastContact = null
        _state.value = CallState.Ringing(raw, null)
        _events.tryEmit(CallEvent.IncomingStarted(raw))

        lookupJob?.cancel()
        lookupJob = scope.launch {
            val name = raw?.let { lookupName(it) }
            if (name != null && _state.value is CallState.Ringing) {
                val cur = _state.value as CallState.Ringing
                if (cur.number == raw) {
                    lastContact = name
                    _state.value = cur.copy(contactName = name)
                }
            }
        }

        announceJob?.cancel()
        announceJob = scope.launch {
            var waited = 0L
            while (waited < 450L && lastContact == null &&
                _state.value is CallState.Ringing && lastNumber == raw) {
                delay(50L); waited += 50L
            }
            val cur = _state.value
            if (cur is CallState.Ringing && cur.number == raw) {
                _events.tryEmit(CallEvent.IncomingAnnouncementReady(cur.displayIdentity(), cur.number))
            }
        }
    }

    private fun onOffhook() {
        lookupJob?.cancel(); announceJob?.cancel()
        _state.value = CallState.OffHook(lastNumber, lastContact)
        _events.tryEmit(CallEvent.Answered)
    }

    private fun onIdle() {
        lookupJob?.cancel(); announceJob?.cancel()
        val had = _state.value !is CallState.Idle
        lastNumber = null; lastContact = null
        _state.value = CallState.Idle
        if (had) _events.tryEmit(CallEvent.Ended)
    }

    private suspend fun lookupName(number: String): String? = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) return@withContext null
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        try {
            appContext.contentResolver.query(uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                    if (i >= 0) return@withContext c.getString(i)
                }
            }
        } catch (t: Throwable) { Log.e(AudioConfig.TAG, "contact lookup failed", t) }
        null
    }

    private fun hasAnswer(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ANSWER_PHONE_CALLS)
            == PackageManager.PERMISSION_GRANTED
}
