package com.aegis.ai.intent

import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioDspPipeline
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class SpeechIntentEngine(
    private val scope: CoroutineScope,
    private val asr: AsrTranscriber = AsrTranscriber.NoOp
) {
    private val _matches = MutableSharedFlow<IntentMatch>(
        extraBufferCapacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val matches: SharedFlow<IntentMatch> = _matches.asSharedFlow()

    private var job: Job? = null
    private var speaking = false
    private val buf = ArrayList<Short>(AudioConfig.FRAME_SIZE * 128)

    fun bindTo(pipeline: AudioDspPipeline): Job {
        job?.cancel()
        val j = pipeline.frames.onEach { ingest(it) }.launchIn(scope)
        job = j
        return j
    }

    fun shutdown() { job?.cancel(); job = null; speaking = false; buf.clear() }

    fun submitText(text: String): IntentMatch {
        val m = IntentGrammar.parse(text)
        if (m.normalizedText.isNotBlank()) _matches.tryEmit(m)
        return m
    }

    suspend fun ingest(frame: AudioDspPipeline.AudioFrame) {
        if (frame.vad.isSpeech) {
            if (!speaking) { speaking = true; buf.clear() }
            for (s in frame.pcm) buf.add(s)
        } else if (speaking) {
            speaking = false
            if (buf.isEmpty()) return
            val pcm = buf.toShortArray(); buf.clear()
            Log.d(AudioConfig.TAG, "Utterance " + pcm.size + " samples")
            scope.launch {
                val text = try { asr.transcribe(pcm, AudioConfig.SAMPLE_RATE) } catch (t: Throwable) { null }
                if (text.isNullOrBlank()) return@launch
                _matches.tryEmit(IntentGrammar.parse(text))
            }
        }
    }
}
