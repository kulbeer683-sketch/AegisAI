package com.aegis.ai.hardware

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

sealed class ControllerResult {
    data class Success(val message: String) : ControllerResult()
    data class Failure(val message: String) : ControllerResult()
    data class NeedsUserIntent(val intent: Intent, val message: String) : ControllerResult()
}

class FlashlightController(context: Context) : AutoCloseable {
    private val appContext = context.applicationContext
    private val cameraManager = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val mutex = Mutex()

    @Volatile private var torchOn = false
    @Volatile private var cameraId: String? = null

    init { cameraId = resolveCameraId() }

    private val cb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) { if (id == cameraId) torchOn = enabled }
        override fun onTorchModeUnavailable(id: String) { if (id == cameraId) torchOn = false }
    }

    init { runCatching { cameraManager.registerTorchCallback(cb, mainHandler) } }

    suspend fun setTorch(enabled: Boolean): ControllerResult = mutex.withLock {
        val id = cameraId ?: return@withLock ControllerResult.Failure("No torch camera")
        withContext(Dispatchers.Main.immediate) {
            try {
                cameraManager.setTorchMode(id, enabled); torchOn = enabled
                ControllerResult.Success("Torch ${if (enabled) "on" else "off"}")
            } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "torch failed") }
        }
    }

    suspend fun toggle(): ControllerResult = mutex.withLock { setTorchInternal(!torchOn) }

    private suspend fun setTorchInternal(enabled: Boolean): ControllerResult {
        val id = cameraId ?: return ControllerResult.Failure("No torch camera")
        return withContext(Dispatchers.Main.immediate) {
            try {
                cameraManager.setTorchMode(id, enabled); torchOn = enabled
                ControllerResult.Success("Torch ${if (enabled) "on" else "off"}")
            } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "torch failed") }
        }
    }

    private fun resolveCameraId(): String? = try {
        val ids = cameraManager.cameraIdList
        ids.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    } catch (_: Throwable) { null }

    override fun close() {
        runCatching { cameraManager.unregisterTorchCallback(cb) }
        cameraId?.let { runCatching { cameraManager.setTorchMode(it, false) } }
    }
}

class VolumeController(context: Context) {
    private val audioManager = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun setVolume(stream: AudioStream, percent: Int): ControllerResult {
        val s = stream.androidStream
        val max = audioManager.getStreamMaxVolume(s)
        val target = (max * percent.coerceIn(0, 100) / 100).coerceIn(0, max)
        return try {
            audioManager.setStreamVolume(s, target, AudioManager.FLAG_SHOW_UI)
            ControllerResult.Success("${stream.name} → ${percent}%")
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "volume failed") }
    }

    fun adjustVolume(stream: AudioStream, direction: AegisAction.Direction, steps: Int = 1): ControllerResult {
        val s = stream.androidStream
        val d = if (direction == AegisAction.Direction.UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        return try {
            repeat(steps.coerceIn(1, 15)) { audioManager.adjustStreamVolume(s, d, AudioManager.FLAG_SHOW_UI) }
            ControllerResult.Success("${stream.name} adjusted")
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "adjust failed") }
    }

    fun setMute(stream: AudioStream, mute: Boolean?): ControllerResult {
        val s = stream.androidStream
        return try {
            val shouldMute = mute ?: (audioManager.getStreamVolume(s) > 0)
            val max = audioManager.getStreamMaxVolume(s)
            val target = if (shouldMute) 0 else maxOf(1, max / 3)
            audioManager.setStreamVolume(s, target, AudioManager.FLAG_SHOW_UI)
            ControllerResult.Success("${stream.name} ${if (shouldMute) "muted" else "unmuted"}")
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "mute failed") }
    }
}

class ConnectivityController(context: Context) {
    private val appContext = context.applicationContext
    private val bt: BluetoothAdapter? =
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val wifi: WifiManager? =
        appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    fun isBluetoothEnabled() = bt?.isEnabled == true
    fun isWifiEnabled() = wifi?.isWifiEnabled == true

    @Suppress("DEPRECATION")
    fun setBluetooth(enabled: Boolean): ControllerResult {
        val a = bt ?: return ControllerResult.Failure("No Bluetooth")
        if (a.isEnabled == enabled) return ControllerResult.Success("already ${if (enabled) "on" else "off"}")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(appContext, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) return ControllerResult.NeedsUserIntent(btRequest(enabled), "BLUETOOTH_CONNECT required")
        return try {
            val ok = if (enabled) a.enable() else a.disable()
            if (ok) ControllerResult.Success("BT ${if (enabled) "on" else "off"}")
            else ControllerResult.NeedsUserIntent(btRequest(enabled), "Direct toggle rejected")
        } catch (t: Throwable) { ControllerResult.NeedsUserIntent(btRequest(enabled), t.message ?: "BT failed") }
    }

    fun toggleBluetooth() = setBluetooth(bt?.isEnabled != true)

    private fun btRequest(enable: Boolean) = Intent(
        if (enable) BluetoothAdapter.ACTION_REQUEST_ENABLE else BluetoothAdapter.ACTION_REQUEST_DISABLE
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    @Suppress("DEPRECATION")
    fun setWifi(enabled: Boolean): ControllerResult {
        val m = wifi ?: return ControllerResult.Failure("No WiFi")
        if (m.isWifiEnabled == enabled) return ControllerResult.Success("already ${if (enabled) "on" else "off"}")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return try {
                if (m.setWifiEnabled(enabled)) ControllerResult.Success("WiFi ${if (enabled) "on" else "off"}")
                else ControllerResult.NeedsUserIntent(wifiPanel(), "Direct toggle rejected")
            } catch (t: Throwable) { ControllerResult.NeedsUserIntent(wifiPanel(), t.message ?: "WiFi failed") }
        }
        return ControllerResult.NeedsUserIntent(wifiPanel(), "WiFi requires user confirmation")
    }

    fun toggleWifi() = setWifi(wifi?.isWifiEnabled != true)

    private fun wifiPanel(): Intent = (
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_WIFI)
        else Intent(Settings.ACTION_WIFI_SETTINGS)
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
