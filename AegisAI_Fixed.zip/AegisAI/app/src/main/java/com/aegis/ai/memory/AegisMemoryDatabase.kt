package com.aegis.ai.memory

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.memory.dao.ActionFrequencyDao
import com.aegis.ai.memory.dao.KnowledgeMemoryDao
import com.aegis.ai.memory.dao.UserProfileDao
import com.aegis.ai.memory.entity.ActionFrequencyEntity
import com.aegis.ai.memory.entity.KnowledgeMemoryEntity
import com.aegis.ai.memory.entity.UserProfileEntity
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(
    entities = [UserProfileEntity::class, KnowledgeMemoryEntity::class, ActionFrequencyEntity::class],
    version = 1, exportSchema = true
)
abstract class AegisMemoryDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun knowledgeMemoryDao(): KnowledgeMemoryDao
    abstract fun actionFrequencyDao(): ActionFrequencyDao

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val DB_NAME = "aegis_memory.db"

        @Volatile private var instance: AegisMemoryDatabase? = null
        @Volatile private var libLoaded = false

        fun get(context: Context, keyProvider: MemoryDatabaseKeyProvider): AegisMemoryDatabase? {
            instance?.let { return it }
            return synchronized(this) {
                instance?.let { return it }
                if (!ensureLib()) return null
                try {
                    val pass = keyProvider.getOrCreatePassphrase()
                    val factory = SupportOpenHelperFactory(pass)
                    val db = Room.databaseBuilder(
                        context.applicationContext, AegisMemoryDatabase::class.java, DB_NAME
                    )
                        .openHelperFactory(factory)
                        .addCallback(object : Callback() {
                            override fun onOpen(db: SupportSQLiteDatabase) { super.onOpen(db) }
                        })
                        .fallbackToDestructiveMigrationOnDowngrade()
                        .build()
                    instance = db
                    db
                } catch (t: Throwable) { Log.e(TAG, "Failed to build memory DB", t); null }
            }
        }

        fun close() {
            synchronized(this) {
                runCatching { instance?.close() }
                instance = null
            }
        }

        private fun ensureLib(): Boolean {
            if (libLoaded) return true
            return synchronized(this) {
                if (libLoaded) return true
                try { System.loadLibrary("sqlcipher"); libLoaded = true; true }
                catch (t: Throwable) { Log.e(TAG, "SQLCipher native load failed", t); false }
            }
        }
    }
}
