package com.aegis.ai.location

import kotlinx.serialization.Serializable

enum class GeoContext { HOME, WORK, TRANSIT, UNKNOWN }

@Serializable
data class LearnedZone(
    val context: GeoContext, val latitude: Double, val longitude: Double,
    val radiusMeters: Float, val ssid: String? = null,
    val learnedAtMs: Long = System.currentTimeMillis()
)

@Serializable
data class LocationReminder(
    val id: String, val target: GeoContext, val message: String,
    val createdAtMs: Long = System.currentTimeMillis()
) { init { require(target == GeoContext.HOME || target == GeoContext.WORK) } }

data class GeoQueryResult(
    val context: GeoContext, val confidence: Confidence,
    val latitude: Double?, val longitude: Double?,
    val matchedSsid: String?, val ageMs: Long
) { enum class Confidence { HIGH, MEDIUM, LOW } }
