package com.aegis.ai.routine

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.aegis.ai.vitals.DeviceVitalsMonitor
import com.aegis.ai.vitals.Plugged
import com.aegis.ai.vitals.VitalsSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Calendar

class ContextTriggerEngine(
    context: Context,
    private val vitals: DeviceVitalsMonitor,
    private val prefs: RoutinePreferences,
    private val scope: CoroutineScope
) {

    private val appContext = context.applicationContext
    private val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val mutex = Mutex()

    @Volatile private var prev: TriggerSnapshot? = null
    @Volatile private var audioState: AudioState = AudioState.NO_HEADSET

    private var cb: AudioDeviceCallback? = null
    @Volatile private var started = false

    fun start() {
        if (started) return; started = true
        audioState = readAudio()
        val c = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(d: Array<out AudioDeviceInfo>?) { updateAudio() }
            override fun onAudioDevicesRemoved(d: Array<out AudioDeviceInfo>?) { updateAudio() }
        }
        runCatching { am.registerAudioDeviceCallback(c, handler); cb = c }
    }

    fun stop() {
        if (!started) return; started = false
        cb?.let { runCatching { am.unregisterAudioDeviceCallback(it) } }; cb = null
    }

    fun snapshot(): TriggerSnapshot {
        val v = vitals.current()
        return TriggerSnapshot(slotNow(), classifyPower(v), audioState, v.batteryPercent, v.isCharging, SystemClock.elapsedRealtime())
    }

    suspend fun evaluate(): List<TriggerEvent> {
        val cur = snapshot()
        val old = mutex.withLock { val o = prev; prev = cur; o }
        val out = ArrayList<TriggerEvent>(3)

        if (prefs.isEnabled(RoutineKind.BEDTIME)) {
            val night = cur.timeSlot == TimeSlot.NIGHT
            val plugged = cur.powerState == PowerState.AC_CONNECTED || cur.powerState == PowerState.WIRELESS_CHARGING
            if (night && plugged) out += TriggerEvent(RoutineKind.BEDTIME, cur, "night+plugged")
        }
        if (prefs.isEnabled(RoutineKind.MORNING_BRIEF) && old != null) {
            val wasPlugged = old.powerState == PowerState.AC_CONNECTED || old.powerState == PowerState.WIRELESS_CHARGING
            if (wasPlugged && cur.powerState == PowerState.UNPLUGGED && cur.timeSlot == TimeSlot.MORNING) out += TriggerEvent(RoutineKind.MORNING_BRIEF, cur, "morning+unplugged")
        }
        if (prefs.isEnabled(RoutineKind.BATTERY_PROTECTION) && old != null) {
            val thr = prefs.getBatteryProtectionThreshold()
            if (old.batteryPercent < thr && cur.batteryPercent >= thr && cur.charging) out += TriggerEvent(RoutineKind.BATTERY_PROTECTION, cur, "battery hit $thr%")
        }
        return out
    }

    private fun updateAudio() { audioState = readAudio() }

    private fun readAudio(): AudioState = runCatching {
        val d = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        when {
            d.any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO } -> AudioState.BLUETOOTH_SCO
            d.any { it.type == AudioDeviceInfo.TYPE_USB_HEADSET } -> AudioState.USB_HEADSET
            d.any { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES } -> AudioState.WIRED_HEADSET
            else -> AudioState.NO_HEADSET
        }
    }.getOrDefault(AudioState.NO_HEADSET)

    private fun classifyPower(v: VitalsSnapshot): PowerState {
        if (v.batteryPercent in 1..15 && !v.isCharging) return PowerState.CRITICAL_BATTERY
        return when (v.batteryPlugged) {
            Plugged.AC, Plugged.USB -> PowerState.AC_CONNECTED
            Plugged.WIRELESS -> PowerState.WIRELESS_CHARGING
            Plugged.NONE -> PowerState.UNPLUGGED
        }
    }

    private fun slotNow(): TimeSlot {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when { h in 6..8 -> TimeSlot.MORNING; h in 9..17 -> TimeSlot.WORK; h in 18..21 -> TimeSlot.EVENING; else -> TimeSlot.NIGHT }
    }
}
