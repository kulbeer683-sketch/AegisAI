package com.aegis.ai.call

internal object CallCommandParser {

    private val ACCEPT = setOf("pick up","pickup","answer","accept","yes","yeah","haan","han","ha","हाँ","हां","हा","लो")
    private val REJECT = setOf("reject","cut","disconnect","decline","no","nahi","na","नहीं","ना")

    fun parse(text: String): CallCommand? {
        val n = text.lowercase().trim()
        if (n.isEmpty()) return null
        if (ACCEPT.any { n == it || n.contains(it) }) return CallCommand.ACCEPT
        if (REJECT.any { n == it || n.contains(it) }) return CallCommand.REJECT
        return null
    }
}
