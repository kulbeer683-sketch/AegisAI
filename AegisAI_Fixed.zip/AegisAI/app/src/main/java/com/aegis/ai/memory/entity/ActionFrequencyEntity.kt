package com.aegis.ai.memory.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "action_frequency",
    indices = [Index(value = ["action_type", "target"], unique = true), Index(value = ["action_type", "count"])]
)
data class ActionFrequencyEntity(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") val id: Long = 0L,
    @ColumnInfo(name = "action_type") val actionType: String,
    @ColumnInfo(name = "target") val target: String,
    @ColumnInfo(name = "count") val count: Long = 1L,
    @ColumnInfo(name = "last_invoked_at_ms") val lastInvokedAtMs: Long = System.currentTimeMillis()
)
