package com.aegis.ai.routine

import android.content.Context
import android.content.SharedPreferences

class RoutinePreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isEnabled(k: RoutineKind) = prefs.getBoolean("enabled_${k.name.lowercase()}", true)
    fun setEnabled(k: RoutineKind, v: Boolean) { prefs.edit().putBoolean("enabled_${k.name.lowercase()}", v).apply() }
    fun enabledRoutines(): Set<RoutineKind> = RoutineKind.entries.filter { isEnabled(it) }.toSet()

    fun getBatteryProtectionThreshold(): Int = prefs.getInt(KEY_THR, DEFAULT_THR).coerceIn(MIN_THR, MAX_THR)
    fun setBatteryProtectionThreshold(p: Int) { prefs.edit().putInt(KEY_THR, p.coerceIn(MIN_THR, MAX_THR)).apply() }

    fun lastFiredAt(k: RoutineKind): Long = prefs.getLong("last_fired_${k.name.lowercase()}", 0L)
    fun markFired(k: RoutineKind, atMs: Long = System.currentTimeMillis()) { prefs.edit().putLong("last_fired_${k.name.lowercase()}", atMs).apply() }
    fun isWithinCooldown(k: RoutineKind, cooldownMs: Long, now: Long = System.currentTimeMillis()): Boolean {
        val last = lastFiredAt(k); if (last == 0L) return false; return now - last < cooldownMs
    }
    fun resetAll() { prefs.edit().clear().apply() }

    companion object {
        private const val FILE = "aegis_routines"
        private const val KEY_THR = "battery_protection_threshold"
        const val DEFAULT_THR = 80
        const val MIN_THR = 50
        const val MAX_THR = 100
    }
}
