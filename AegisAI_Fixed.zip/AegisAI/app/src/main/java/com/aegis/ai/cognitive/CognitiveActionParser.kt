package com.aegis.ai.cognitive

import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream
import kotlinx.serialization.json.Json

object CognitiveActionParser {

    private val json = Json { ignoreUnknownKeys = true; explicitNulls = false; isLenient = true }

    fun parse(rawResponse: String): AegisAction? {
        val trimmed = rawResponse.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}") || !trimmed.contains("\"action\"")) return null
        val payload = try { json.decodeFromString(GeminiActionPayload.serializer(), trimmed) }
        catch (t: Throwable) { Log.d(TAG, "Not a valid action payload", t); return null }

        val p = payload.params.orEmpty()
        return when (payload.action.uppercase()) {
            "TORCH_ON" -> AegisAction.TorchOn
            "TORCH_OFF" -> AegisAction.TorchOff
            "TORCH_TOGGLE" -> AegisAction.TorchToggle
            "VOLUME_SET" -> {
                val s = parseStream(p["stream"]); val n = parsePercent(p["percent"])
                if (s != null && n != null) AegisAction.VolumeSet(s, n) else null
            }
            "VOLUME_UP" -> AegisAction.VolumeAdjust(parseStream(p["stream"]) ?: AudioStream.MEDIA, AegisAction.Direction.UP)
            "VOLUME_DOWN" -> AegisAction.VolumeAdjust(parseStream(p["stream"]) ?: AudioStream.MEDIA, AegisAction.Direction.DOWN)
            "VOLUME_MUTE" -> AegisAction.VolumeMute(parseStream(p["stream"]) ?: AudioStream.MEDIA, mute = true)
            "BLUETOOTH_ON" -> AegisAction.BluetoothOn
            "BLUETOOTH_OFF" -> AegisAction.BluetoothOff
            "BLUETOOTH_TOGGLE" -> AegisAction.BluetoothToggle
            "WIFI_ON" -> AegisAction.WifiOn
            "WIFI_OFF" -> AegisAction.WifiOff
            "WIFI_TOGGLE" -> AegisAction.WifiToggle
            "GO_HOME" -> AegisAction.GoHome
            "GO_BACK" -> AegisAction.GoBack
            "SHOW_RECENTS" -> AegisAction.ShowRecents
            "SHOW_NOTIFICATIONS" -> AegisAction.ShowNotifications
            "LOCK_SCREEN" -> AegisAction.LockScreen
            else -> { Log.d(TAG, "Unknown action '${payload.action}'"); null }
        }
    }

    private fun parseStream(raw: String?): AudioStream? = when (raw?.trim()?.uppercase()) {
        "MEDIA", null, "" -> AudioStream.MEDIA
        "CALL" -> AudioStream.CALL
        "RING" -> AudioStream.RING
        "ALARM" -> AudioStream.ALARM
        "NOTIFICATION" -> AudioStream.NOTIFICATION
        else -> AudioStream.MEDIA
    }

    private fun parsePercent(raw: String?): Int? = raw?.trim()?.removeSuffix("%")?.trim()?.toIntOrNull()?.coerceIn(0, 100)

    private const val TAG = AudioConfig.TAG
}
