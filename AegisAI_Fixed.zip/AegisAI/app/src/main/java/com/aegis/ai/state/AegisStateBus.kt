package com.aegis.ai.state

import com.aegis.ai.decision.Phase4DiagnosticsPayload
import com.aegis.ai.power.ThrottleTier
import com.aegis.ai.vitals.VitalsSnapshot
import com.aegis.ai.wakeword.AssistantStateCoordinator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AegisStateBus {

    private val _serviceRunning = MutableStateFlow(false)
    val serviceRunning: StateFlow<Boolean> = _serviceRunning.asStateFlow()

    private val _pipelineRunning = MutableStateFlow(false)
    val pipelineRunning: StateFlow<Boolean> = _pipelineRunning.asStateFlow()

    private val _assistantState = MutableStateFlow<AssistantStateCoordinator.State?>(null)
    val assistantState: StateFlow<AssistantStateCoordinator.State?> = _assistantState.asStateFlow()

    private val _vitals = MutableStateFlow<VitalsSnapshot?>(null)
    val vitals: StateFlow<VitalsSnapshot?> = _vitals.asStateFlow()

    private val _heartbeat = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val heartbeat: StateFlow<Map<String, Boolean>> = _heartbeat.asStateFlow()

    private val _diagnostics = MutableStateFlow<Phase4DiagnosticsPayload?>(null)
    val diagnostics: StateFlow<Phase4DiagnosticsPayload?> = _diagnostics.asStateFlow()

    private val _geminiKeyPresent = MutableStateFlow(false)
    val geminiKeyPresent: StateFlow<Boolean> = _geminiKeyPresent.asStateFlow()

    private val _voicePitch = MutableStateFlow(0.88f)
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceRate = MutableStateFlow(1.04f)
    val voiceRate: StateFlow<Float> = _voiceRate.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _privacyCloudEnabled = MutableStateFlow(true)
    val privacyCloudEnabled: StateFlow<Boolean> = _privacyCloudEnabled.asStateFlow()

    private val _privacyScreenVisionEnabled = MutableStateFlow(true)
    val privacyScreenVisionEnabled: StateFlow<Boolean> = _privacyScreenVisionEnabled.asStateFlow()

    private val _privacyCameraVisionEnabled = MutableStateFlow(true)
    val privacyCameraVisionEnabled: StateFlow<Boolean> = _privacyCameraVisionEnabled.asStateFlow()

    private val _privacyLocationRoutinesEnabled = MutableStateFlow(true)
    val privacyLocationRoutinesEnabled: StateFlow<Boolean> = _privacyLocationRoutinesEnabled.asStateFlow()

    private val _throttleTier = MutableStateFlow(ThrottleTier.NORMAL)
    val throttleTier: StateFlow<ThrottleTier> = _throttleTier.asStateFlow()

    private val _activeWakeLocks = MutableStateFlow(0)
    val activeWakeLocks: StateFlow<Int> = _activeWakeLocks.asStateFlow()

    private val _releasedLeaks = MutableStateFlow(0L)
    val releasedLeaks: StateFlow<Long> = _releasedLeaks.asStateFlow()

    fun setServiceRunning(v: Boolean) { _serviceRunning.value = v }
    fun setPipelineRunning(v: Boolean) { _pipelineRunning.value = v }
    fun setAssistantState(v: AssistantStateCoordinator.State?) { _assistantState.value = v }
    fun setVitals(v: VitalsSnapshot?) { _vitals.value = v }
    fun setHeartbeat(v: Map<String, Boolean>) { _heartbeat.value = v }
    fun setDiagnostics(v: Phase4DiagnosticsPayload?) { _diagnostics.value = v }
    fun setGeminiKeyPresent(v: Boolean) { _geminiKeyPresent.value = v }
    fun setVoicePitch(v: Float) { _voicePitch.value = v }
    fun setVoiceRate(v: Float) { _voiceRate.value = v }
    fun setLastError(v: String?) { _lastError.value = v }
    fun setPrivacyCloudEnabled(v: Boolean) { _privacyCloudEnabled.value = v }
    fun setPrivacyScreenVisionEnabled(v: Boolean) { _privacyScreenVisionEnabled.value = v }
    fun setPrivacyCameraVisionEnabled(v: Boolean) { _privacyCameraVisionEnabled.value = v }
    fun setPrivacyLocationRoutinesEnabled(v: Boolean) { _privacyLocationRoutinesEnabled.value = v }
    fun setThrottleTier(v: ThrottleTier) { _throttleTier.value = v }
    fun setActiveWakeLocks(v: Int) { _activeWakeLocks.value = v }
    fun setReleasedLeaks(v: Long) { _releasedLeaks.value = v }

    fun clear() {
        _serviceRunning.value = false; _pipelineRunning.value = false; _assistantState.value = null
        _vitals.value = null; _heartbeat.value = emptyMap(); _diagnostics.value = null
        _geminiKeyPresent.value = false; _voicePitch.value = 0.88f; _voiceRate.value = 1.04f
        _lastError.value = null
        _privacyCloudEnabled.value = true; _privacyScreenVisionEnabled.value = true
        _privacyCameraVisionEnabled.value = true; _privacyLocationRoutinesEnabled.value = true
        _throttleTier.value = ThrottleTier.NORMAL; _activeWakeLocks.value = 0; _releasedLeaks.value = 0L
    }
}
