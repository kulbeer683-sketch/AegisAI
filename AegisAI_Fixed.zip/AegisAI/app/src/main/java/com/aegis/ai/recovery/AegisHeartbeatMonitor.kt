package com.aegis.ai.recovery

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

class AegisHeartbeatMonitor(private val scope: CoroutineScope) {

    private val components = ConcurrentHashMap<String, Registered>()
    private var tickerJob: Job? = null
    private val recoveryMutex = Mutex()

    @Volatile private var started = false

    private data class Registered(
        val component: HeartbeatComponent,
        val misses: AtomicLong = AtomicLong(0L),
        val lastRecoveryAtMs: AtomicLong = AtomicLong(0L)
    )

    fun start() {
        if (started) return
        started = true
        tickerJob = scope.launch(Dispatchers.Default) {
            delay(TICK_MS)
            while (isActive) {
                runCatching { runCycle() }
                delay(TICK_MS)
            }
        }
    }

    fun stop() { if (!started) return; started = false; tickerJob?.cancel(); tickerJob = null }

    fun register(component: HeartbeatComponent) { components[component.componentName] = Registered(component) }
    fun unregister(name: String) { components.remove(name) }

    fun healthSnapshot(): Map<String, Boolean> = components.mapValues { (_, r) ->
        try { r.component.isAlive() } catch (_: Throwable) { false }
    }

    private suspend fun runCycle() {
        for ((name, r) in components.entries.toList()) {
            val alive = try { r.component.isAlive() } catch (_: Throwable) { false }
            if (alive) { r.misses.set(0L); continue }
            val n = r.misses.incrementAndGet()
            Log.w(TAG, "Heartbeat miss $n for '$name'")
            if (n >= MISS_THRESHOLD) attemptRecovery(name, r)
        }
    }

    private suspend fun attemptRecovery(name: String, r: Registered) = recoveryMutex.withLock {
        val now = SystemClock.elapsedRealtime()
        val last = r.lastRecoveryAtMs.get()
        if (now - last < RECOVERY_COOLDOWN_MS) return@withLock
        r.lastRecoveryAtMs.set(now)
        val recovered = try { withTimeoutOrNull(RECOVERY_TIMEOUT_MS) { r.component.recover() } ?: false }
        catch (ce: CancellationException) { throw ce }
        catch (_: Throwable) { false }
        if (recovered) { Log.i(TAG, "Component '$name' recovered"); r.misses.set(0L) }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val TICK_MS = 60_000L
        private const val MISS_THRESHOLD = 3L
        private const val RECOVERY_TIMEOUT_MS = 5_000L
        private const val RECOVERY_COOLDOWN_MS = 3 * 60_000L
    }
}
