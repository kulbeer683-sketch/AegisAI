package com.aegis.ai.cognitive

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NetworkMonitor(context: Context) : AutoCloseable {

    private val connectivityManager =
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _online = MutableStateFlow(currentOnline())
    val online: StateFlow<Boolean> = _online.asStateFlow()

    @Volatile private var callback: ConnectivityManager.NetworkCallback? = null

    init {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { update(true) }
            override fun onLost(network: Network) { update(currentOnline()) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                update(caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
            }
        }
        try { connectivityManager.registerDefaultNetworkCallback(cb); callback = cb }
        catch (t: Throwable) { Log.e(TAG, "registerDefaultNetworkCallback failed", t) }
    }

    fun isOnline(): Boolean = _online.value

    private fun currentOnline(): Boolean = try {
        val active = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(active) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Throwable) { false }

    private fun update(state: Boolean) {
        if (_online.value != state) { Log.i(TAG, "Network online → $state"); _online.value = state }
    }

    override fun close() {
        callback?.let { runCatching { connectivityManager.unregisterNetworkCallback(it) } }
        callback = null
    }

    private companion object { const val TAG = AudioConfig.TAG }
}
