package com.aegis.ai.wakeword

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioDspPipeline
import java.util.concurrent.atomic.AtomicLong

class WakeWordDetector(
    private val engine: KwsEngine = TemplateKwsEngine(),
    sensitivity: Float = DEFAULT_SENSITIVITY,
    private val cooldownMs: Long = DEFAULT_COOLDOWN_MS
) {

    data class WakeWordEvent(val keyword: String, val confidence: Float, val timestampMs: Long)

    @Volatile var sensitivity: Float = sensitivity.coerceIn(0.05f, 0.95f); private set

    private val lastFireMs = AtomicLong(0L)
    private val detCount = AtomicLong(0L)
    val detections: Long get() = detCount.get()

    fun setSensitivity(v: Float) { sensitivity = v.coerceIn(0.05f, 0.95f) }

    fun ingest(frame: AudioDspPipeline.AudioFrame): WakeWordEvent? {
        val scores = try { engine.process(frame.pcm) } catch (t: Throwable) { return null }
        if (scores.isEmpty()) return null
        var bi = 0; var bs = scores[0]
        for (i in 1 until scores.size) if (scores[i] > bs) { bs = scores[i]; bi = i }
        if (bs < sensitivity) return null
        val now = SystemClock.elapsedRealtime()
        val prev = lastFireMs.get()
        if (now - prev < cooldownMs) return null
        if (!lastFireMs.compareAndSet(prev, now)) return null
        val kw = engine.keywords.getOrNull(bi) ?: "unknown"
        detCount.incrementAndGet()
        return WakeWordEvent(kw, bs, now)
    }

    fun reset() { engine.reset(); lastFireMs.set(0L) }

    fun close() { runCatching { engine.close() } }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val DEFAULT_SENSITIVITY = 0.65f
        private const val DEFAULT_COOLDOWN_MS = 1_500L
    }
}
