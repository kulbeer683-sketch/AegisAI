package com.aegis.ai.routine

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.aegis.ai.audio.AudioConfig
import java.util.Calendar

class RoutinePeriodicWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = runCatching {
        Log.d(TAG, "Periodic routine safety check")
        Result.success()
    }.getOrElse { Result.retry() }

    companion object { private const val TAG = AudioConfig.TAG }
}
