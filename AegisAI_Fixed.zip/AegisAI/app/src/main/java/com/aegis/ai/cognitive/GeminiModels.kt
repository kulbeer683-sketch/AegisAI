package com.aegis.ai.cognitive

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null,
    val generationConfig: GenerationConfig? = null,
    val safetySettings: List<SafetySetting>? = null
)

@Serializable
internal data class GeminiContent(
    val role: String? = null,
    val parts: List<GeminiPart>
)

@Serializable
internal data class GeminiPart(
    val text: String? = null,
    val inlineData: InlineData? = null
)

@Serializable
internal data class InlineData(
    val mimeType: String,
    val data: String
)

@Serializable
internal data class GenerationConfig(
    val temperature: Double? = null,
    val topP: Double? = null,
    val topK: Int? = null,
    val maxOutputTokens: Int? = null,
    val candidateCount: Int? = null,
    val stopSequences: List<String>? = null
)

@Serializable
internal data class SafetySetting(val category: String, val threshold: String)

@Serializable
internal data class GeminiResponse(
    val candidates: List<Candidate>? = null,
    val promptFeedback: PromptFeedback? = null,
    val usageMetadata: UsageMetadata? = null
)

@Serializable
internal data class Candidate(
    val content: GeminiContent? = null,
    val finishReason: String? = null,
    val index: Int? = null,
    val safetyRatings: List<SafetyRating>? = null
)

@Serializable
internal data class SafetyRating(val category: String? = null, val probability: String? = null)

@Serializable
internal data class PromptFeedback(@SerialName("blockReason") val blockReason: String? = null)

@Serializable
internal data class UsageMetadata(
    @SerialName("promptTokenCount") val promptTokenCount: Int? = null,
    @SerialName("candidatesTokenCount") val candidatesTokenCount: Int? = null,
    @SerialName("totalTokenCount") val totalTokenCount: Int? = null
)

@Serializable
internal data class GeminiErrorEnvelope(val error: GeminiError? = null)

@Serializable
internal data class GeminiError(val code: Int? = null, val message: String? = null, val status: String? = null)

@Serializable
internal data class GeminiActionPayload(val action: String, val params: Map<String, String>? = null)

data class DialogTurn(val role: String, val text: String) {
    init { require(role == "user" || role == "model") { "role must be user|model" } }
}
