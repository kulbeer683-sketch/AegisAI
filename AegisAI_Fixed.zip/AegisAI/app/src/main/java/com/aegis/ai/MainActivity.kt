package com.aegis.ai

import android.Manifest
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aegis.ai.service.AegisForegroundService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var commandInput: EditText

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val denied = result.filterValues { !it }.keys
        status.text = if (denied.isEmpty())
            "Permissions granted"
        else "Denied: " + denied.joinToString { it.substringAfterLast('.') }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ViewGroup {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
            setBackgroundColor(Color.parseColor("#000000"))
        }

        root.addView(TextView(this).apply {
            text = "AEGIS AI"
            setTextColor(Color.parseColor("#2FE6A8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.15f
        })

        root.addView(TextView(this).apply {
            text = "v1.0 · on-device assistant"
            setTextColor(Color.parseColor("#8A9AAB"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, dp(4), 0, dp(24))
        })

        status = TextView(this).apply {
            text = "Idle"
            setTextColor(Color.parseColor("#E7EEF5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, 0, 0, dp(16))
        }
        root.addView(status)

        root.addView(makeButton("Grant Permissions") {
            permissionsLauncher.launch(arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.MODIFY_AUDIO_SETTINGS,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.CAMERA,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.POST_NOTIFICATIONS
            ))
        })

        root.addView(makeButton("Start Aegis") {
            ContextCompat.startForegroundService(this, AegisForegroundService.startIntent(this))
            status.text = "Aegis starting…"
        })

        root.addView(makeButton("Stop Aegis") {
            startService(AegisForegroundService.stopIntent(this))
            status.text = "Aegis stopped"
        })

        commandInput = EditText(this).apply {
            hint = "Type a command (torch on, volume 50, battery…)"
            setTextColor(Color.parseColor("#E7EEF5"))
            setHintTextColor(Color.parseColor("#5A6A7B"))
            setBackgroundColor(Color.parseColor("#0A0D12"))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(8), 0, dp(8)) }
        }
        root.addView(commandInput)

        root.addView(makeButton("Send Command") {
            val text = commandInput.text?.toString().orEmpty().trim()
            if (text.isEmpty()) return@makeButton
            startService(AegisForegroundService.textIntent(this, text))
            status.text = "Sent: " + text
            commandInput.text?.clear()
        })

        root.addView(makeButton("System Diagnostics") {
            ContextCompat.startForegroundService(this, AegisForegroundService.selfCheckIntent(this))
            status.text = "Diagnostics requested"
        })

        root.addView(TextView(this).apply {
            text = "Tip: enable Accessibility for Aegis in Settings → Accessibility."
            setTextColor(Color.parseColor("#8A9AAB"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setPadding(0, dp(24), 0, 0)
        })

        return root
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(Color.parseColor("#04140E"))
            setBackgroundColor(Color.parseColor("#2FE6A8"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { setMargins(0, 0, 0, dp(8)) }
            setOnClickListener { action() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
