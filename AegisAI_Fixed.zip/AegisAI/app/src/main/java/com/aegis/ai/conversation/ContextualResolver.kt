package com.aegis.ai.conversation

import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch

class ContextualResolver(private val contextManager: ConversationContextManager) {

    fun resolve(match: IntentMatch): IntentMatch? {
        val n = match.normalizedText.trim()
        if (n.isEmpty()) return null
        val snap = contextManager.current()
        if (snap.turns.isEmpty()) return null
        return tryRepeat(match, n, snap) ?: tryInvert(match, n, snap)
    }

    fun contextBlockForPrompt(): String? {
        val snap = contextManager.current()
        if (snap.turns.isEmpty() && snap.entities == EntityMemory.EMPTY) return null
        return buildString {
            snap.entities.activeContact?.let { append("active_contact: ").append(it).append('\n') }
            snap.entities.lastTargetApp?.let { append("last_target_app: ").append(it).append('\n') }
            snap.entities.lastInspectedVisualEntity?.let { append("last_visual_entity: ").append(it).append('\n') }
            val recent = snap.turns.takeLast(3)
            if (recent.isNotEmpty()) {
                append("recent_turns:\n")
                for (t in recent) {
                    append("- user: ").append(t.userText.take(120)).append('\n')
                    t.assistantText?.let { append("  aegis: ").append(it.take(120)).append('\n') }
                }
            }
        }.trim().takeIf { it.isNotEmpty() }
    }

    private fun tryRepeat(o: IntentMatch, n: String, snap: ConversationSnapshot): IntentMatch? {
        if (!REPEAT.any { n == it || n.startsWith("$it ") }) return null
        val c = snap.turns.asReversed().firstOrNull { it.actions.isNotEmpty() && it.actions.all { a -> a.isFastPath() } } ?: return null
        return o.copy(actions = c.actions, confidence = 1f)
    }

    private fun tryInvert(o: IntentMatch, n: String, snap: ConversationSnapshot): IntentMatch? {
        if (!INVERT.any { n.contains(it) }) return null
        val last = snap.turns.asReversed().firstOrNull { it.actions.isNotEmpty() && it.actions.all { a -> a.isFastPath() } } ?: return null
        val inv = last.actions.mapNotNull { invert(it) }
        if (inv.isEmpty()) return null
        return o.copy(actions = inv, confidence = 1f)
    }

    private fun invert(a: AegisAction): AegisAction? = when (a) {
        AegisAction.TorchOn -> AegisAction.TorchOff
        AegisAction.TorchOff -> AegisAction.TorchOn
        AegisAction.BluetoothOn -> AegisAction.BluetoothOff
        AegisAction.BluetoothOff -> AegisAction.BluetoothOn
        AegisAction.WifiOn -> AegisAction.WifiOff
        AegisAction.WifiOff -> AegisAction.WifiOn
        AegisAction.MediaPlay -> AegisAction.MediaPause
        AegisAction.MediaPause -> AegisAction.MediaPlay
        is AegisAction.VolumeSet -> AegisAction.VolumeMute(a.stream, mute = true)
        is AegisAction.VolumeAdjust -> AegisAction.VolumeMute(a.stream, mute = true)
        is AegisAction.VolumeMute -> AegisAction.VolumeMute(a.stream, mute = false)
        else -> null
    }

    private companion object {
        val REPEAT = setOf("again", "repeat", "repeat that", "do that again", "same thing", "phir se", "dubara", "fir se", "फिर से", "दुबारा")
        val INVERT = setOf("stop it", "turn it off", "switch it off", "band karo", "use band karo", "इसे बंद करो", "बंद करो")
    }
}
