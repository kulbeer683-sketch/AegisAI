package com.aegis.ai.memory.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.aegis.ai.memory.entity.KnowledgeMemoryEntity

@Dao
interface KnowledgeMemoryDao {
    @Query("SELECT * FROM knowledge_memory ORDER BY updated_at_ms DESC")
    suspend fun loadAll(): List<KnowledgeMemoryEntity>

    @Query("SELECT * FROM knowledge_memory WHERE key = :key LIMIT 1")
    suspend fun findByKey(key: String): KnowledgeMemoryEntity?

    @Query("""
        SELECT * FROM knowledge_memory
        WHERE key LIKE '%' || :needle || '%'
           OR display_key LIKE '%' || :needle || '%'
           OR value LIKE '%' || :needle || '%'
        ORDER BY hit_count DESC, updated_at_ms DESC LIMIT :limit
    """)
    suspend fun search(needle: String, limit: Int): List<KnowledgeMemoryEntity>

    @Query("SELECT * FROM knowledge_memory ORDER BY hit_count DESC, updated_at_ms DESC LIMIT :limit")
    suspend fun topByHits(limit: Int): List<KnowledgeMemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: KnowledgeMemoryEntity): Long

    @Query("DELETE FROM knowledge_memory WHERE key LIKE '%' || :needle || '%'")
    suspend fun deleteByKeyPattern(needle: String): Int

    @Query("UPDATE knowledge_memory SET hit_count = hit_count + 1, updated_at_ms = :nowMs WHERE key = :key")
    suspend fun bumpHitCount(key: String, nowMs: Long): Int

    @Query("DELETE FROM knowledge_memory")
    suspend fun clear()
}
