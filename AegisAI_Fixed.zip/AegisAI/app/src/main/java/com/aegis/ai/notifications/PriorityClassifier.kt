package com.aegis.ai.notifications

import android.app.Notification
import android.service.notification.StatusBarNotification

object PriorityClassifier {

    private val MESSAGING = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
        "com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging",
        "com.facebook.orca", "com.instagram.android", "com.google.android.apps.dynamite",
        "com.signal", "org.thoughtcrime.securesms", "com.viber.voip", "com.skype.raider"
    )
    private val BANKING = setOf(
        "com.google.android.apps.nbu.paisa.user", "com.phonepe.app", "net.one97.paytm",
        "com.sbi.lotusintouch", "com.icicibank.imobile", "com.hdfcbank.mobilebanking",
        "com.axis.mobile", "com.kotak.mahindrabank"
    )
    private val CALENDAR = setOf("com.google.android.calendar", "com.android.calendar", "com.samsung.android.calendar")
    private val BANK_KW = listOf("debited", "credited", "spent on", "transaction", "upi", "rs.", "₹", "balance is")
    private val OTP_KW = listOf("otp", "one time password", "verification code", "code is", "सत्यापन कोड", "ओटीपी")

    private val LOW_CATEGORIES = setOf(
        Notification.CATEGORY_PROMO, Notification.CATEGORY_SOCIAL, Notification.CATEGORY_PROGRESS,
        Notification.CATEGORY_SERVICE, Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_SYSTEM,
        Notification.CATEGORY_RECOMMENDATION, Notification.CATEGORY_STATUS
    )

    data class Verdict(val priority: NotificationPriority, val category: NotificationCategory)

    fun classify(sbn: StatusBarNotification): Verdict {
        val pkg = sbn.packageName ?: ""
        val n = sbn.notification ?: return Verdict(NotificationPriority.LOW, NotificationCategory.OTHER)

        n.category?.let { if (it in LOW_CATEGORIES) return Verdict(NotificationPriority.LOW, NotificationCategory.OTHER) }

        val ex = n.extras ?: return Verdict(NotificationPriority.LOW, NotificationCategory.OTHER)
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()?.take(120)
        val body = (ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim()?.take(400)

        val hay = (title.orEmpty() + " " + body.orEmpty()).lowercase()
        if (OTP_KW.any { hay.contains(it) } && containsShortNumeric(hay)) return Verdict(NotificationPriority.HIGH, NotificationCategory.OTP)
        if (pkg in BANKING || hasBankKeyword(pkg) || BANK_KW.any { hay.contains(it) }) return Verdict(NotificationPriority.HIGH, NotificationCategory.BANKING)
        if (pkg in MESSAGING || n.category == Notification.CATEGORY_MESSAGE || n.category == Notification.CATEGORY_EMAIL) return Verdict(NotificationPriority.HIGH, NotificationCategory.MESSAGING)
        if (pkg in CALENDAR || n.category == Notification.CATEGORY_EVENT || n.category == Notification.CATEGORY_REMINDER) return Verdict(NotificationPriority.HIGH, NotificationCategory.CALENDAR)
        if (n.category == Notification.CATEGORY_CALL || n.category == Notification.CATEGORY_MISSED_CALL) return Verdict(NotificationPriority.HIGH, NotificationCategory.CALL)
        return Verdict(NotificationPriority.LOW, NotificationCategory.OTHER)
    }

    private fun containsShortNumeric(text: String): Boolean {
        var s = -1
        for (i in text.indices) {
            val d = text[i].isDigit()
            if (d && s < 0) s = i
            else if (!d && s >= 0) {
                val len = i - s
                if (len in 4..8) return true
                s = -1
            }
        }
        if (s >= 0 && text.length - s in 4..8) return true
        return false
    }

    private fun hasBankKeyword(pkg: String): Boolean {
        val l = pkg.lowercase()
        return l.contains(".bank") || l.contains("banking") || l.contains(".pay") || l.contains("wallet") || l.contains("upi")
    }
}
