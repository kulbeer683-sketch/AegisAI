package com.aegis.ai.routine

enum class TimeSlot { MORNING, WORK, EVENING, NIGHT }
enum class PowerState { AC_CONNECTED, WIRELESS_CHARGING, UNPLUGGED, CRITICAL_BATTERY }
enum class AudioState { NO_HEADSET, WIRED_HEADSET, BLUETOOTH_SCO, USB_HEADSET }
enum class RoutineKind { BEDTIME, MORNING_BRIEF, BATTERY_PROTECTION }

data class TriggerSnapshot(
    val timeSlot: TimeSlot, val powerState: PowerState, val audioState: AudioState,
    val batteryPercent: Int, val charging: Boolean, val timestampMs: Long
)

data class TriggerEvent(val kind: RoutineKind, val snapshot: TriggerSnapshot, val reason: String)
