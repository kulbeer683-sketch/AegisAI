package com.aegis.ai.wakeword

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class WakeTonePlayer(context: Context) : AutoCloseable {

    private val appContext = context.applicationContext

    private val pool: SoundPool = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
    } else {
        @Suppress("DEPRECATION") SoundPool(1, AudioManager.STREAM_NOTIFICATION, 0)
    }

    private val mutex = Mutex()
    private val closed = AtomicBoolean(false)
    @Volatile private var sampleId = 0
    @Volatile private var loaded = false
    private val latch = CountDownLatch(1)

    init {
        pool.setOnLoadCompleteListener { _, _, status ->
            loaded = status == 0
            latch.countDown()
        }
        runCatching {
            val f = ensureToneFile()
            if (f != null) sampleId = pool.load(f.absolutePath, 1)
        }
    }

    suspend fun play(volume: Float = 1.0f): Boolean = mutex.withLock {
        if (closed.get()) return@withLock false
        if (sampleId == 0) return@withLock false
        if (!loaded) {
            val deadline = android.os.SystemClock.elapsedRealtime() + 1_000L
            while (!loaded && android.os.SystemClock.elapsedRealtime() < deadline) {
                kotlinx.coroutines.delay(10L)
            }
        }
        if (!loaded) return@withLock false
        return try {
            val sid = pool.play(sampleId, volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f), 1, 0, 1.0f)
            sid != 0
        } catch (_: Throwable) { false }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        runCatching { pool.release() }
        deleteToneFile()
    }

    private fun ensureToneFile(): File? {
        val dir = File(appContext.cacheDir, "wake")
        if (!dir.exists() && !dir.mkdirs()) return null
        val f = File(dir, "aegis_wake.wav")
        if (f.exists() && f.length() > 1_000) return f
        val pcm = synthesize()
        val wav = wrapWav(pcm)
        return try { FileOutputStream(f).use { it.write(wav) }; f } catch (_: Throwable) { null }
    }

    private fun synthesize(): ShortArray {
        val sr = 16_000
        val total = sr * 180 / 1_000
        val out = ShortArray(total)
        val half = total / 2
        for (i in 0 until total) {
            val t = i.toDouble() / sr.toDouble()
            val freq = if (i < half) 880.0 else 1320.0
            val phase = 2.0 * PI * freq * t
            val attack = if (i < sr * 8 / 1_000) i.toDouble() / (sr * 8 / 1_000) else 1.0
            val seg = if (i < half) i.toDouble() / half else (i - half).toDouble() / (total - half)
            val release = exp(-3.5 * seg)
            out[i] = (sin(phase) * attack * release * 0.55 * Short.MAX_VALUE).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return out
    }

    private fun wrapWav(pcm: ShortArray): ByteArray {
        val data = pcm.size * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray()); putInt(36 + data); put("WAVE".toByteArray())
            put("fmt ".toByteArray()); putInt(16); putShort(1); putShort(1)
            putInt(16_000); putInt(16_000 * 2); putShort(2); putShort(16)
            put("data".toByteArray()); putInt(data)
        }
        val body = ByteBuffer.allocate(data).order(ByteOrder.LITTLE_ENDIAN).apply { for (s in pcm) putShort(s) }
        return header.array() + body.array()
    }

    private fun deleteToneFile() { runCatching { File(File(appContext.cacheDir, "wake"), "aegis_wake.wav").delete() } }

    private companion object { const val TAG = AudioConfig.TAG }
}
