package com.aegis.ai.privacy

import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.conversation.ConversationContextManager
import com.aegis.ai.memory.LongTermMemoryManager
import com.aegis.ai.security.SecureKeyStorage
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MemoryWipeManager(
    context: Context,
    private val memory: LongTermMemoryManager,
    private val conversation: ConversationContextManager
) {
    @Suppress("unused")
    private val appContext = context.applicationContext
    private val secureKeys = SecureKeyStorage(appContext)
    private val mutex = Mutex()

    @Volatile private var pendingAt = 0L

    fun requestConfirmation(): Boolean {
        val now = SystemClock.elapsedRealtime()
        val prev = pendingAt
        if (prev > 0L && now - prev < TTL) return false
        pendingAt = now
        return true
    }

    fun isConfirmationPending(): Boolean {
        val at = pendingAt
        if (at == 0L) return false
        if (SystemClock.elapsedRealtime() - at > TTL) { pendingAt = 0L; return false }
        return true
    }

    suspend fun handleResponse(text: String): WipeOutcome {
        if (!isConfirmationPending()) return WipeOutcome.NoPendingRequest
        val n = text.trim().lowercase()
        val yes = YES.any { n == it || n.startsWith("$it ") }
        val no = NO.any { n == it || n.startsWith("$it ") }
        if (no || !yes) { pendingAt = 0L; return WipeOutcome.Cancelled }
        pendingAt = 0L
        return wipe()
    }

    fun cancelPending() { pendingAt = 0L }

    suspend fun wipe(): WipeOutcome = mutex.withLock {
        val t0 = SystemClock.elapsedRealtime()
        val errors = mutableListOf<String>()
        runCatching { memory.forgetAll() }.onFailure { errors += "memory: ${it.message}" }
        runCatching { conversation.clear() }.onFailure { errors += "conversation: ${it.message}" }
        runCatching { secureKeys.clearGeminiApiKey() }.onFailure { errors += "gemini: ${it.message}" }
        val elapsed = SystemClock.elapsedRealtime() - t0
        Log.w(AudioConfig.TAG, "Wipe done in ${elapsed}ms errors=$errors")
        if (errors.isEmpty()) WipeOutcome.Success(elapsed) else WipeOutcome.Partial(elapsed, errors)
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val TTL = 12_000L
        private val YES = setOf("yes", "confirm", "do it", "haan", "han", "ha", "ok", "okay", "हाँ", "हाँ")
        private val NO = setOf("no", "cancel", "stop", "nahi", "na", "नहीं", "ना")
    }
}
