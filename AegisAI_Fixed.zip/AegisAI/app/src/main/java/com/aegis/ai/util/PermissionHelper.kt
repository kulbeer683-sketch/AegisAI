package com.aegis.ai.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object PermissionHelper {

    const val REQUEST_CODE_RUNTIME = 0x4A31

    fun requiredRuntimePermissions(): Array<String> {
        val p = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.MODIFY_AUDIO_SETTINGS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CONTACTS,
            Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) p += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { p += Manifest.permission.POST_NOTIFICATIONS; p += Manifest.permission.NEARBY_WIFI_DEVICES }
        return p.toTypedArray()
    }

    fun missingRuntimePermissions(context: Context): List<String> =
        requiredRuntimePermissions().filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }

    fun hasAllRuntimePermissions(context: Context) = missingRuntimePermissions(context).isEmpty()

    fun requestRuntimePermissions(activity: Activity) {
        ActivityCompat.requestPermissions(activity, missingRuntimePermissions(activity).toTypedArray(), REQUEST_CODE_RUNTIME)
    }

    fun isAccessibilityServiceEnabled(context: Context, serviceClass: Class<*>): Boolean {
        val expected = "${context.packageName}/${serviceClass.name}"
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, true) }
    }

    fun openAccessibilitySettings(context: Context) { runCatching { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    fun openOverlaySettings(context: Context) { com.aegis.ai.overlay.OverlayPermissionHelper.openOverlaySettings(context) }
    fun canDrawOverlays(context: Context) = com.aegis.ai.overlay.OverlayPermissionHelper.canDrawOverlays(context)
    fun openNotificationAccessSettings(context: Context) { runCatching { context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    fun openAppDetailsSettings(context: Context) { runCatching { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    fun hasDndAccess(context: Context) = runCatching { (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).isNotificationPolicyAccessGranted }.getOrDefault(false)
    fun hasWriteSettingsAccess(context: Context) = runCatching { Settings.System.canWrite(context) }.getOrDefault(false)
    fun isIgnoringBatteryOptimizations(context: Context) = runCatching { (context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(context.packageName) }.getOrDefault(false)
    fun requestIgnoreBatteryOptimizations(context: Context) {
        runCatching { context.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.fromParts("package", context.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
