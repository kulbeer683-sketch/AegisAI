package com.aegis.ai

import android.app.Application
import android.util.Log

class AegisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        installCrashTrap()
        Log.i(TAG, "Aegis AI booting v" + BuildConfig.VERSION_NAME)
    }
    private fun installCrashTrap() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            Log.e(TAG, "Uncaught on " + t.name, e)
            prev?.uncaughtException(t, e)
        }
    }
    companion object { const val TAG = "AegisAudio" }
}
