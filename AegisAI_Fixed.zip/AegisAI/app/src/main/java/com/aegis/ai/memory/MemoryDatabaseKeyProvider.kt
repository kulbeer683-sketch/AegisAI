package com.aegis.ai.memory

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.aegis.ai.audio.AudioConfig
import java.security.SecureRandom

class MemoryDatabaseKeyProvider(context: Context) {

    private val prefs: SharedPreferences? = try {
        val mk = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context.applicationContext, PREFS_FILE, mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (t: Throwable) { Log.e(TAG, "EncryptedSharedPreferences init failed", t); null }

    fun getOrCreatePassphrase(): ByteArray {
        val p = prefs ?: return volatileFallback ?: ByteArray(LEN).also {
            SecureRandom().nextBytes(it); volatileFallback = it
        }
        val existing = p.getString(KEY_PASS, null)
        if (existing != null) return runCatching { Base64.decode(existing, Base64.NO_WRAP) }
            .getOrElse { generateAndStore(p) }
        return generateAndStore(p)
    }

    fun clearPassphrase() { runCatching { prefs?.edit()?.remove(KEY_PASS)?.apply() } }

    private fun generateAndStore(p: SharedPreferences): ByteArray {
        val fresh = ByteArray(LEN); SecureRandom().nextBytes(fresh)
        runCatching { p.edit().putString(KEY_PASS, Base64.encodeToString(fresh, Base64.NO_WRAP)).apply() }
        return fresh
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val PREFS_FILE = "aegis_memory_key"
        private const val KEY_PASS = "sqlcipher_passphrase_v1"
        private const val LEN = 32

        @Volatile private var volatileFallback: ByteArray? = null
    }
}
