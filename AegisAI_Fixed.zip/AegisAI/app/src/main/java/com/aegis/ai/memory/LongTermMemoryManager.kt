package com.aegis.ai.memory

import android.content.Context
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

class LongTermMemoryManager(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("aegis_memory", Context.MODE_PRIVATE)
    private val mutex = Mutex()
    private val cache = ConcurrentHashMap<String, String>()

    init { loadFromDisk() }

    private fun loadFromDisk() {
        runCatching {
            prefs.all.forEach { (k, v) ->
                if (k.startsWith("fact_") && v is String) cache[k.removePrefix("fact_")] = v
            }
        }
    }

    suspend fun rememberFact(key: String, value: String): Boolean {
        val k = normalize(key)
        if (k.isBlank() || value.isBlank()) return false
        return mutex.withLock {
            cache[k] = value.trim()
            runCatching { prefs.edit().putString("fact_$k", value.trim()).apply() }
            Log.i(AudioConfig.TAG, "Remembered: $k")
            true
        }
    }

    fun lookup(key: String): String? = cache[normalize(key)]
    fun factCount(): Int = cache.size
    fun allFacts(): Map<String, String> = HashMap(cache)

    suspend fun forgetAll(): Int = mutex.withLock {
        val n = cache.size
        cache.clear()
        runCatching { prefs.edit().clear().apply() }
        n
    }

    private fun normalize(k: String) = k.trim().lowercase().replace(Regex("\\s+"), " ")

    companion object {
        private const val TAG = AudioConfig.TAG
    }
}
