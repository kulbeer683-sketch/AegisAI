package com.aegis.ai.media

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.aegis.ai.audio.AudioConfig

open class AegisNotificationListenerService : NotificationListenerService() {

    @Volatile private var mediaCount = 0

    open override fun onListenerConnected() {
        super.onListenerConnected()
        boundInstance = this
        refreshMediaCount()
    }

    open override fun onListenerDisconnected() {
        if (boundInstance === this) boundInstance = null
        super.onListenerDisconnected()
    }

    open override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (isMedia(sbn)) refreshMediaCount()
    }

    open override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (isMedia(sbn)) refreshMediaCount()
    }

    private fun isMedia(sbn: StatusBarNotification): Boolean {
        val n: Notification = sbn.notification ?: return false
        return try {
            if (n.category == Notification.CATEGORY_TRANSPORT) return true
            n.extras?.containsKey(Notification.EXTRA_MEDIA_SESSION) == true
        } catch (_: Throwable) { false }
    }

    private fun refreshMediaCount() {
        mediaCount = runCatching { activeNotifications?.count { isMedia(it) } ?: 0 }.getOrDefault(0)
    }

    companion object {
        private const val TAG = AudioConfig.TAG

        @Volatile private var boundInstance: AegisNotificationListenerService? = null

        fun get(): AegisNotificationListenerService? = boundInstance
        fun componentNameOrNull(): ComponentName? = boundInstance?.componentName
        fun isConnected(): Boolean = boundInstance != null
    }
}
