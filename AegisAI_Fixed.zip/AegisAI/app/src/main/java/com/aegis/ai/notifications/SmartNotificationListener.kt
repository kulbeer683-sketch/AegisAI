package com.aegis.ai.notifications

import android.app.Notification
import android.os.SystemClock
import android.service.notification.StatusBarNotification
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.media.AegisNotificationListenerService
import java.util.concurrent.atomic.AtomicReference

class SmartNotificationListener : AegisNotificationListenerService() {

    private val cache = AtomicReference<List<CachedNotification>>(emptyList())

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        cache.set(emptyList())
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        cache.set(emptyList())
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        val s = sbn ?: return
        runCatching {
            val v = PriorityClassifier.classify(s)
            if (v.priority != NotificationPriority.HIGH) return
            val c = extract(s, v) ?: return
            addOrReplace(c)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        val s = sbn ?: return
        removeByKey(s.key ?: return)
    }

    fun recentHighPriority(): List<CachedNotification> = cache.get()
    fun latestReplyable(): CachedNotification? = cache.get().asReversed().firstOrNull { it.hasReplyAction }
    fun findByKey(key: String): CachedNotification? = cache.get().firstOrNull { it.key == key }

    fun markDigested(keys: Collection<String>) {
        if (keys.isEmpty()) return
        val set = keys.toHashSet()
        val updated = cache.get().map { if (it.key in set) it.copy(digested = true) else it }
        cache.set(updated)
    }

    fun clearCache() { cache.set(emptyList()) }

    private fun addOrReplace(e: CachedNotification) {
        while (true) {
            val cur = cache.get()
            val filtered = cur.filter { it.key != e.key }
            val app = filtered + e
            val trim = if (app.size > MAX_CACHED) app.subList(app.size - MAX_CACHED, app.size) else app
            if (cache.compareAndSet(cur, trim)) return
        }
    }

    private fun removeByKey(key: String) {
        while (true) {
            val cur = cache.get()
            val filtered = cur.filter { it.key != key }
            if (filtered.size == cur.size) return
            if (cache.compareAndSet(cur, filtered)) return
        }
    }

    private fun extract(sbn: StatusBarNotification, v: PriorityClassifier.Verdict): CachedNotification? {
        val n = sbn.notification ?: return null
        val ex = n.extras ?: return null
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()?.take(120)
        val body = (ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim()?.take(300)
        val hasReply = n.actions?.any { !it.remoteInputs.isNullOrEmpty() } == true
        val sender = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim()?.take(120) ?: title
        return CachedNotification(sbn.key ?: return null, sbn.packageName ?: "unknown", v.category, v.priority, sender, title, body, hasReply, SystemClock.elapsedRealtime())
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val MAX_CACHED = 15

        @Volatile private var instance: SmartNotificationListener? = null
        fun get(): SmartNotificationListener? = instance
        fun isConnected(): Boolean = instance != null
    }
}
