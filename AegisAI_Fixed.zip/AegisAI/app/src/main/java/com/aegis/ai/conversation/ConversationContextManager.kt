package com.aegis.ai.conversation

import android.os.SystemClock
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class ConversationContextManager {

    private val mutex = Mutex()
    private val ref = AtomicReference(ConversationSnapshot.EMPTY)
    private val counter = AtomicLong(0L)

    fun current(): ConversationSnapshot {
        val raw = ref.get()
        if (raw.lastActivityMs == 0L) return ConversationSnapshot.EMPTY
        val now = SystemClock.elapsedRealtime()
        return if (now - raw.lastActivityMs > EXPIRY) ConversationSnapshot.EMPTY else raw
    }

    fun pendingAction(): PendingAction? = current().entities.pendingAction

    suspend fun recordTurn(
        userText: String, assistantText: String?, actions: List<AegisAction>,
        language: IntentMatch.Language = IntentMatch.Language.ENGLISH
    ) = mutex.withLock {
        val now = SystemClock.elapsedRealtime()
        val base = live(now)
        val t = ConversationTurn(
            counter.incrementAndGet(), userText.trim(),
            assistantText?.trim()?.takeIf { it.isNotEmpty() },
            actions, now, language
        )
        ref.set(base.copy(turns = (base.turns + t).takeLast(MAX_TURNS), lastActivityMs = now))
    }

    suspend fun setPendingAction(p: PendingAction?) = mutex.withLock {
        val now = SystemClock.elapsedRealtime()
        val base = live(now)
        ref.set(base.copy(entities = base.entities.copy(pendingAction = p), lastActivityMs = now))
    }

    suspend fun setActiveContact(c: String?) = mutex.withLock {
        val now = SystemClock.elapsedRealtime()
        val base = live(now)
        ref.set(base.copy(entities = base.entities.copy(activeContact = c), lastActivityMs = now))
    }

    suspend fun clear() = mutex.withLock { ref.set(ConversationSnapshot.EMPTY); counter.set(0L) }

    private fun live(now: Long): ConversationSnapshot {
        val raw = ref.get()
        if (raw.lastActivityMs == 0L) return ConversationSnapshot.EMPTY
        return if (now - raw.lastActivityMs > EXPIRY) ConversationSnapshot.EMPTY else raw
    }

    companion object {
        const val MAX_TURNS = 6
        const val EXPIRY = 60_000L
    }
}
