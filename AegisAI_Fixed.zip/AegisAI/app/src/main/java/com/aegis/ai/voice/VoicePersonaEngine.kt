package com.aegis.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import java.util.Locale

class VoicePersonaEngine(
    context: Context,
    private val preferences: VoicePersonaPreferences
) {

    private val appContext = context.applicationContext

    fun getPitch(): Float = preferences.getPitch()
    fun getRate(): Float = preferences.getRate()
    fun adjustPitch(delta: Float): Float = preferences.adjustPitch(delta)
    fun adjustRate(delta: Float): Float = preferences.adjustRate(delta)
    fun resetToDefaults() = preferences.resetPitchAndRate()

    fun targetLocaleFor(text: String): Locale {
        val dev = text.any { it.code in 0x0900..0x097F }
        return if (dev) Locale("hi", "IN") else Locale("en", "IN")
    }

    fun applyTo(tts: TextToSpeech, utteranceText: String): Boolean {
        val target = targetLocaleFor(utteranceText)
        val cur = runCatching { tts.voice?.locale }.getOrNull()
        if (cur?.language != target.language) {
            val r = runCatching { tts.setLanguage(target) }.getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                runCatching { tts.setLanguage(Locale.getDefault()) }
            }
        }

        var ok = true
        val pitch = preferences.getPitch()
        if (runCatching { tts.pitch }.getOrDefault(-1f) != pitch) {
            val r = runCatching { tts.setPitch(pitch) }.getOrDefault(TextToSpeech.ERROR)
            if (r != TextToSpeech.SUCCESS) ok = false
        }
        val rate = preferences.getRate()
        if (runCatching { tts.speechRate }.getOrDefault(-1f) != rate) {
            val r = runCatching { tts.setSpeechRate(rate) }.getOrDefault(TextToSpeech.ERROR)
            if (r != TextToSpeech.SUCCESS) ok = false
        }
        applyVoiceSelection(tts, target)
        return ok
    }

    fun currentVoiceName(tts: TextToSpeech): String? = runCatching { tts.voice?.name }.getOrNull()

    fun pickBestVoice(voices: Set<Voice>, target: Locale): Voice? {
        if (voices.isEmpty()) return null
        val exact = voices.filter { it.locale == target }
        val byLang = voices.filter { it.locale.language == target.language }
        val pool = when {
            exact.isNotEmpty() -> exact
            byLang.isNotEmpty() -> byLang
            else -> voices.toList()
        }
        return pool.sortedWith(
            compareByDescending<Voice> { it.quality }
                .thenByDescending { !it.isNetworkConnectionRequired }
                .thenBy { it.latency }
                .thenBy { it.name }
        ).firstOrNull()
    }

    private fun applyVoiceSelection(tts: TextToSpeech, target: Locale): Boolean {
        val voices = runCatching { tts.voices }.getOrNull() ?: return false
        if (voices.isEmpty()) return false
        val tag = target.toLanguageTag()
        val persisted = preferences.getPreferredVoiceName(tag)

        if (persisted != null) {
            val v = voices.firstOrNull { it.name == persisted }
            if (v != null) {
                val cur = runCatching { tts.voice }.getOrNull()
                if (cur?.name == v.name) return true
                runCatching { tts.voice = v }.onSuccess { return true }
            }
        }

        val best = pickBestVoice(voices, target) ?: return false
        return runCatching {
            val cur = runCatching { tts.voice }.getOrNull()
            if (cur?.name != best.name) tts.voice = best
            preferences.setPreferredVoiceName(tag, best.name)
            true
        }.getOrDefault(false)
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val TEST_PHRASE_HINDI = "नमस्ते, मैं एजिस हूँ। यह मेरी आवाज़ का परीक्षण है।"
        const val TEST_PHRASE_ENGLISH = "Hello, I am Aegis. This is a voice test."
    }
}
