package com.aegis.ai.audio

import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

class VoiceActivityDetector(
    private val frameSize: Int,
    private val thresholdDb: Double = 6.0,
    private val hangoverFrames: Int = 10
) {
    data class VadResult(
        val isSpeech: Boolean,
        val rmsDbfs: Double,
        val noiseFloorDbfs: Double,
        val zcr: Double,
        val snrDb: Double
    )

    private var noiseFloorRms = 0.0
    private var initialized = false
    private var hangover = 0

    fun process(frame: ShortArray): VadResult {
        require(frame.size == frameSize)
        var sum = 0.0
        var zc = 0
        var prev = frame[0] >= 0
        for (i in frame.indices) {
            val v = frame[i].toInt()
            val d = v.toDouble()
            sum += d * d
            if (i > 0) {
                val sign = v >= 0
                if (sign != prev) zc++
                prev = sign
            }
        }
        val rms = sqrt(sum / frameSize.toDouble())
        val zcr = zc.toDouble() / (frameSize - 1).toDouble()

        if (!initialized) { noiseFloorRms = rms.coerceAtLeast(1.0); initialized = true }
        else if (rms < noiseFloorRms) noiseFloorRms = 0.9 * noiseFloorRms + 0.1 * rms
        else noiseFloorRms = 0.999 * noiseFloorRms + 0.001 * rms
        noiseFloorRms = noiseFloorRms.coerceAtLeast(1.0)

        val thresh = noiseFloorRms * 10.0.pow(thresholdDb / 20.0)
        var speech = rms > thresh && zcr < 0.45
        if (speech) hangover = hangoverFrames
        else if (hangover > 0) { hangover--; speech = true }

        val rmsDbfs = 20.0 * log10(rms / 32768.0 + 1e-9)
        val nfDbfs = 20.0 * log10(noiseFloorRms / 32768.0 + 1e-9)
        return VadResult(speech, rmsDbfs, nfDbfs, zcr, rmsDbfs - nfDbfs)
    }

    fun reset() { noiseFloorRms = 0.0; initialized = false; hangover = 0 }
}
