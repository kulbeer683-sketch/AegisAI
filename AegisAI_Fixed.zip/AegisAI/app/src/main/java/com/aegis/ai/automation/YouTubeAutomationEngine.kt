package com.aegis.ai.automation

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.service.AegisAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

class YouTubeAutomationEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val accessibilityProvider: () -> AegisAccessibilityService?,
    private val inEar: InEarNotificationManager?,
    private val watchdog: com.aegis.ai.recovery.UiWatchdogSupervisor? = null
) {

    private val appContext = context.applicationContext
    private val mutex = Mutex()

    sealed class YouTubeResult {
        data class Success(val verified: Boolean) : YouTubeResult()
        data object NotInstalled : YouTubeResult()
        data object AccessibilityUnavailable : YouTubeResult()
        data class NodeTimeout(val phase: String, val timeoutMs: Long) : YouTubeResult()
        data class SearchFailed(val reason: String) : YouTubeResult()
        data class PlaybackFailed(val reason: String) : YouTubeResult()
        data class Error(val message: String?) : YouTubeResult()
    }

    suspend fun playVideo(query: String, language: IntentMatch.Language = IntentMatch.Language.ENGLISH, announce: Boolean = true): YouTubeResult =
        mutex.withLock {
            Log.i(TAG, "YouTube start query='$query'")
            val pkg = pickPackage() ?: run { if (announce) announce(YouTubeResult.NotInstalled, language); return@withLock YouTubeResult.NotInstalled }
            val svc = accessibilityProvider() ?: run { if (announce) announce(YouTubeResult.AccessibilityUnavailable, language); return@withLock YouTubeResult.AccessibilityUnavailable }

            val result = try { runPhases(svc, pkg, query) }
            catch (ce: CancellationException) { throw ce }
            catch (t: Throwable) { YouTubeResult.Error(t.message) }

            if (announce) announce(result, language)
            result
        }

    fun playVideoAsync(query: String, language: IntentMatch.Language = IntentMatch.Language.ENGLISH, announce: Boolean = true): Job =
        scope.launch { playVideo(query, language, announce) }

    private sealed class PhaseResult {
        data object Ok : PhaseResult()
        data class Timeout(val phase: String, val ms: Long) : PhaseResult()
        data class Fail(val reason: YouTubeResult) : PhaseResult()
    }

    private suspend fun runPhases(svc: AegisAccessibilityService, pkg: String, query: String): YouTubeResult {
        val sessionId = watchdog?.startSession("yt:$query", "launch")
        try {
            if (!launchSearch(pkg, query)) { if (!launchMain(pkg)) return YouTubeResult.Error("Launch failed") }
            watchdog?.beginPhase(sessionId ?: "", "wait-fg")
            if (!awaitForeground(pkg, 5000L)) return YouTubeResult.NodeTimeout("wait-for-foreground", 5000L)
            delay(400L); coroutineContext.ensureActive()

            watchdog?.beginPhase(sessionId ?: "", "search")
            when (val c = ensureQuery(svc, query)) {
                is PhaseResult.Ok -> {}
                is PhaseResult.Timeout -> return YouTubeResult.NodeTimeout(c.phase, c.ms)
                is PhaseResult.Fail -> return YouTubeResult.SearchFailed(c.reason.toString())
            }

            watchdog?.beginPhase(sessionId ?: "", "click-video")
            when (val d = clickFirstVideo(svc)) {
                is PhaseResult.Ok -> {}
                is PhaseResult.Timeout -> return YouTubeResult.NodeTimeout(d.phase, d.ms)
                is PhaseResult.Fail -> return YouTubeResult.PlaybackFailed(d.reason.toString())
            }

            watchdog?.beginPhase(sessionId ?: "", "verify")
            val playing = verify(svc)
            return YouTubeResult.Success(playing)
        } finally { sessionId?.let { watchdog?.endSession(it) } }
    }

    private suspend fun launchSearch(pkg: String, query: String): Boolean = withContext(Dispatchers.Main.immediate) {
        try {
            appContext.startActivity(Intent(Intent.ACTION_SEARCH).apply {
                setPackage(pkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(SearchManager.QUERY, query)
                putExtra("query", query)
                putExtra("query_string", query)
            })
            true
        } catch (_: Throwable) { false }
    }

    private suspend fun launchMain(pkg: String): Boolean = withContext(Dispatchers.Main.immediate) {
        try {
            appContext.startActivity(Intent(Intent.ACTION_MAIN).apply {
                setPackage(pkg); addCategory(Intent.CATEGORY_LAUNCHER)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            })
            true
        } catch (_: Throwable) { false }
    }

    private suspend fun awaitForeground(pkg: String, timeoutMs: Long): Boolean {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline) {
            coroutineContext.ensureActive()
            if (accessibilityProvider()?.currentPackage() == pkg) return true
            delay(100L)
        }
        return false
    }

    private suspend fun ensureQuery(svc: AegisAccessibilityService, query: String): PhaseResult {
        val existing = svc.findNode { n -> n.viewIdResourceName in RESULT_IDS }
        if (existing != null) { existing.recycleSafe(); return PhaseResult.Ok }

        val icon = svc.findNode { n -> n.viewIdResourceName in SEARCH_ICON_IDS || (isSearchDesc(n) && n.isEnabled) }
        if (icon != null) { try { svc.clickNode(icon) } finally { icon.recycleSafe() } }

        val input = svc.awaitNode(2500L, 100L) { n -> n.viewIdResourceName in SEARCH_INPUT_IDS || (n.isEditable && n.isFocused) }
            ?: return PhaseResult.Timeout("search-input", 2500L)
        try {
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, query) }
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return PhaseResult.Fail(YouTubeResult.SearchFailed("search rejected"))
        } finally { input.recycleSafe() }

        val submit = svc.findNode { n -> n.viewIdResourceName in SEARCH_SUBMIT_IDS || (n.isClickable && isSubmitDesc(n)) }
        if (submit != null) { try { svc.clickNode(submit) } finally { submit.recycleSafe() } }

        delay(500L)
        return PhaseResult.Ok
    }

    private suspend fun clickFirstVideo(svc: AegisAccessibilityService): PhaseResult {
        val item = svc.awaitNode(4000L, 100L) { n -> isVideoItem(n) }
            ?: return PhaseResult.Timeout("results-grid", 4000L)
        try { if (!svc.clickNode(item)) return PhaseResult.Fail(YouTubeResult.PlaybackFailed("not clickable")) }
        finally { item.recycleSafe() }
        return PhaseResult.Ok
    }

    private suspend fun verify(svc: AegisAccessibilityService): Boolean {
        delay(700L); coroutineContext.ensureActive()
        val p = svc.awaitNode(3500L, 120L) { n -> n.viewIdResourceName in PLAYER_IDS }
        if (p != null) { p.recycleSafe(); return true }
        val c = svc.findNode { n -> n.viewIdResourceName in CONTROL_IDS }
        if (c != null) { c.recycleSafe(); return true }
        return false
    }

    private fun isVideoItem(n: AccessibilityNodeInfo): Boolean {
        val id = n.viewIdResourceName ?: return false
        return id in RESULT_IDS && n.isClickable
    }

    private fun isSearchDesc(n: AccessibilityNodeInfo): Boolean {
        val d = n.contentDescription?.toString()?.lowercase() ?: return false
        return SEARCH_DESCS.any { it in d }
    }

    private fun isSubmitDesc(n: AccessibilityNodeInfo): Boolean {
        val d = n.contentDescription?.toString()?.lowercase() ?: return false
        return SUBMIT_DESCS.any { it in d }
    }

    private fun pickPackage(): String? {
        val pm = appContext.packageManager
        for (pkg in YT_PACKAGES) {
            try { @Suppress("DEPRECATION") pm.getPackageInfo(pkg, 0); return pkg } catch (_: PackageManager.NameNotFoundException) {}
        }
        return null
    }

    private suspend fun announce(r: YouTubeResult, language: IntentMatch.Language) {
        val mgr = inEar ?: return
        val hindi = language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH
        val text = when (r) {
            is YouTubeResult.Success -> if (hindi) "वीडियो चालू कर दिया गया" else "Video playing"
            YouTubeResult.NotInstalled -> if (hindi) "यूट्यूब इंस्टॉल नहीं है" else "YouTube not installed"
            YouTubeResult.AccessibilityUnavailable -> if (hindi) "एक्सेसिबिलिटी सेवा चालू करें" else "Enable accessibility"
            is YouTubeResult.NodeTimeout -> if (hindi) "यूट्यूब ने जवाब नहीं दिया" else "YouTube did not respond"
            is YouTubeResult.SearchFailed -> if (hindi) "खोज नहीं हो सकी" else "Search failed"
            is YouTubeResult.PlaybackFailed -> if (hindi) "वीडियो नहीं चला" else "Playback failed"
            is YouTubeResult.Error -> if (hindi) "कुछ गलत हो गया" else "Something went wrong"
        }
        runCatching { mgr.speak(text) }
    }

    private companion object {
        const val TAG = AudioConfig.TAG
        val YT_PACKAGES = listOf("com.google.android.youtube")
        val SEARCH_ICON_IDS = setOf("com.google.android.youtube:id/menu_search", "com.google.android.youtube:id/search_btn")
        val SEARCH_INPUT_IDS = setOf("com.google.android.youtube:id/search_edit_text", "com.google.android.youtube:id/search_src_text")
        val SEARCH_SUBMIT_IDS = setOf("com.google.android.youtube:id/search_button")
        val RESULT_IDS = setOf("com.google.android.youtube:id/results_list", "com.google.android.youtube:id/compact_video_renderer", "com.google.android.youtube:id/thumbnail", "com.google.android.youtube:id/video_renderer")
        val PLAYER_IDS = setOf("com.google.android.youtube:id/player_view", "com.google.android.youtube:id/watch_player", "com.google.android.youtube:id/surface_view")
        val CONTROL_IDS = setOf("com.google.android.youtube:id/player_controls_container", "com.google.android.youtube:id/controls_layout")
        val SEARCH_DESCS = setOf("search", "खोज")
        val SUBMIT_DESCS = setOf("search", "submit", "go")
    }
}

private fun AccessibilityNodeInfo.recycleSafe() = com.aegis.ai.accessibility.UiNodeResolver.recycleSafe(this)
