package com.aegis.ai.audio

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.SystemClock
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean

class AudioDspPipeline(private val context: Context) {

    data class AudioFrame(
        val pcm: ShortArray,
        val vad: VoiceActivityDetector.VadResult,
        val timestampMs: Long
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is AudioFrame) return false
            return pcm.contentEquals(other.pcm) && vad == other.vad && timestampMs == other.timestampMs
        }
        override fun hashCode(): Int {
            var r = pcm.contentHashCode(); r = 31 * r + vad.hashCode(); r = 31 * r + timestampMs.hashCode(); return r
        }
    }

    enum class State { STOPPED, STARTING, RUNNING, STOPPING, ERROR }

    data class Stats(
        val state: State,
        val sampleRate: Int,
        val frameSize: Int,
        val audioSessionId: Int,
        val noiseSuppressorActive: Boolean,
        val echoCancelerActive: Boolean,
        val framesCaptured: Long,
        val framesWithSpeech: Long
    )

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val hp = BiquadFilter.highPass(AudioConfig.SAMPLE_RATE, AudioConfig.BANDPASS_LOW_HZ)
    private val lp = BiquadFilter.lowPass(AudioConfig.SAMPLE_RATE, AudioConfig.BANDPASS_HIGH_HZ)
    private val vad = VoiceActivityDetector(AudioConfig.FRAME_SIZE)

    private var record: AudioRecord? = null
    private var ns: NoiseSuppressor? = null
    private var aec: AcousticEchoCanceler? = null
    private var sessionId = AudioManager.ERROR

    private val mutex = Mutex()
    private val running = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    private val _frames = MutableSharedFlow<AudioFrame>(
        extraBufferCapacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val frames: SharedFlow<AudioFrame> = _frames.asSharedFlow()

    private val _stats = MutableStateFlow(Stats(State.STOPPED, AudioConfig.SAMPLE_RATE,
        AudioConfig.FRAME_SIZE, AudioManager.ERROR, false, false, 0L, 0L))
    val stats: StateFlow<Stats> = _stats.asStateFlow()

    suspend fun start(preferBluetoothSco: Boolean = false): Boolean = mutex.withLock {
        if (running.get()) return@withLock true
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Log.e(AudioConfig.TAG, "RECORD_AUDIO not granted"); publish(State.ERROR); return@withLock false
        }
        publish(State.STARTING)
        val r = build() ?: run { publish(State.ERROR); return@withLock false }
        sessionId = r.audioSessionId
        attachEffects(sessionId)
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            releaseInternal(); publish(State.ERROR); return@withLock false
        }
        try { r.startRecording() } catch (t: Throwable) {
            Log.e(AudioConfig.TAG, "startRecording failed", t); releaseInternal(); publish(State.ERROR); return@withLock false
        }
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            releaseInternal(); publish(State.ERROR); return@withLock false
        }
        record = r
        hp.reset(); lp.reset(); vad.reset()
        running.set(true)
        job = scope.launch { loop(r) }
        publish(State.RUNNING)
        true
    }

    suspend fun stop() = mutex.withLock {
        if (!running.get() && record == null) return@withLock
        publish(State.STOPPING)
        running.set(false)
        job?.let { it.cancel(); runCatching { it.join() } }
        job = null
        releaseInternal()
        publish(State.STOPPED)
    }

    fun shutdown() {
        running.set(false); job?.cancel(); job = null
        releaseInternal(); scope.coroutineContext[Job]?.cancel()
    }

    private suspend fun loop(r: AudioRecord) {
        val raw = ShortArray(AudioConfig.FRAME_SIZE)
        val filtered = ShortArray(AudioConfig.FRAME_SIZE)
        var captured = 0L; var speech = 0L
        while (running.get() && scope.isActive) {
            val n = try { r.read(raw, 0, raw.size, AudioRecord.READ_BLOCKING) } catch (t: Throwable) { -1 }
            if (n <= 0) {
                if (n == AudioRecord.ERROR_DEAD_OBJECT || n == AudioRecord.ERROR_INVALID_OPERATION) {
                    running.set(false); publish(State.ERROR); return
                }
                continue
            }
            for (i in 0 until n) {
                val s = raw[i].toDouble()
                val a = hp.process(s)
                val b = lp.process(a)
                filtered[i] = b.coerceIn(-32768.0, 32767.0).toInt().toShort()
            }
            val slice = if (n == AudioConfig.FRAME_SIZE) filtered else filtered.copyOf(n)
            val v = vad.process(slice)
            captured++; if (v.isSpeech) speech++
            _frames.tryEmit(AudioFrame(slice, v, SystemClock.elapsedRealtime()))
            if (captured % 250L == 0L) {
                _stats.value = _stats.value.copy(framesCaptured = captured, framesWithSpeech = speech)
            }
        }
        _stats.value = _stats.value.copy(framesCaptured = captured, framesWithSpeech = speech)
    }

    @SuppressLint("MissingPermission")
    private fun build(): AudioRecord? {
        val minBuf = AudioRecord.getMinBufferSize(
            AudioConfig.SAMPLE_RATE, AudioConfig.CHANNEL_MASK, AudioConfig.ENCODING)
        if (minBuf <= 0) return null
        return try {
            AudioRecord.Builder()
                .setAudioSource(AudioConfig.AUDIO_SOURCE)
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioConfig.ENCODING)
                    .setSampleRate(AudioConfig.SAMPLE_RATE)
                    .setChannelMask(AudioConfig.CHANNEL_MASK).build())
                .setBufferSizeInBytes(AudioConfig.bufferSizeBytes(minBuf))
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .build()
        } catch (t: Throwable) { Log.e(AudioConfig.TAG, "AudioRecord build failed", t); null }
    }

    private fun attachEffects(id: Int) {
        if (id == AudioManager.ERROR) return
        ns = runCatching { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(id)?.apply { enabled = true } else null }.getOrNull()
        aec = runCatching { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(id)?.apply { enabled = true } else null }.getOrNull()
        _stats.value = _stats.value.copy(audioSessionId = id,
            noiseSuppressorActive = ns != null, echoCancelerActive = aec != null)
    }

    private fun releaseInternal() {
        record?.let { r ->
            runCatching { if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) r.stop() }
            runCatching { r.release() }
        }
        record = null
        runCatching { ns?.enabled = false; ns?.release() }; ns = null
        runCatching { aec?.enabled = false; aec?.release() }; aec = null
        sessionId = AudioManager.ERROR
        _stats.value = _stats.value.copy(audioSessionId = AudioManager.ERROR,
            noiseSuppressorActive = false, echoCancelerActive = false)
    }

    private fun publish(s: State) { _stats.value = _stats.value.copy(state = s) }
}
