package com.aegis.ai.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import androidx.core.content.ContextCompat
import com.aegis.ai.R
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

class WaveformVisualizerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var mode: OverlayMode = OverlayMode.HIDDEN
        set(v) { if (field != v) { field = v; onModeChanged(v) } }

    fun setListeningAmplitude(l: Float) { target = l.coerceIn(0f, 1f) }
    fun setSpeakingAmplitude(l: Float) { target = l.coerceIn(0f, 1f) }
    fun setSpeakingActive(a: Boolean) { speakingActive = a }

    private val accent = ContextCompat.getColor(context, R.color.aegis_accent)
    private val accentDim = withAlpha(accent, 90)
    private val accentFaint = withAlpha(accent, 30)
    private val errorColor = Color.parseColor("#F2A03D")

    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val orbCore = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(1.6f); strokeCap = Paint.Cap.ROUND; color = accent
    }
    private val waveGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(4.5f); strokeCap = Paint.Cap.ROUND; color = accentDim; alpha = 90
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2f); color = errorColor }

    private val wavePath = Path()
    private val fillPath = Path()
    private val barPhases = FloatArray(BAR_COUNT)
    private val barEnv = FloatArray(BAR_COUNT)

    @Volatile private var target = 0f
    private var display = 0f
    @Volatile private var speakingActive = false
    private var timeMs = 0f
    private var lastFrame = 0f
    private var errorElapsed = 0f
    private var prevNonError: OverlayMode = OverlayMode.HIDDEN
    private var choreographerActive = false

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!choreographerActive) return
            val now = frameTimeNanos / 1_000_000f
            val dt = if (lastFrame == 0f) 16f else (now - lastFrame).coerceIn(1f, 64f)
            lastFrame = now
            advance(dt); invalidate()
            if (choreographerActive) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    init {
        var seed = 1
        for (i in 0 until BAR_COUNT) {
            seed = (seed * 1103515245 + 12345) and 0x7FFFFFFF
            barPhases[i] = (seed % 1000).toFloat() / 1000f * 2f * PI.toFloat()
            barEnv[i] = 0.55f + 0.45f * ((seed / 1000) % 100).toFloat() / 100f
        }
        setWillNotDraw(false)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); ensureAnim() }
    override fun onDetachedFromWindow() { stopAnim(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) ensureAnim() else stopAnim()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        orbPaint.shader = RadialGradient(w / 2f, h / 2f, max(1f, minOf(w, h) / 2f),
            intArrayOf(accent, accentDim, accentFaint, Color.TRANSPARENT),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        wavePaint.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, intArrayOf(accentFaint, accent, accentFaint), null, Shader.TileMode.CLAMP)
        fillPaint.shader = LinearGradient(0f, h.toFloat(), 0f, h / 2f, intArrayOf(Color.TRANSPARENT, accentFaint), null, Shader.TileMode.CLAMP)
    }

    private fun onModeChanged(v: OverlayMode) {
        when (v) {
            OverlayMode.HIDDEN -> { target = 0f; speakingActive = false; postDelayed({ if (mode == OverlayMode.HIDDEN) stopAnim() }, OverlayConfig.FADE_MS) }
            OverlayMode.ERROR -> { prevNonError = prevNonError.takeIf { it != OverlayMode.ERROR && it != OverlayMode.HIDDEN } ?: OverlayMode.LISTENING; errorElapsed = 0f; ensureAnim() }
            else -> { prevNonError = v; ensureAnim() }
        }
    }

    private fun ensureAnim() { if (mode == OverlayMode.HIDDEN) return; if (choreographerActive) return; choreographerActive = true; lastFrame = 0f; Choreographer.getInstance().postFrameCallback(frameCb) }
    private fun stopAnim() { choreographerActive = false }

    private fun advance(dt: Float) {
        timeMs += dt; if (timeMs > 1_000_000f) timeMs = 0f
        val rate = if (target > display) 6f else 2.5f
        val k = (dt / 1000f * rate).coerceIn(0f, 1f)
        display += (target - display) * k
        if (abs(display - target) < 0.001f) display = target
        if (mode == OverlayMode.ERROR) { errorElapsed += dt; if (errorElapsed >= OverlayConfig.ERROR_DURATION_MS) { mode = prevNonError; errorElapsed = 0f } }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        when (mode) {
            OverlayMode.HIDDEN -> {}
            OverlayMode.LISTENING -> drawOrb(canvas)
            OverlayMode.SPEAKING -> drawWave(canvas)
            OverlayMode.ERROR -> drawError(canvas)
        }
    }

    private fun drawOrb(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val base = minOf(width, height) * 0.32f
        val breathe = 1f + 0.12f * sin(timeMs / 1000f * 2f * PI.toFloat() * 0.9f)
        val amp = 0.35f + display * 0.9f
        val r = base * breathe * amp
        if (r < 1f) return
        c.drawCircle(cx, cy, r * 1.6f, orbPaint)
        orbCore.color = accent
        c.drawCircle(cx, cy, r * 0.55f, orbCore)
    }

    private fun drawWave(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cy = h / 2f
        val maxAmp = h * 0.36f
        val live = when { display > 0.02f -> display; speakingActive -> 0.55f; else -> 0f }
        if (live <= 0f) return
        val amp = maxAmp * live
        val t = timeMs / 1000f
        wavePath.rewind(); fillPath.rewind()
        val stepX = w / BAR_COUNT
        wavePath.moveTo(0f, cy); fillPath.moveTo(0f, h); fillPath.lineTo(0f, cy)
        for (i in 0..BAR_COUNT) {
            val x = i * stepX
            val ph = barPhases[i.coerceAtMost(BAR_COUNT - 1)]
            val en = barEnv[i.coerceAtMost(BAR_COUNT - 1)]
            val o = sin(t * 6.2f + ph) * 0.55f + sin(t * 11.7f + ph * 1.7f) * 0.30f + sin(t * 3.1f + ph * 0.6f) * 0.15f
            val y = cy - o * amp * en
            wavePath.lineTo(x, y); fillPath.lineTo(x, y)
        }
        fillPath.lineTo(w, h); fillPath.close()
        c.drawPath(wavePath, waveGlow); c.drawPath(wavePath, wavePaint); c.drawPath(fillPath, fillPaint)
    }

    private fun drawError(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val p = (errorElapsed / OverlayConfig.ERROR_DURATION_MS).coerceIn(0f, 1f)
        val base = minOf(width, height) * 0.28f
        val r = base * (1f + p * 1.4f)
        val alpha = ((1f - p) * 255f).toInt().coerceIn(0, 255)
        ringPaint.alpha = alpha; ringPaint.strokeWidth = dp(2f + (1f - p) * 2f)
        c.drawCircle(cx, cy, r, ringPaint)
        orbCore.color = errorColor; orbCore.alpha = (alpha * 0.7f).toInt()
        c.drawCircle(cx, cy, base * 0.4f, orbCore)
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private companion object { const val BAR_COUNT = 24 }
}
