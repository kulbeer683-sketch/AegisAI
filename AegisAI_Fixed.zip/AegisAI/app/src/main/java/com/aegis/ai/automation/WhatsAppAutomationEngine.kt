package com.aegis.ai.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.service.AegisAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

class WhatsAppAutomationEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val accessibilityProvider: () -> AegisAccessibilityService?,
    private val inEar: InEarNotificationManager?,
    private val watchdog: com.aegis.ai.recovery.UiWatchdogSupervisor? = null
) {

    private val appContext = context.applicationContext
    private val mutex = Mutex()

    sealed class WhatsAppResult {
        data class Success(val verified: Boolean) : WhatsAppResult()
        data object NotInstalled : WhatsAppResult()
        data object AccessibilityUnavailable : WhatsAppResult()
        data class ContactNotFound(val recipient: String) : WhatsAppResult()
        data class NodeTimeout(val phase: String, val timeoutMs: Long) : WhatsAppResult()
        data class SendFailed(val reason: String) : WhatsAppResult()
        data object ChatLocked : WhatsAppResult()
        data class Error(val message: String?) : WhatsAppResult()
    }

    suspend fun sendMessage(
        recipient: String, message: String,
        language: IntentMatch.Language = IntentMatch.Language.ENGLISH,
        announce: Boolean = true
    ): WhatsAppResult = mutex.withLock {
        Log.i(TAG, "WhatsApp start recipient='$recipient'")
        val pkg = pickPackage() ?: run { if (announce) announce(WhatsAppResult.NotInstalled, language); return@withLock WhatsAppResult.NotInstalled }
        val svc = accessibilityProvider() ?: run { if (announce) announce(WhatsAppResult.AccessibilityUnavailable, language); return@withLock WhatsAppResult.AccessibilityUnavailable }

        val result: WhatsAppResult = try { runPhases(svc, pkg, recipient, message) }
        catch (ce: CancellationException) { throw ce }
        catch (t: Throwable) { Log.e(TAG, "flow threw", t); WhatsAppResult.Error(t.message) }

        if (announce) announce(result, language)
        result
    }

    fun sendMessageAsync(recipient: String, message: String, language: IntentMatch.Language = IntentMatch.Language.ENGLISH, announce: Boolean = true): Job =
        scope.launch { sendMessage(recipient, message, language, announce) }

    private sealed class PhaseResult {
        data object Ok : PhaseResult()
        data class Timeout(val phase: String, val ms: Long) : PhaseResult()
        data class Fail(val reason: WhatsAppResult) : PhaseResult()
    }

    private suspend fun runPhases(svc: AegisAccessibilityService, pkg: String, recipient: String, message: String): WhatsAppResult {
        val sessionId = watchdog?.startSession(description = "wa:$recipient", initialPhase = "launch")
        try {
            if (!launch(pkg)) return WhatsAppResult.Error("Launch failed")
            watchdog?.beginPhase(sessionId ?: "", "wait-fg")
            if (!awaitForeground(pkg, 5000L)) return WhatsAppResult.NodeTimeout("wait-for-foreground", 5000L)
            delay(250L); coroutineContext.ensureActive()

            watchdog?.beginPhase(sessionId ?: "", "search")
            when (val c = searchAndClickContact(svc, recipient)) {
                is PhaseResult.Ok -> {}
                is PhaseResult.Timeout -> return WhatsAppResult.NodeTimeout(c.phase, c.ms)
                is PhaseResult.Fail -> return c.reason
            }

            if (detectLock(svc)) { safeBack(svc); return WhatsAppResult.ChatLocked }

            watchdog?.beginPhase(sessionId ?: "", "compose")
            when (val d = compose(svc, message)) {
                is PhaseResult.Ok -> {}
                is PhaseResult.Timeout -> { safeBack(svc); return WhatsAppResult.NodeTimeout(d.phase, d.ms) }
                is PhaseResult.Fail -> { safeBack(svc); return d.reason }
            }

            watchdog?.beginPhase(sessionId ?: "", "send")
            when (val e = tapSend(svc)) {
                is PhaseResult.Ok -> {}
                is PhaseResult.Timeout -> { safeBack(svc); return WhatsAppResult.NodeTimeout(e.phase, e.ms) }
                is PhaseResult.Fail -> { safeBack(svc); return e.reason }
            }

            watchdog?.beginPhase(sessionId ?: "", "verify")
            val verified = verifySent(svc, message)
            safeBack(svc)
            return WhatsAppResult.Success(verified)
        } finally { sessionId?.let { watchdog?.endSession(it) } }
    }

    private fun pickPackage(): String? {
        val pm = appContext.packageManager
        for (pkg in WHATSAPP_PACKAGES) {
            try { @Suppress("DEPRECATION") pm.getPackageInfo(pkg, 0); return pkg } catch (_: PackageManager.NameNotFoundException) {}
        }
        return null
    }

    private suspend fun launch(pkg: String): Boolean = withContext(Dispatchers.Main.immediate) {
        try {
            appContext.startActivity(Intent(Intent.ACTION_MAIN).apply {
                setPackage(pkg); addCategory(Intent.CATEGORY_LAUNCHER)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            })
            true
        } catch (t: Throwable) { false }
    }

    private suspend fun awaitForeground(pkg: String, timeoutMs: Long): Boolean {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline) {
            coroutineContext.ensureActive()
            val s = accessibilityProvider() ?: return false
            if (s.currentPackage() == pkg) return true
            delay(100L)
        }
        return false
    }

    private suspend fun searchAndClickContact(svc: AegisAccessibilityService, recipient: String): PhaseResult {
        val input = openSearchInput(svc) ?: return PhaseResult.Timeout("search-input", 2500L)
        try {
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, recipient) }
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return PhaseResult.Fail(WhatsAppResult.SendFailed("search rejected"))
        } finally { input.recycleSafe() }

        delay(450L); coroutineContext.ensureActive()

        val row = svc.awaitNode(2500L, 100L) { n -> isContactRow(n) }
            ?: return PhaseResult.Fail(WhatsAppResult.ContactNotFound(recipient))
        try {
            if (!svc.clickNode(row)) return PhaseResult.Fail(WhatsAppResult.SendFailed("row not clickable"))
        } finally { row.recycleSafe() }
        return PhaseResult.Ok
    }

    private suspend fun openSearchInput(svc: AegisAccessibilityService): AccessibilityNodeInfo? {
        val existing = svc.findNode { n -> n.viewIdResourceName in SEARCH_INPUT_IDS || (n.isEditable && n.isFocused) }
        if (existing != null) return existing
        val icon = svc.findNode { n -> n.viewIdResourceName in SEARCH_ICON_IDS || (isSearchDesc(n) && n.isEnabled) }
        if (icon != null) { try { svc.clickNode(icon) } finally { icon.recycleSafe() } }
        return svc.awaitNode(2500L, 100L) { n -> n.viewIdResourceName in SEARCH_INPUT_IDS || (n.isEditable && n.isFocused) }
    }

    private suspend fun compose(svc: AegisAccessibilityService, message: String): PhaseResult {
        val entry = svc.awaitNode(3500L, 100L) { n -> n.viewIdResourceName in ENTRY_IDS || (n.isEditable && n.isFocused) }
            ?: return PhaseResult.Timeout("chat-window", 3500L)
        try {
            entry.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message) }
            if (!entry.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return PhaseResult.Fail(WhatsAppResult.SendFailed("entry rejected"))
        } finally { entry.recycleSafe() }
        delay(300L)
        return PhaseResult.Ok
    }

    private suspend fun tapSend(svc: AegisAccessibilityService): PhaseResult {
        val send = svc.awaitNode(1500L, 100L) { n -> n.viewIdResourceName in SEND_IDS || (isSendDesc(n) && n.isEnabled) }
            ?: return PhaseResult.Timeout("send-button", 1500L)
        try { if (!svc.clickNode(send)) return PhaseResult.Fail(WhatsAppResult.SendFailed("send not clickable")) }
        finally { send.recycleSafe() }
        return PhaseResult.Ok
    }

    private suspend fun verifySent(svc: AegisAccessibilityService, message: String): Boolean {
        delay(500L); coroutineContext.ensureActive()
        val empty = svc.awaitNode(1500L, 80L) { n -> n.viewIdResourceName in ENTRY_IDS && n.text.isNullOrEmpty() }
        if (empty != null) { empty.recycleSafe(); return true }
        val snip = message.take(40)
        if (snip.isNotBlank()) {
            val bubble = svc.findNode { n -> n.text?.toString()?.contains(snip, ignoreCase = true) == true }
            if (bubble != null) { bubble.recycleSafe(); return true }
        }
        return false
    }

    private suspend fun detectLock(svc: AegisAccessibilityService): Boolean {
        val n = svc.findNode { node ->
            val c = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
            c.any { txt -> LOCK_HINTS.any { it in txt.lowercase() } }
        }
        if (n == null) return false
        n.recycleSafe(); return true
    }

    private fun isContactRow(n: AccessibilityNodeInfo): Boolean {
        val id = n.viewIdResourceName ?: return false
        if (id in CONTACT_ROW_IDS) return true
        return id.startsWith("com.whatsapp:id/contact") && n.isClickable
    }

    private fun isSearchDesc(n: AccessibilityNodeInfo): Boolean {
        val d = n.contentDescription?.toString()?.lowercase() ?: return false
        return SEARCH_DESCS.any { it in d }
    }

    private fun isSendDesc(n: AccessibilityNodeInfo): Boolean {
        val c = listOfNotNull(n.contentDescription?.toString(), n.text?.toString())
        return c.any { txt -> SEND_DESCS.any { it in txt.lowercase() } }
    }

    private suspend fun safeBack(svc: AegisAccessibilityService) {
        try { svc.goBack(); delay(120L); svc.goBack() } catch (_: Throwable) {}
    }

    private suspend fun announce(r: WhatsAppResult, language: IntentMatch.Language) {
        val mgr = inEar ?: return
        val text = when (r) {
            is WhatsAppResult.Success -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "मैसेज भेज दिया गया" else "Message sent"
            WhatsAppResult.NotInstalled -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "व्हाट्सएप इंस्टॉल नहीं है" else "WhatsApp not installed"
            is WhatsAppResult.ContactNotFound -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "कॉन्टैक्ट नहीं मिला" else "Contact not found"
            is WhatsAppResult.NodeTimeout -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "व्हाट्सएप ने जवाब नहीं दिया" else "WhatsApp did not respond"
            is WhatsAppResult.SendFailed -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "मैसेज नहीं भेजा जा सका" else "Could not send message"
            WhatsAppResult.AccessibilityUnavailable -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "एक्सेसिबिलिटी सेवा चालू करें" else "Enable accessibility service"
            WhatsAppResult.ChatLocked -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "चैट लॉक है" else "Chat is locked"
            is WhatsAppResult.Error -> if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "कुछ गलत हो गया" else "Something went wrong"
        }
        runCatching { mgr.speak(text) }
    }

    private companion object {
        const val TAG = AudioConfig.TAG
        val WHATSAPP_PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")
        val SEARCH_INPUT_IDS = setOf("com.whatsapp:id/search_input", "com.whatsapp:id/search_src_text", "com.whatsapp:id/searchbar")
        val SEARCH_ICON_IDS = setOf("com.whatsapp:id/menuitem_search", "com.whatsapp:id/search")
        val CONTACT_ROW_IDS = setOf("com.whatsapp:id/contact_row_container", "com.whatsapp:id/contactpicker_row_name", "com.whatsapp:id/conversations_row_contact_name")
        val ENTRY_IDS = setOf("com.whatsapp:id/entry", "com.whatsapp:id/input")
        val SEND_IDS = setOf("com.whatsapp:id/send", "com.whatsapp:id/send_button")
        val SEARCH_DESCS = setOf("search", "खोज")
        val SEND_DESCS = setOf("send", "भेजें", "भेजो")
        val LOCK_HINTS = setOf("unlock", "fingerprint", "pattern", "chat locked")
    }
}

private fun AccessibilityNodeInfo.recycleSafe() = UiNodeResolver.recycleSafe(this)
