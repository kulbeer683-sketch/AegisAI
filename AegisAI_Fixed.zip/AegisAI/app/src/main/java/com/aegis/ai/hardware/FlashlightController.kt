package com.aegis.ai.hardware

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.aegis.ai.audio.AudioConfig

class FlashlightController(context: Context) : AutoCloseable {

    private val cameraManager =
        context.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var cameraId: String? = resolve()
    @Volatile private var on = false

    private val callback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) { if (id == cameraId) on = enabled }
        override fun onTorchModeUnavailable(id: String) { if (id == cameraId) on = false }
    }

    init { runCatching { cameraManager.registerTorchCallback(callback, handler) } }

    suspend fun setTorch(enabled: Boolean): ControllerResult {
        val id = cameraId ?: return ControllerResult.Failure("No torch camera")
        return try {
            cameraManager.setTorchMode(id, enabled); on = enabled
            ControllerResult.Success("Torch " + (if (enabled) "on" else "off"))
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "torch failed") }
    }

    suspend fun toggle(): ControllerResult = setTorch(!on)

    private fun resolve(): String? = try {
        val ids = cameraManager.cameraIdList
        ids.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    } catch (_: Throwable) { null }

    override fun close() {
        runCatching { cameraManager.unregisterTorchCallback(callback) }
        cameraId?.let { runCatching { cameraManager.setTorchMode(it, false) } }
    }
}
