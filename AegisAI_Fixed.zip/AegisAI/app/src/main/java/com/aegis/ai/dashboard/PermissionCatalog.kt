package com.aegis.ai.dashboard

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.aegis.ai.notifications.SmartNotificationListener
import com.aegis.ai.service.AegisAccessibilityService

object PermissionCatalog {

    fun load(context: Context): List<PermissionItem> = buildList {
        add(rt("record_audio", "Microphone", "Wake-word and voice commands.", PermissionCategory.AUDIO_AND_HARDWARE, true, Manifest.permission.RECORD_AUDIO))
        add(rt("modify_audio", "Audio Routing", "Bluetooth SCO + volume.", PermissionCategory.AUDIO_AND_HARDWARE, false, Manifest.permission.MODIFY_AUDIO_SETTINGS))
        add(rt("read_phone_state", "Phone State", "Detect incoming calls.", PermissionCategory.PHONE_AND_CONTACTS, false, Manifest.permission.READ_PHONE_STATE))
        add(rt("read_contacts", "Contacts", "Resolve caller names.", PermissionCategory.PHONE_AND_CONTACTS, false, Manifest.permission.READ_CONTACTS))
        add(rt("answer_calls", "Answer Calls", "Hands-free answering.", PermissionCategory.PHONE_AND_CONTACTS, false, Manifest.permission.ANSWER_PHONE_CALLS))
        add(rt("fine_location", "Precise Location", "Home/work zone detection.", PermissionCategory.LOCATION, false, Manifest.permission.ACCESS_FINE_LOCATION))
        add(rt("coarse_location", "Approximate Location", "Coarse context.", PermissionCategory.LOCATION, false, Manifest.permission.ACCESS_COARSE_LOCATION))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) add(rt("background_location", "Background Location", "Spatial routines.", PermissionCategory.LOCATION, false, Manifest.permission.ACCESS_BACKGROUND_LOCATION))
        add(rt("camera", "Camera", "Look around vision.", PermissionCategory.CAMERA, false, Manifest.permission.CAMERA))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(rt("bluetooth_connect", "Bluetooth", "Headset routing.", PermissionCategory.CONNECTIVITY, false, Manifest.permission.BLUETOOTH_CONNECT))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(rt("post_notifications", "Notifications", "Foreground service.", PermissionCategory.NOTIFICATIONS, true, Manifest.permission.POST_NOTIFICATIONS))
            add(rt("nearby_wifi", "Nearby Wi-Fi", "Read SSID.", PermissionCategory.CONNECTIVITY, false, Manifest.permission.NEARBY_WIFI_DEVICES))
        }
        add(sp("accessibility", "Accessibility Service", "UI automation and gestures.", true, { AegisAccessibilityService.isConnected() }, { c ->
            c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }))
        add(sp("overlay", "Display Over Other Apps", "Floating HUD.", false, { c -> runCatching { Settings.canDrawOverlays(c) }.getOrDefault(false) }, { c ->
            c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.fromParts("package", c.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }))
        add(sp("notification_listener", "Notification Access", "Priority triage.", false, { SmartNotificationListener.isConnected() }, { c ->
            c.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }))
        add(sp("dnd_access", "Do Not Disturb Access", "DND + bedtime.", false, { c ->
            runCatching { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }.getOrDefault(false)
        }, { c -> c.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }))
        add(sp("battery_exempt", "Unrestricted Battery", "Reliable wake word.", false, { c ->
            runCatching { (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName) }.getOrDefault(false)
        }, { c ->
            runCatching { c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.fromParts("package", c.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }))
    }

    private fun rt(id: String, title: String, desc: String, cat: PermissionCategory, req: Boolean, perm: String) = PermissionItem(
        id, title, desc, cat, req,
        { c -> ContextCompat.checkSelfPermission(c, perm) == PackageManager.PERMISSION_GRANTED },
        { c -> c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", c.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    )

    private fun sp(id: String, title: String, desc: String, req: Boolean, isG: (Context) -> Boolean, open: (Context) -> Unit) =
        PermissionItem(id, title, desc, PermissionCategory.SPECIAL_ACCESS, req, isG, open)
}
