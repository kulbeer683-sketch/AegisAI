package com.aegis.ai.power

import com.aegis.ai.intent.IntentMatch

object PowerDiagnosticsSpeaker {

    fun speak(posture: PowerPosture, language: IntentMatch.Language = IntentMatch.Language.HINGLISH): String {
        val hindi = language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH || language == IntentMatch.Language.MIXED
        val b = posture.batteryPercent
        val t = posture.temperatureC
        val charging = posture.charging
        val tier = posture.tier

        val charge = if (charging) { if (hindi) "चार्जिंग पर" else "charging" }
                     else { if (hindi) "चार्जिंग पर नहीं" else "not charging" }

        val tierText = when (tier) {
            ThrottleTier.NORMAL -> if (hindi) "सामान्य" else "normal"
            ThrottleTier.THROTTLED -> if (hindi) "थोड़ा सीमित" else "throttled"
            ThrottleTier.CRITICAL -> if (hindi) "गंभीर सीमित" else "critical"
        }
        val drain = when (tier) {
            ThrottleTier.NORMAL -> ""
            ThrottleTier.THROTTLED -> if (hindi) " कुछ सुविधाएँ धीमी हैं" else " some features reduced"
            ThrottleTier.CRITICAL -> if (hindi) " केवल ज़रूरी काम चालू हैं" else " only essential features active"
        }
        val tempText = if (t.isNaN()) "" else if (hindi) "तापमान ${"%.0f".format(t)} डिग्री, " else "temperature ${"%.0f".format(t)}°C, "

        return if (hindi) "बैटरी $b%, $tempText$charge, पावर मोड $tierText$drain"
        else "Battery $b%, $tempText$charge, power mode $tierText$drain"
    }
}
