package com.aegis.ai.hardware

import android.content.Context
import android.media.AudioManager
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream

class VolumeController(context: Context) {

    private val am = context.applicationContext
        .getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun setVolume(stream: AudioStream, percent: Int): ControllerResult {
        val s = stream.androidStream
        val max = am.getStreamMaxVolume(s)
        val target = (max * percent.coerceIn(0, 100) / 100).coerceIn(0, max)
        return try {
            am.setStreamVolume(s, target, AudioManager.FLAG_SHOW_UI)
            ControllerResult.Success(stream.name + " → " + percent + "%")
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "volume failed") }
    }

    fun adjustVolume(stream: AudioStream, direction: AegisAction.Direction): ControllerResult {
        val s = stream.androidStream
        val d = if (direction == AegisAction.Direction.UP) AudioManager.ADJUST_RAISE
                else AudioManager.ADJUST_LOWER
        return try {
            am.adjustStreamVolume(s, d, AudioManager.FLAG_SHOW_UI)
            ControllerResult.Success(stream.name + " adjusted")
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "adjust failed") }
    }

    fun setMute(stream: AudioStream, mute: Boolean?): ControllerResult {
        val s = stream.androidStream
        return try {
            val shouldMute = mute ?: (am.getStreamVolume(s) > 0)
            val max = am.getStreamMaxVolume(s)
            val target = if (shouldMute) 0 else maxOf(1, max / 3)
            am.setStreamVolume(s, target, AudioManager.FLAG_SHOW_UI)
            ControllerResult.Success(stream.name + " " + (if (shouldMute) "muted" else "unmuted"))
        } catch (t: Throwable) { ControllerResult.Failure(t.message ?: "mute failed") }
    }
}
