package com.aegis.ai.service

import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.aegis.ai.vision.MediaProjectionHolder

class ScreenCapturePermissionActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val granted = r.resultCode == Activity.RESULT_OK && r.data != null
        if (granted) MediaProjectionHolder.set(r.resultCode, r.data) else MediaProjectionHolder.clear()
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (MediaProjectionHolder.isGranted()) { finish(); return }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        if (mpm == null) { finish(); return }
        runCatching { launcher.launch(mpm.createScreenCaptureIntent()) }.onFailure { finish() }
    }
}
