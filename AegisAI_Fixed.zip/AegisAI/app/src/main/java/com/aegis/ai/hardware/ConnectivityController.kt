package com.aegis.ai.hardware

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

class ConnectivityController(context: Context) {

    private val appContext = context.applicationContext
    private val bt: BluetoothAdapter? =
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val wifi: WifiManager? =
        appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    @Suppress("DEPRECATION")
    fun setBluetooth(enabled: Boolean): ControllerResult {
        val a = bt ?: return ControllerResult.Failure("No Bluetooth")
        if (a.isEnabled == enabled) return ControllerResult.Success("already")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(appContext, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            return ControllerResult.NeedsUserIntent(btRequest(enabled), "BLUETOOTH_CONNECT required")
        }
        return try {
            val ok = if (enabled) a.enable() else a.disable()
            if (ok) ControllerResult.Success("BT " + (if (enabled) "on" else "off"))
            else ControllerResult.NeedsUserIntent(btRequest(enabled), "Direct toggle rejected")
        } catch (t: Throwable) { ControllerResult.NeedsUserIntent(btRequest(enabled), t.message ?: "BT failed") }
    }

    fun toggleBluetooth(): ControllerResult = setBluetooth(bt?.isEnabled != true)

    private fun btRequest(enable: Boolean): Intent = Intent(
        if (enable) BluetoothAdapter.ACTION_REQUEST_ENABLE else BluetoothAdapter.ACTION_REQUEST_DISABLE
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    @Suppress("DEPRECATION")
    fun setWifi(enabled: Boolean): ControllerResult {
        val m = wifi ?: return ControllerResult.Failure("No WiFi")
        if (m.isWifiEnabled == enabled) return ControllerResult.Success("already")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return try {
                if (m.setWifiEnabled(enabled)) ControllerResult.Success("WiFi " + (if (enabled) "on" else "off"))
                else ControllerResult.NeedsUserIntent(wifiPanel(), "Direct toggle rejected")
            } catch (t: Throwable) { ControllerResult.NeedsUserIntent(wifiPanel(), t.message ?: "WiFi failed") }
        }
        return ControllerResult.NeedsUserIntent(wifiPanel(), "WiFi requires confirmation")
    }

    fun toggleWifi(): ControllerResult = setWifi(wifi?.isWifiEnabled != true)

    private fun wifiPanel(): Intent = (
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_WIFI)
        else Intent(Settings.ACTION_WIFI_SETTINGS)
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
