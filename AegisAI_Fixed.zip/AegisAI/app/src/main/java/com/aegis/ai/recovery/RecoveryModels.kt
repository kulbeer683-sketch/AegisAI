package com.aegis.ai.recovery

data class WatchdogSession(
    val id: String, val phaseName: String, val startedAtMs: Long,
    val deadlineMs: Long, val description: String
) {
    fun isExpired(nowMs: Long) = (nowMs - startedAtMs) > deadlineMs
    fun remainingMs(nowMs: Long) = (deadlineMs - (nowMs - startedAtMs)).coerceAtLeast(0L)
}

interface HeartbeatComponent {
    val componentName: String
    fun isAlive(): Boolean
    suspend fun recover(): Boolean
}

enum class CircuitState { CLOSED, OPEN, HALF_OPEN }

data class RecoveryEvent(
    val sessionId: String, val phaseName: String, val description: String,
    val elapsedMs: Long, val deadlineMs: Long, val timestampMs: Long
)
