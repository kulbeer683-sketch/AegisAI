package com.aegis.ai.notifications

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import com.aegis.ai.audio.AudioConfig

class NotificationReplyDispatcher(private val context: Context) {

    fun dispatch(notificationKey: String, message: String): ReplyResult {
        if (message.isBlank()) return ReplyResult.Failure("empty message")
        val listener = SmartNotificationListener.get() ?: return ReplyResult.Failure("listener unavailable")
        val active = runCatching { listener.activeNotifications }.getOrNull() ?: return ReplyResult.NotificationNotFound
        val sbn = active.firstOrNull { it.key == notificationKey } ?: return ReplyResult.NotificationNotFound
        val notif = sbn.notification ?: return ReplyResult.NotificationNotFound
        val action = findReplyAction(notif) ?: return ReplyResult.NoReplyAction
        val remote = action.remoteInputs
        if (remote.isNullOrEmpty()) return ReplyResult.NoReplyAction

        val intent = Intent()
        val bundle = Bundle()
        for (ri in remote) bundle.putCharSequence(ri.resultKey, message)
        RemoteInput.addResultsToIntent(remote, intent, bundle)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) RemoteInput.setResultsSource(intent, RemoteInput.SOURCE_FREE_FORM_INPUT)

        return try {
            action.actionIntent.send(context, 0, intent)
            ReplyResult.Success(sbn.packageName ?: "unknown")
        } catch (e: PendingIntent.CanceledException) { ReplyResult.PendingIntentCanceled }
        catch (t: Throwable) { ReplyResult.Failure(t.message ?: "unknown") }
    }

    private fun findReplyAction(n: Notification): Notification.Action? = n.actions?.firstOrNull { !it.remoteInputs.isNullOrEmpty() }

    private companion object { const val TAG = AudioConfig.TAG }
}
