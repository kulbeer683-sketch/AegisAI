package com.aegis.ai.boot

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.core.content.ContextCompat
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioDspPipeline
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.memory.LongTermMemoryManager
import com.aegis.ai.security.SecureKeyStorage
import com.aegis.ai.voice.VoicePersonaEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

class FirstBootProvisioner(
    context: Context,
    private val audioPipeline: AudioDspPipeline,
    private val inEar: InEarNotificationManager,
    private val voicePersonaEngine: VoicePersonaEngine,
    private val memoryManager: LongTermMemoryManager,
    private val secureKeyStorage: SecureKeyStorage
) {
    private val appContext = context.applicationContext

    fun isFirstBoot(): Boolean = runCatching {
        !appContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_DONE, false)
    }.getOrDefault(true)

    fun resetFirstBootFlag() { runCatching { appContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(KEY_DONE).apply() } }

    private fun markComplete() { runCatching { appContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_DONE, true).putLong(KEY_AT, System.currentTimeMillis()).apply() } }

    suspend fun runHandshake(force: Boolean = false): BootHandshakeResult {
        val start = SystemClock.elapsedRealtime()
        val errors = mutableListOf<String>()
        val firstBoot = force || isFirstBoot()

        val pipelineWarm = withTimeoutOrNull(PHASE_MS) { warmPipeline() } ?: false
        val ttsReady = withTimeoutOrNull(PHASE_MS) { verifyTts() } ?: false
        val voiceOk = runCatching { voicePersonaEngine.targetLocaleFor(SIGNATURE_GREETING); true }.getOrDefault(false)
        val memoryOk = withTimeoutOrNull(PHASE_MS) { warmMemory() } ?: false

        val missing = collectMissing()
        val permsOk = missing.isEmpty()

        val greeted = if (firstBoot || force) withTimeoutOrNull(GREET_MS) { speakGreeting(permsOk, missing, errors) } ?: false else false
        if (firstBoot && greeted) markComplete()

        if (!pipelineWarm) runCatching { audioPipeline.start(false) }.onFailure { errors += "pipeline-final:${it.javaClass.simpleName}" }

        val elapsed = SystemClock.elapsedRealtime() - start
        return BootHandshakeResult(
            wasFirstBoot = firstBoot,
            pipelineWarmedUp = pipelineWarm || audioPipeline.stats.value.state == AudioDspPipeline.State.RUNNING,
            ttsAvailable = ttsReady, preferredVoiceSelected = voiceOk, memoryCacheReady = memoryOk,
            permissionsComplete = permsOk, missingPermissions = missing,
            greetingSpoken = greeted, elapsedMs = elapsed, errors = errors
        )
    }

    private suspend fun warmPipeline(): Boolean {
        val cur = audioPipeline.stats.value.state
        if (cur == AudioDspPipeline.State.RUNNING || cur == AudioDspPipeline.State.STARTING) return true
        val ok = runCatching { audioPipeline.start(false) }.getOrDefault(false)
        delay(150L)
        return ok || audioPipeline.stats.value.state == AudioDspPipeline.State.RUNNING
    }

    private suspend fun verifyTts(): Boolean = runCatching { inEar.speak(""); true }.getOrDefault(false)

    private suspend fun warmMemory(): Boolean = runCatching { delay(80L); memoryManager.factCount(); true }.getOrDefault(false)

    private fun collectMissing(): List<String> {
        val m = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(appContext, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) m += "microphone"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && ContextCompat.checkSelfPermission(appContext, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) m += "notifications"
        if (runCatching { !android.provider.Settings.canDrawOverlays(appContext) }.getOrDefault(false)) m += "overlay"
        if (com.aegis.ai.service.AegisAccessibilityService.get() == null) m += "accessibility"
        if (!com.aegis.ai.notifications.SmartNotificationListener.isConnected()) m += "notification-listener"
        return m
    }

    private suspend fun speakGreeting(permsOk: Boolean, missing: List<String>, errors: MutableList<String>): Boolean {
        return runCatching {
            val text = if (permsOk) SIGNATURE_GREETING else "एजिस ऑनलाइन। लेकिन ${missing.take(3).joinToString(", ")} की अनुमति अभी नहीं मिली। कृपया डैशबोर्ड में जाकर दें।"
            delay(GREET_PRE_MS)
            inEar.speak(text, priority = true)
        }.getOrElse { errors += "greeting:${it.javaClass.simpleName}"; false }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val SIGNATURE_GREETING = "एजिस ऑनलाइन। सभी सब-सिस्टम सक्रिय हैं, सर।"
        private const val PHASE_MS = 3_000L
        private const val GREET_MS = 6_000L
        private const val GREET_PRE_MS = 250L
        private const val FILE = "aegis_first_boot"
        private const val KEY_DONE = "first_boot_completed"
        private const val KEY_AT = "first_boot_at_ms"
    }
}
