package com.aegis.ai.boot

data class BootHandshakeResult(
    val wasFirstBoot: Boolean, val pipelineWarmedUp: Boolean, val ttsAvailable: Boolean,
    val preferredVoiceSelected: Boolean, val memoryCacheReady: Boolean,
    val permissionsComplete: Boolean, val missingPermissions: List<String>,
    val greetingSpoken: Boolean, val elapsedMs: Long, val errors: List<String>
) {
    val allOk: Boolean get() = errors.isEmpty() && pipelineWarmedUp && ttsAvailable && memoryCacheReady
    fun logLine(): String = buildString {
        append("firstBoot=").append(wasFirstBoot); append(" pipeline=").append(pipelineWarmedUp)
        append(" tts=").append(ttsAvailable); append(" voice=").append(preferredVoiceSelected)
        append(" memory=").append(memoryCacheReady); append(" perms=").append(permissionsComplete)
        if (missingPermissions.isNotEmpty()) append(" missing=").append(missingPermissions.joinToString(","))
        append(" greeted=").append(greetingSpoken); append(" ms=").append(elapsedMs)
        if (errors.isNotEmpty()) append(" errors=").append(errors.joinToString(";"))
    }
}
