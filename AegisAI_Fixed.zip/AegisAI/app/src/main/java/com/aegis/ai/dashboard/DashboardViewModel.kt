package com.aegis.ai.dashboard

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aegis.ai.privacy.PrivacyPreferences
import com.aegis.ai.security.SecureKeyStorage
import com.aegis.ai.service.AegisForegroundService
import com.aegis.ai.state.AegisStateBus
import com.aegis.ai.voice.VoicePersonaPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class DashboardViewModel(app: Application) : AndroidViewModel(app) {

    private val secureKeys = SecureKeyStorage(app)
    private val privacyPrefs = PrivacyPreferences(app)
    private val voicePrefs = VoicePersonaPreferences(app)
    private val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val permFlow = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    private val _keyValidation = MutableStateFlow<KeyValidation>(KeyValidation.Idle)
    val keyValidation: StateFlow<KeyValidation> = _keyValidation.asStateFlow()

    val state: StateFlow<DashboardState> = combine(
        AegisStateBus.serviceRunning, AegisStateBus.pipelineRunning, AegisStateBus.assistantState,
        AegisStateBus.vitals, AegisStateBus.heartbeat, AegisStateBus.diagnostics,
        AegisStateBus.geminiKeyPresent, AegisStateBus.voicePitch, AegisStateBus.voiceRate,
        AegisStateBus.lastError, permFlow,
        AegisStateBus.privacyCloudEnabled, AegisStateBus.privacyScreenVisionEnabled,
        AegisStateBus.privacyCameraVisionEnabled, AegisStateBus.privacyLocationRoutinesEnabled,
        AegisStateBus.throttleTier, AegisStateBus.activeWakeLocks, AegisStateBus.releasedLeaks
    ) { values ->
        DashboardState(
            serviceRunning = values[0] as Boolean,
            pipelineRunning = values[1] as Boolean,
            assistantState = values[2] as com.aegis.ai.wakeword.AssistantStateCoordinator.State?,
            vitals = values[3] as com.aegis.ai.vitals.VitalsSnapshot?,
            heartbeat = values[4] as Map<String, Boolean>,
            diagnostics = values[5] as com.aegis.ai.decision.Phase4DiagnosticsPayload?,
            geminiKeyPresent = values[6] as Boolean,
            voicePitch = values[7] as Float,
            voiceRate = values[8] as Float,
            lastError = values[9] as String?,
            permissions = PermissionCatalog.load(getApplication()),
            permissionStatus = values[10] as Map<String, Boolean>,
            privacyCloudEnabled = values[11] as Boolean,
            privacyScreenVisionEnabled = values[12] as Boolean,
            privacyCameraVisionEnabled = values[13] as Boolean,
            privacyLocationRoutinesEnabled = values[14] as Boolean,
            throttleTier = values[15] as com.aegis.ai.power.ThrottleTier,
            activeWakeLocks = values[16] as Int,
            releasedLeaks = values[17] as Long
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardState(permissions = PermissionCatalog.load(getApplication())))

    fun refreshPermissions() {
        val ctx = getApplication<Application>()
        permFlow.value = PermissionCatalog.load(ctx).associate { it.id to it.isGranted(ctx) }
        AegisStateBus.setGeminiKeyPresent(secureKeys.hasGeminiApiKey())
        AegisStateBus.setVoicePitch(voicePrefs.getPitch())
        AegisStateBus.setVoiceRate(voicePrefs.getRate())
        privacyPrefs.refresh()
        AegisStateBus.setPrivacyCloudEnabled(privacyPrefs.isCloudReasoningEnabled())
        AegisStateBus.setPrivacyScreenVisionEnabled(privacyPrefs.isScreenVisionEnabled())
        AegisStateBus.setPrivacyCameraVisionEnabled(privacyPrefs.isCameraVisionEnabled())
        AegisStateBus.setPrivacyLocationRoutinesEnabled(privacyPrefs.isLocationRoutinesEnabled())
    }

    fun openPermissionSettings(item: PermissionItem) { runCatching { item.openSettings(getApplication()) } }

    fun startService() { runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.startIntent(getApplication(), true)) } }
    fun stopService() { runCatching { getApplication<Application>().startService(AegisForegroundService.stopIntent(getApplication())) } }
    fun startServiceOrStop(start: Boolean) { if (start) startService() else stopService() }

    fun requestDiagnostics() { runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.selfCheckIntent(getApplication())) } }

    fun setVoicePitch(v: Float) { AegisStateBus.setVoicePitch(v); runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.setVoicePitchIntent(getApplication(), v)) } }
    fun setVoiceRate(v: Float) { AegisStateBus.setVoiceRate(v); runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.setVoiceRateIntent(getApplication(), v)) } }
    fun testVoice() { runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.textIntent(getApplication(), "voice test")) } }

    fun setCloudEnabled(e: Boolean) { privacyPrefs.setCloudReasoningEnabled(e); AegisStateBus.setPrivacyCloudEnabled(e); runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.privacyCloudIntent(getApplication(), e)) } }
    fun setScreenVisionEnabled(e: Boolean) { privacyPrefs.setScreenVisionEnabled(e); AegisStateBus.setPrivacyScreenVisionEnabled(e); runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.privacyScreenVisionIntent(getApplication(), e)) } }
    fun setCameraVisionEnabled(e: Boolean) { privacyPrefs.setCameraVisionEnabled(e); AegisStateBus.setPrivacyCameraVisionEnabled(e); runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.privacyCameraVisionIntent(getApplication(), e)) } }
    fun setLocationRoutinesEnabled(e: Boolean) { privacyPrefs.setLocationRoutinesEnabled(e); AegisStateBus.setPrivacyLocationRoutinesEnabled(e); runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.privacyLocationIntent(getApplication(), e)) } }

    fun requestWipe() { runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.textIntent(getApplication(), "wipe everything")) } }

    fun saveGeminiKey(k: String) {
        val t = k.trim(); if (t.isBlank()) return
        secureKeys.setGeminiApiKey(t); AegisStateBus.setGeminiKeyPresent(true)
        runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.setGeminiKeyIntent(getApplication(), t)) }
    }

    fun clearGeminiKey() {
        secureKeys.clearGeminiApiKey(); AegisStateBus.setGeminiKeyPresent(false); _keyValidation.value = KeyValidation.Idle
        runCatching { getApplication<Application>().startForegroundService(AegisForegroundService.clearGeminiKeyIntent(getApplication())) }
    }

    fun validateKey(k: String) {
        val t = k.trim()
        if (t.length < 20) { _keyValidation.value = KeyValidation.Failure("Key too short"); return }
        if (!isOnline()) { _keyValidation.value = KeyValidation.Failure("Network unavailable"); return }
        _keyValidation.value = KeyValidation.Validating
        viewModelScope.launch { _keyValidation.value = withContext(Dispatchers.IO) { probe(t) } }
    }

    fun dismissKeyValidation() { _keyValidation.value = KeyValidation.Idle }

    private fun isOnline() = runCatching {
        val a = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(a) ?: return false
        c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }.getOrDefault(false)

    private fun probe(apiKey: String): KeyValidation {
        val client = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(6, TimeUnit.SECONDS).callTimeout(8, TimeUnit.SECONDS).build()
        val body = """{"contents":[{"role":"user","parts":[{"text":"hi"}]}],"generationConfig":{"maxOutputTokens":1}}""".toRequestBody("application/json; charset=utf-8".toMediaType())
        val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey").post(body).build()
        return try {
            client.newCall(req).execute().use { r -> when (r.code) {
                200 -> KeyValidation.Success("••••${apiKey.takeLast(4)}")
                401, 403 -> KeyValidation.Failure("Invalid API key")
                429 -> KeyValidation.Failure("Rate limited")
                in 500..599 -> KeyValidation.Failure("Server error ${r.code}")
                else -> KeyValidation.Failure("HTTP ${r.code}")
            } }
        } catch (t: Throwable) { KeyValidation.Failure(t.message ?: "Network error") }
        finally { runCatching { client.dispatcher.executorService.shutdown(); client.connectionPool.evictAll() } }
    }
}
