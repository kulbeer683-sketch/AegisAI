package com.aegis.ai.routine

import android.content.Context
import android.os.SystemClock
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.pipeline.WorkflowPipelineCoordinator
import com.aegis.ai.vitals.DeviceVitalsMonitor
import com.aegis.ai.vitals.VitalsQuery
import com.aegis.ai.vitals.VitalsResponder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Calendar

class AutonomousRoutineEngine(
    context: Context,
    private val prefs: RoutinePreferences,
    private val workflow: WorkflowPipelineCoordinator,
    private val vitals: DeviceVitalsMonitor,
    private val inEar: InEarNotificationManager?
) {

    private val mutex = Mutex()

    suspend fun handle(trigger: TriggerEvent): Boolean = mutex.withLock {
        if (prefs.isWithinCooldown(trigger.kind, DEBOUNCE_MS)) return@withLock false
        try {
            when (trigger.kind) {
                RoutineKind.BEDTIME -> runBedtime()
                RoutineKind.MORNING_BRIEF -> runMorning()
                RoutineKind.BATTERY_PROTECTION -> runBattery(trigger)
            }
        } catch (ce: CancellationException) { throw ce }
        catch (_: Throwable) { return@withLock false }
        prefs.markFired(trigger.kind)
        true
    }

    fun statusReport(): String {
        val en = prefs.enabledRoutines()
        if (en.isEmpty()) return "कोई रूटीन चालू नहीं है"
        return "चालू रूटीन: ${en.joinToString(", ") { hindiName(it) }}. बैटरी अलर्ट ${prefs.getBatteryProtectionThreshold()}% पर सेट है"
    }

    private suspend fun runBedtime() {
        val actions = listOf(AegisAction.SetDnd(true), AegisAction.VolumeMute(AudioStream.MEDIA, true), AegisAction.SetScreenTimeout(15_000L))
        runCatching { workflow.executeWorkflow(actions, IntentMatch.Language.HINGLISH, voicePrefix = "नाइट रूटीन सक्रिय") }
            .onFailure { speak("नाइट रूटीन लागू नहीं हो सका") }
    }

    private suspend fun runMorning() {
        val s = vitals.current()
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = when { h < 8 -> "सुप्रभात"; h < 10 -> "गुड मॉर्निंग"; else -> "नमस्ते" }
        val report = VitalsResponder.respond(VitalsQuery.FULL_REPORT, s)
        speak("$greet. बैटरी ${s.batteryPercent}%. $report")
    }

    private suspend fun runBattery(t: TriggerEvent) {
        val p = t.snapshot.batteryPercent
        val thr = prefs.getBatteryProtectionThreshold()
        speak(when { p >= 100 -> "बैटरी फुल चार्ज हो चुकी है, चार्जर निकाल दें"; p >= thr -> "बैटरी $p% चार्ज हो चुकी है, चार्जर निकाल दें"; else -> "बैटरी $p% हो गई है" })
    }

    private suspend fun speak(t: String) { runCatching { inEar?.speak(t) } }

    private fun hindiName(k: RoutineKind) = when (k) { RoutineKind.BEDTIME -> "नाइट रूटीन"; RoutineKind.MORNING_BRIEF -> "मॉर्निंग ब्रीफ"; RoutineKind.BATTERY_PROTECTION -> "बैटरी अलर्ट" }

    companion object { const val DEBOUNCE_MS = 60 * 60_000L }
}
