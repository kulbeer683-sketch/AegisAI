package com.aegis.ai.recovery

import android.util.Log
import com.aegis.ai.audio.AudioConfig
import java.util.concurrent.ConcurrentHashMap

object RecoveryRegistry {

    private val handles = ConcurrentHashMap<String, AbortHandle>()

    data class AbortHandle(val name: String, val abort: () -> Unit)

    fun register(name: String, abort: () -> Unit) { handles[name] = AbortHandle(name, abort) }
    fun unregister(name: String) { handles.remove(name) }

    fun abortAll(reason: String): List<String> {
        val invoked = ArrayList<String>(handles.size)
        for (h in handles.values) {
            try { h.abort(); invoked += h.name }
            catch (t: Throwable) { Log.e(TAG, "abort handle '${h.name}' threw", t) }
        }
        return invoked
    }

    fun registeredNames(): List<String> = handles.keys.sorted()
    fun clear() { handles.clear() }

    private const val TAG = AudioConfig.TAG
}
