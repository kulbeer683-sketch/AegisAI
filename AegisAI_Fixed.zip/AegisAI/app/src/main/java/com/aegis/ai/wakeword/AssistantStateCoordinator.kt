package com.aegis.ai.wakeword

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioDspPipeline
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.intent.SpeechIntentEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class AssistantStateCoordinator(
    private val scope: CoroutineScope,
    private val wakeWordDetector: WakeWordDetector,
    private val intentEngine: SpeechIntentEngine,
    private val tonePlayer: WakeTonePlayer,
    private val speakingFlow: StateFlow<Boolean>? = null
) {

    enum class State { PASSIVE_SLEEP, ACTIVE_LISTENING, AWAITING_SLOT, PROCESSING, SPEAKING }

    data class WakeEvent(val keyword: String, val confidence: Float, val timestampMs: Long)

    @Volatile private var stateInternal: State = State.PASSIVE_SLEEP

    private val _state = MutableStateFlow(State.PASSIVE_SLEEP)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _wakeEvents = MutableStateFlow<WakeEvent?>(null)
    val wakeEvents: StateFlow<WakeEvent?> = _wakeEvents.asStateFlow()

    private val transitionMutex = Mutex()
    private var listeningStartedMs = 0L
    private var lastSpeechMs = 0L
    private var watchdogJob: Job? = null
    private var processingSinceMs = 0L

    fun start() {
        speakingFlow?.onEach { s ->
            if (s) transitionTo(State.SPEAKING, "TTS started")
            else if (stateInternal == State.SPEAKING) transitionTo(State.PASSIVE_SLEEP, "TTS ended")
        }?.launchIn(scope)

        watchdogJob?.cancel()
        watchdogJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(WATCHDOG_MS)
                val now = SystemClock.elapsedRealtime()
                when (stateInternal) {
                    State.PROCESSING -> if (processingSinceMs > 0 && now - processingSinceMs > PROCESSING_WATCHDOG_MS) {
                        applyTransition(State.PASSIVE_SLEEP, "processing watchdog")
                    }
                    State.ACTIVE_LISTENING -> {
                        val since = now - listeningStartedMs
                        if (since > MAX_LISTENING_MS + 500L) applyTransition(State.PASSIVE_SLEEP, "listening watchdog")
                    }
                    else -> {}
                }
            }
        }

        scope.launch {
            _state.collect { s -> processingSinceMs = if (s == State.PROCESSING) SystemClock.elapsedRealtime() else 0L }
        }
    }

    fun stop() { watchdogJob?.cancel(); watchdogJob = null }

    fun ingest(frame: AudioDspPipeline.AudioFrame) {
        when (stateInternal) {
            State.PASSIVE_SLEEP -> handlePassive(frame)
            State.ACTIVE_LISTENING, State.AWAITING_SLOT -> handleActive(frame)
            else -> {}
        }
    }

    fun forceWake() {
        onWake(WakeWordDetector.WakeWordEvent("manual", 1.0f, SystemClock.elapsedRealtime()))
    }

    fun notifyIntentMatched(match: IntentMatch) { transitionTo(State.PROCESSING, "intent matched") }
    fun notifyIdle() { transitionTo(State.PASSIVE_SLEEP, "explicit idle") }
    fun enterAwaitingSlot() { listeningStartedMs = SystemClock.elapsedRealtime(); lastSpeechMs = listeningStartedMs; transitionTo(State.AWAITING_SLOT, "slot filling") }
    fun exitAwaitingSlot() { if (stateInternal == State.AWAITING_SLOT) transitionTo(State.PASSIVE_SLEEP, "slot done") }

    private fun handlePassive(frame: AudioDspPipeline.AudioFrame) {
        val w = wakeWordDetector.ingest(frame) ?: return
        onWake(w)
    }

    private fun handleActive(frame: AudioDspPipeline.AudioFrame) {
        val now = SystemClock.elapsedRealtime()
        scope.launch { runCatching { intentEngine.ingest(frame) } }
        if (frame.vad.isSpeech) lastSpeechMs = now
        val sinceStart = now - listeningStartedMs
        val sinceSpeech = now - lastSpeechMs
        if (sinceStart >= MIN_LISTENING_MS && sinceSpeech >= INACTIVITY_TIMEOUT_MS) transitionTo(State.PASSIVE_SLEEP, "silence timeout")
        else if (sinceStart >= MAX_LISTENING_MS) transitionTo(State.PASSIVE_SLEEP, "hard ceiling")
    }

    private fun onWake(w: WakeWordDetector.WakeWordEvent) {
        scope.launch { runCatching { tonePlayer.play() } }
        _wakeEvents.value = WakeEvent(w.keyword, w.confidence, w.timestampMs)
        listeningStartedMs = SystemClock.elapsedRealtime()
        lastSpeechMs = listeningStartedMs
        wakeWordDetector.reset()
        transitionTo(State.ACTIVE_LISTENING, "wake '${w.keyword}'")
    }

    private fun transitionTo(next: State, reason: String) { scope.launch { applyTransition(next, reason) } }

    private suspend fun applyTransition(next: State, reason: String) = transitionMutex.withLock {
        if (stateInternal == next) return@withLock
        stateInternal = next
        _state.value = next
        if (next == State.PASSIVE_SLEEP) intentEngine.exitCallCommandMode()
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val MIN_LISTENING_MS = 5_000L
        private const val INACTIVITY_TIMEOUT_MS = 1_200L
        private const val MAX_LISTENING_MS = 12_000L
        private const val WATCHDOG_MS = 500L
        private const val PROCESSING_WATCHDOG_MS = 20_000L
    }
}
