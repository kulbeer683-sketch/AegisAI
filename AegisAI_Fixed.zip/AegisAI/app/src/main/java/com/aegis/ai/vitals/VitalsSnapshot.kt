package com.aegis.ai.vitals

data class VitalsSnapshot(
    val batteryPercent: Int,
    val batteryStatus: BatteryStatus,
    val batteryPlugged: Plugged,
    val batteryVoltageMv: Int,
    val batteryTempC: Float,
    val thermalStatus: ThermalStatus,
    val networkType: NetworkType,
    val signalLevel: Int,
    val timestampMs: Long
) {
    val isCharging: Boolean
        get() = batteryStatus == BatteryStatus.CHARGING ||
            batteryStatus == BatteryStatus.FULL ||
            batteryPlugged != Plugged.NONE
    val isPluggedAcOrUsb: Boolean
        get() = batteryPlugged == Plugged.AC || batteryPlugged == Plugged.USB
    companion object {
        val EMPTY = VitalsSnapshot(0, BatteryStatus.UNKNOWN, Plugged.NONE, 0, 25f,
            ThermalStatus.UNKNOWN, NetworkType.UNKNOWN, 0, 0L)
    }
}

enum class BatteryStatus { CHARGING, DISCHARGING, FULL, NOT_CHARGING, UNKNOWN }
enum class Plugged { NONE, AC, USB, WIRELESS }
enum class ThermalStatus { NONE, LIGHT, MODERATE, SEVERE, CRITICAL, EMERGENCY, SHUTDOWN, UNKNOWN }
enum class NetworkType { WIFI, ETHERNET, NR_5G, LTE, HSPA, UMTS, GSM, UNKNOWN, NONE }
