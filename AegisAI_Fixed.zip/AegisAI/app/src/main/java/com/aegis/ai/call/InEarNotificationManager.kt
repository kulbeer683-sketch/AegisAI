package com.aegis.ai.call

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.util.Locale
import java.util.UUID

class InEarNotificationManager(context: Context) : AutoCloseable {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val mutex = Mutex()
    private val ready = CompletableDeferred<Boolean>()

    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var current: CompletableDeferred<Unit>? = null

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {}
        override fun onDone(id: String?) { current?.complete(Unit) }
        @Deprecated("legacy") override fun onError(id: String?) { current?.completeExceptionally(IllegalStateException("tts")) }
        override fun onError(id: String?, code: Int) { current?.completeExceptionally(IllegalStateException("tts " + code)) }
    }

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val e = tts
                if (e != null) {
                    val r = e.setLanguage(Locale("hi", "IN"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        e.setLanguage(Locale.getDefault())
                    }
                    e.setPitch(0.88f)
                    e.setSpeechRate(1.04f)
                    e.setOnUtteranceProgressListener(listener)
                    ready.complete(true)
                } else ready.complete(false)
            } else ready.complete(false)
        }
    }

    suspend fun speak(text: String, priority: Boolean = false, streamOverride: Int? = null): Boolean {
        if (text.isBlank()) return true
        _speaking.value = true
        try {
            return speakInternal(text, priority, streamOverride)
        } finally { _speaking.value = false }
    }

    private suspend fun speakInternal(text: String, priority: Boolean, override: Int?): Boolean =
        mutex.withLock {
            val ok = try { withTimeout(2000L) { ready.await() } } catch (_: Throwable) { false }
            if (!ok) return@withLock false
            val e = tts ?: return@withLock false
            val done = CompletableDeferred<Unit>()
            current = done
            val params = Bundle().apply {
                putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, override ?: AudioManager.STREAM_MUSIC)
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            }
            val id = UUID.randomUUID().toString()
            val mode = if (priority) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val r = e.speak(text, mode, params, id)
            if (r != TextToSpeech.SUCCESS) { current = null; return@withLock false }
            try {
                withTimeout(8000L) { done.await() }
                true
            } catch (_: Throwable) { false }
            finally { current = null }
        }

    fun stop() {
        runCatching { tts?.stop() }
        current?.completeExceptionally(IllegalStateException("stopped"))
        current = null
    }

    override fun close() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
    }

    companion object {
        private const val TAG = AudioConfig.TAG
    }
}
