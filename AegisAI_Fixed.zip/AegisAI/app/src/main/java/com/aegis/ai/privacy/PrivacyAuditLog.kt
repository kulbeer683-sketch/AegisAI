package com.aegis.ai.privacy

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

class PrivacyAuditLog(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private val mutex = Mutex()

    data class Entry(val timestampMs: Long, val kind: Kind, val detail: String)
    enum class Kind { TOGGLE, WIPE, KEY_ROTATION }

    suspend fun record(kind: Kind, detail: String) = mutex.withLock {
        runCatching {
            val cur = read().toMutableList()
            cur += Entry(System.currentTimeMillis(), kind, detail.take(160))
            val trim = cur.takeLast(MAX)
            val arr = JSONArray()
            for (e in trim) arr.put(JSONObject().apply { put("ts", e.timestampMs); put("kind", e.kind.name); put("detail", e.detail) })
            prefs.edit().putString(KEY, arr.toString()).apply()
        }
    }

    suspend fun entries(): List<Entry> = mutex.withLock { read() }
    suspend fun lastWipeAt(): Long = mutex.withLock { read().lastOrNull { it.kind == Kind.WIPE }?.timestampMs ?: 0L }
    suspend fun clear() = mutex.withLock { prefs.edit().remove(KEY).apply() }

    private fun read(): List<Entry> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList(arr.length()) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(Entry(o.optLong("ts"), runCatching { Kind.valueOf(o.optString("kind")) }.getOrDefault(Kind.TOGGLE), o.optString("detail")))
                }
            }
        }.getOrDefault(emptyList())
    }

    private companion object {
        const val TAG = AudioConfig.TAG
        const val FILE = "aegis_privacy_audit"
        const val KEY = "audit_entries"
        const val MAX = 256
    }
}
