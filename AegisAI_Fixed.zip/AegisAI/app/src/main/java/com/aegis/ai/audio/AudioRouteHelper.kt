package com.aegis.ai.audio

import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log

object AudioRouteHelper {

    fun hasHeadsetConnected(audioManager: AudioManager): Boolean = try {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        devices.any { d ->
            when (d.type) {
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_USB_HEADSET -> true
                else -> Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET
            }
        }
    } catch (t: Throwable) { Log.w(AudioConfig.TAG, "hasHeadsetConnected failed", t); false }

    fun enableSpeakerphone(audioManager: AudioManager): Boolean = try {
        @Suppress("DEPRECATION") audioManager.isSpeakerphoneOn = true
        true
    } catch (_: Throwable) { false }

    fun disableSpeakerphone(audioManager: AudioManager): Boolean = try {
        @Suppress("DEPRECATION") audioManager.isSpeakerphoneOn = false
        true
    } catch (_: Throwable) { false }
}
