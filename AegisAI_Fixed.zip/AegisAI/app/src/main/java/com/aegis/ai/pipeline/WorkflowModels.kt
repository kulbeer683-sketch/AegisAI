package com.aegis.ai.pipeline

import com.aegis.ai.intent.AegisAction

enum class ExecutionMode { CONCURRENT_FAST, SEQUENTIAL_UI }

data class WorkflowTask(val index: Int, val action: AegisAction, val mode: ExecutionMode)

data class SubActionOutcome(
    val task: WorkflowTask,
    val success: Boolean,
    val message: String,
    val elapsedMs: Long,
    val error: Throwable? = null
)

data class WorkflowOutcome(
    val tasks: List<WorkflowTask>,
    val results: List<SubActionOutcome>,
    val totalElapsedMs: Long,
    val fastGroupElapsedMs: Long,
    val synthesizedReply: String
) {
    val allSucceeded: Boolean get() = results.all { it.success }
    val successCount: Int get() = results.count { it.success }
    val failureCount: Int get() = results.count { !it.success }
    val hasSlotFilling: Boolean get() = tasks.any { it.action.requiresSlotFilling() }
}
