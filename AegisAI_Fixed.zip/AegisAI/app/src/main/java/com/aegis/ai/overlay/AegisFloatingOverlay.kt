package com.aegis.ai.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.aegis.ai.audio.AudioConfig
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

class AegisFloatingOverlay(context: Context) {

    private val appContext = context.applicationContext
    private val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var view: OverlayView? = null
    private var params: WindowManager.LayoutParams? = null
    private var attached = false

    @Volatile private var dismissed = false
    @Volatile private var mode: OverlayMode = OverlayMode.HIDDEN

    fun isAttached(): Boolean = attached
    fun hasPermission(): Boolean = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)

    fun attach(): Boolean {
        if (attached) return true
        if (dismissed) return false
        if (!hasPermission()) return false
        return try {
            val p = buildParams()
            val v = OverlayView(appContext).apply {
                alpha = OverlayConfig.HIDDEN_ALPHA
                setOnTouchListener(touch())
            }
            wm.addView(v, p)
            view = v; params = p; attached = true
            Log.i(AudioConfig.TAG, "HUD attached")
            true
        } catch (t: Throwable) {
            Log.e(AudioConfig.TAG, "HUD attach failed", t)
            view = null; params = null; attached = false
            false
        }
    }

    fun detach() {
        if (!attached) return
        val v = view
        try { if (v != null) wm.removeViewImmediate(v) } catch (_: Throwable) {}
        finally { view = null; params = null; attached = false }
    }

    fun resetDismissal() { dismissed = false }

    fun setMode(m: OverlayMode) {
        if (mode == m) return
        mode = m
        val v = view ?: return
        v.mode = m
        val target = if (m == OverlayMode.HIDDEN) OverlayConfig.HIDDEN_ALPHA else OverlayConfig.ACTIVE_ALPHA
        v.animate().alpha(target).setDuration(OverlayConfig.FADE_MS).start()
    }

    fun setListeningAmplitude(a: Float) { view?.amplitude = a.coerceIn(0f, 1f) }
    fun setSpeakingActive(a: Boolean) { view?.speaking = a }
    fun suspendForPower() { view?.let { it.mode = OverlayMode.HIDDEN; it.alpha = 0f } }
    fun resumeFromPower() { view?.alpha = OverlayConfig.ACTIVE_ALPHA }

    private fun buildParams(): WindowManager.LayoutParams {
        val d = appContext.resources.displayMetrics
        val size = (OverlayConfig.WIDTH_DP * d.density).toInt()
        return WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (OverlayConfig.DEFAULT_X_DP * d.density).toInt()
            y = (OverlayConfig.DEFAULT_Y_DP * d.density).toInt()
        }
    }

    private fun touch(): View.OnTouchListener {
        var initX = 0; var initY = 0; var downX = 0f; var downY = 0f
        return View.OnTouchListener { _, e ->
            val p = params ?: return@OnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initX = p.x; initY = p.y; downX = e.rawX; downY = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = initX + (e.rawX - downX).toInt()
                    p.y = initY + (e.rawY - downY).toInt()
                    runCatching { wm.updateViewLayout(view, p) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - downX
                    if (dx > 200f) { dismissed = true; setMode(OverlayMode.HIDDEN) }
                    true
                }
                else -> false
            }
        }
    }

    /**
     * Minimal HUD view: a pulsing circle whose color reflects the current mode.
     * No allocations in the animation loop — paints created once.
     */
    private class OverlayView(context: Context) : View(context) {

        var mode: OverlayMode = OverlayMode.HIDDEN
        var amplitude: Float = 0f
        var speaking: Boolean = false

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f }
        private var t = 0f

        init { setWillNotDraw(false) }

        override fun onDraw(canvas: Canvas) {
            if (mode == OverlayMode.HIDDEN) return
            t += 0.05f
            if (t > 1000f) t = 0f
            val cx = width / 2f
            val cy = height / 2f
            val base = min(width, height) * 0.30f

            val (coreColor, ringColor) = when (mode) {
                OverlayMode.LISTENING -> Color.parseColor("#2FE6A8") to Color.parseColor("#1B8F69")
                OverlayMode.SPEAKING -> Color.parseColor("#4A9EFF") to Color.parseColor("#1B5FA8")
                OverlayMode.ERROR -> Color.parseColor("#F2A03D") to Color.parseColor("#8A5A1E")
                OverlayMode.HIDDEN -> Color.TRANSPARENT to Color.TRANSPARENT
            }

            val pulse = 1f + 0.15f * sin(t * 2f * PI.toFloat() * 0.6f)
            val amp = 0.4f + amplitude * 0.9f
            val r = base * pulse * amp

            paint.color = coreColor
            paint.alpha = 220
            canvas.drawCircle(cx, cy, r, paint)

            glow.color = ringColor
            glow.alpha = 140
            canvas.drawCircle(cx, cy, r * 1.4f, glow)

            if (speaking) {
                paint.color = Color.WHITE
                paint.alpha = 180
                canvas.drawCircle(cx, cy, r * 0.3f, paint)
            }
            invalidate()
        }
    }
}
