package com.aegis.ai.conversation

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SlotFillingCoordinator(
    private val scope: CoroutineScope,
    private val contextManager: ConversationContextManager,
    private val inEar: InEarNotificationManager?,
    private val onEnterAwaitingSlot: () -> Unit,
    private val onExitAwaitingSlot: () -> Unit
) {

    fun interface ActionRunner {
        suspend fun run(action: AegisAction): SlotActionOutcome
    }
    data class SlotActionOutcome(val success: Boolean, val message: String)

    private val mutex = Mutex()
    private var session: Session? = null
    private var timeoutJob: Job? = null
    private var runner: ActionRunner? = null

    fun setActionRunner(r: ActionRunner) { runner = r }

    private data class Session(
        val type: PendingActionType,
        val originalUtterance: String,
        val language: IntentMatch.Language,
        val startedAtMs: Long,
        val filled: MutableMap<String, String>,
        val remaining: MutableList<String>
    )

    suspend fun startFor(
        action: AegisAction,
        language: IntentMatch.Language = IntentMatch.Language.ENGLISH,
        originalUtterance: String = ""
    ): Boolean {
        val plan = plan(action, language) ?: return false
        mutex.withLock {
            timeoutJob?.cancel()
            session = Session(plan.type, originalUtterance, language,
                SystemClock.elapsedRealtime(), mutableMapOf(), plan.missing.toMutableList())
        }
        contextManager.setPendingAction(
            PendingAction(plan.type, originalUtterance, emptyMap(), plan.missing, SystemClock.elapsedRealtime())
        )
        onEnterAwaitingSlot()
        speak(plan.firstPrompt, language)

        timeoutJob = scope.launch {
            val deadline = SystemClock.elapsedRealtime() + TIMEOUT_MS
            while (isActive) {
                delay(500L)
                if (session == null) return@launch
                if (SystemClock.elapsedRealtime() > deadline) { cancelInternal("timeout"); return@launch }
            }
        }
        return true
    }

    suspend fun provideSlot(text: String): Boolean {
        val s = mutex.withLock { session } ?: return false
        val clean = text.trim()
        if (clean.isBlank()) { speak(promptFor(s), s.language); return true }

        var next: String? = null
        mutex.withLock {
            if (session !== s) return@withLock
            val slot = s.remaining.firstOrNull() ?: return@withLock
            s.filled[slot] = clean
            s.remaining.removeAt(0)
            next = s.remaining.firstOrNull()
            contextManager.setPendingAction(
                PendingAction(s.type, s.originalUtterance, s.filled.toMap(), s.remaining.toList(), s.startedAtMs)
            )
        }
        if (next != null) { speak(promptFor(s), s.language); return true }

        val completed = build(s)
        if (completed == null) { speak("समझ नहीं आया", s.language); cancelInternal("build"); return true }

        mutex.withLock { session = null }
        timeoutJob?.cancel(); timeoutJob = null
        contextManager.setPendingAction(null)
        onExitAwaitingSlot()

        val r = runner ?: return true
        scope.launch {
            val out = try { r.run(completed) }
            catch (_: Throwable) { SlotActionOutcome(false, "नहीं हो सका") }
            if (!completed.isAutomation()) {
                speak(if (out.success) out.message.ifBlank { "ठीक है" }
                      else out.message.ifBlank { "नहीं हो सका" }, s.language)
            }
        }
        return true
    }

    suspend fun cancel() { cancelInternal("cancel") }
    fun isActive(): Boolean = session != null

    private suspend fun cancelInternal(reason: String) {
        val had = mutex.withLock { val h = session != null; session = null; h }
        timeoutJob?.cancel(); timeoutJob = null
        contextManager.setPendingAction(null)
        if (had) { onExitAwaitingSlot(); Log.i(AudioConfig.TAG, "Slot cancel: $reason") }
    }

    private data class Plan(val type: PendingActionType, val missing: List<String>, val firstPrompt: String)

    private fun plan(a: AegisAction, l: IntentMatch.Language): Plan? = when (a) {
        is AegisAction.IncompleteWhatsApp -> {
            val m = buildList {
                if (a.recipient.isNullOrBlank()) add(SLOT_RECIPIENT)
                if (a.message.isNullOrBlank()) add(SLOT_MESSAGE)
            }
            if (m.isEmpty()) null else Plan(PendingActionType.SEND_WHATSAPP, m, prompt(m.first(), l))
        }
        is AegisAction.IncompleteYouTube ->
            if (!a.query.isNullOrBlank()) null else Plan(PendingActionType.PLAY_YOUTUBE, listOf(SLOT_QUERY), prompt(SLOT_QUERY, l))
        else -> null
    }

    private fun promptFor(s: Session): String {
        val slot = s.remaining.firstOrNull() ?: return "समझ नहीं आया"
        return prompt(slot, s.language)
    }

    private fun prompt(slot: String, l: IntentMatch.Language): String {
        val h = l == IntentMatch.Language.HINDI || l == IntentMatch.Language.HINGLISH
        return when (slot) {
            SLOT_RECIPIENT -> if (h) "किसे भेजना है?" else "Who should I send it to?"
            SLOT_MESSAGE -> if (h) "क्या संदेश भेजना है?" else "What's the message?"
            SLOT_QUERY -> if (h) "कौन सा वीडियो चलाऊँ?" else "Which video?"
            else -> if (h) "कृपया बताएं" else "Please tell me"
        }
    }

    private fun build(s: Session): AegisAction? = when (s.type) {
        PendingActionType.SEND_WHATSAPP -> {
            val r = s.filled[SLOT_RECIPIENT]?.trim().orEmpty()
            val m = s.filled[SLOT_MESSAGE]?.trim().orEmpty()
            if (r.isBlank() || m.isBlank()) null else AegisAction.SendWhatsApp(r, m)
        }
        PendingActionType.PLAY_YOUTUBE -> {
            val q = s.filled[SLOT_QUERY]?.trim().orEmpty()
            if (q.isBlank()) null else AegisAction.PlayYouTube(q)
        }
    }

    private suspend fun speak(t: String, l: IntentMatch.Language) {
        runCatching { inEar?.speak(t, priority = true) }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val TIMEOUT_MS = 15_000L
        const val SLOT_RECIPIENT = "recipient"
        const val SLOT_MESSAGE = "message"
        const val SLOT_QUERY = "query"
    }
}
