package com.aegis.ai.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class AudioFocusCoordinator(context: Context) {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mutex = Mutex()
    private var nestCount = 0
    private var request: AudioFocusRequest? = null
    private var owns = false

    private val listener = AudioManager.OnAudioFocusChangeListener { }

    suspend fun duck(): Boolean = mutex.withLock {
        nestCount++
        if (owns) return@withLock true
        val req = ensureRequest()
        val r = runCatching { audioManager.requestAudioFocus(req) }.getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED)
        owns = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        owns
    }

    suspend fun release() = mutex.withLock {
        if (nestCount > 0) nestCount--
        if (nestCount > 0) return@withLock
        if (!owns) return@withLock
        runCatching { request?.let { audioManager.abandonAudioFocusRequest(it) } }
        owns = false
    }

    suspend fun releaseAll() = mutex.withLock {
        nestCount = 0
        if (!owns) return@withLock
        runCatching { request?.let { audioManager.abandonAudioFocusRequest(it) } }
        owns = false
    }

    private fun ensureRequest(): AudioFocusRequest {
        request?.let { return it }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        val req = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setWillPauseWhenDucked(false)
                .setOnAudioFocusChangeListener(listener)
                .build()
        } else {
            AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(listener)
                .build()
        }
        request = req
        return req
    }
}
