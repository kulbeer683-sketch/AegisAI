package com.aegis.ai.location

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import com.aegis.ai.service.AegisForegroundService

class GeofenceTransitionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val ctx = context ?: return
        val i = intent ?: return
        val targetName = i.getStringExtra(EXTRA_TARGET) ?: return
        val target = runCatching { GeoContext.valueOf(targetName) }.getOrNull() ?: return
        val entering = i.getBooleanExtra(LocationManager.KEY_PROXIMITY_ENTERING, false)
        runCatching {
            val svc = AegisForegroundService.geofenceIntent(ctx, target, entering)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) ctx.startForegroundService(svc) else ctx.startService(svc)
        }
    }

    companion object {
        const val ACTION = "com.aegis.ai.action.GEOFENCE_TRANSITION"
        const val EXTRA_TARGET = "com.aegis.ai.extra.GEOFENCE_TARGET"
        const val EXTRA_ENTERING = "com.aegis.ai.extra.GEOFENCE_ENTERING"
        fun buildIntent(c: Context, t: GeoContext): Intent =
            Intent(c, GeofenceTransitionReceiver::class.java).apply { action = ACTION; putExtra(EXTRA_TARGET, t.name) }
    }
}
