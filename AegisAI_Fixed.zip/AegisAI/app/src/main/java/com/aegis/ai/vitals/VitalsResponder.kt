package com.aegis.ai.vitals

import com.aegis.ai.intent.VitalsQuery

object VitalsResponder {

    fun respond(q: VitalsQuery, s: VitalsSnapshot): String = when (q) {
        VitalsQuery.BATTERY_LEVEL -> "बैटरी " + s.batteryPercent + "% है"
        VitalsQuery.BATTERY_STATUS -> {
            val st = when {
                s.batteryStatus == BatteryStatus.FULL -> "फुल चार्ज"
                s.batteryStatus == BatteryStatus.CHARGING -> "चार्जिंग पर"
                s.batteryPlugged == Plugged.AC -> "AC पर चार्जिंग"
                s.batteryPlugged == Plugged.USB -> "USB पर चार्जिंग"
                s.batteryPlugged == Plugged.WIRELESS -> "वायरलेस चार्जिंग"
                else -> "चार्जिंग पर नहीं"
            }
            "बैटरी " + s.batteryPercent + "% है, " + st
        }
        VitalsQuery.BATTERY_TEMP ->
            "बैटरी का तापमान " + "%.1f".format(s.batteryTempC) + " डिग्री है"
        VitalsQuery.THERMAL_STATUS -> {
            val temp = if (s.batteryTempC.isNaN()) "" else "तापमान " + "%.1f".format(s.batteryTempC) + " डिग्री, "
            val st = when (s.thermalStatus) {
                ThermalStatus.NONE -> "सामान्य"
                ThermalStatus.LIGHT -> "हल्की गर्मी"
                ThermalStatus.MODERATE -> "मध्यम गर्मी"
                ThermalStatus.SEVERE -> "अधिक गर्मी"
                ThermalStatus.CRITICAL -> "गंभीर गर्मी"
                ThermalStatus.EMERGENCY -> "आपातकालीन गर्मी"
                ThermalStatus.SHUTDOWN -> "डिवाइस बंद होने वाला है"
                ThermalStatus.UNKNOWN -> "जानकारी उपलब्ध नहीं"
            }
            temp + st
        }
        VitalsQuery.NETWORK_STATUS -> when (s.networkType) {
            NetworkType.WIFI -> "वाईफाई कनेक्टेड"
            NetworkType.ETHERNET -> "ईथरनेट कनेक्टेड"
            NetworkType.NR_5G -> "5G नेटवर्क"
            NetworkType.LTE -> "4G LTE नेटवर्क"
            NetworkType.HSPA -> "HSPA नेटवर्क"
            NetworkType.UMTS -> "3G नेटवर्क"
            NetworkType.GSM -> "2G नेटवर्क"
            NetworkType.UNKNOWN -> "नेटवर्क अज्ञात"
            NetworkType.NONE -> "नेटवर्क बंद है"
        }
        VitalsQuery.FULL_REPORT -> buildString {
            append("बैटरी ").append(s.batteryPercent).append("%, ")
            append(if (s.isCharging) "चार्जिंग, " else "चार्जिंग पर नहीं, ")
            append("तापमान ").append("%.0f".format(s.batteryTempC)).append(" डिग्री, ")
            append(when (s.networkType) {
                NetworkType.WIFI -> "वाईफाई"
                NetworkType.ETHERNET -> "ईथरनेट"
                NetworkType.NR_5G -> "5G"
                NetworkType.LTE -> "LTE"
                NetworkType.HSPA -> "HSPA"
                NetworkType.UMTS -> "3G"
                NetworkType.GSM -> "2G"
                NetworkType.UNKNOWN -> "नेटवर्क अज्ञात"
                NetworkType.NONE -> "नेटवर्क बंद"
            })
        }
    }
}
