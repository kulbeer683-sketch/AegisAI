package com.aegis.ai.hardware

import android.content.Intent

sealed class ControllerResult {
    data class Success(val message: String) : ControllerResult()
    data class Failure(val message: String) : ControllerResult()
    data class NeedsUserIntent(val intent: Intent, val message: String) : ControllerResult()
}
