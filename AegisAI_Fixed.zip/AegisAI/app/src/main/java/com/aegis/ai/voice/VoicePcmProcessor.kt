package com.aegis.ai.voice

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow

object VoicePcmProcessor {

    private const val CEILING_RATIO = 0.90f
    private const val CEILING = 0.955f * Short.MAX_VALUE.toFloat()

    fun applyGainAndLimit(pcm: ShortArray, gainDb: Float = DEFAULT_GAIN_DB): ShortArray {
        if (pcm.isEmpty()) return pcm
        val g = 10.0.pow(gainDb / 20.0).toFloat()
        if (g == 1.0f) {
            var m = 0
            for (s in pcm) { val a = abs(s.toInt()); if (a > m) m = a }
            if (m < CEILING) return pcm.copyOf()
        }
        val out = ShortArray(pcm.size)
        val knee = CEILING_RATIO * Short.MAX_VALUE.toFloat()
        for (i in pcm.indices) {
            val a = pcm[i].toFloat() * g
            val av = abs(a)
            val lim = if (av <= knee) a else {
                val sign = if (a < 0f) -1f else 1f
                val excess = av - knee
                val comp = knee + (CEILING - knee) * (1f - exp(-excess / (CEILING - knee)))
                sign * comp.coerceAtMost(CEILING)
            }
            out[i] = lim.toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return out
    }

    fun normalize(pcm: ShortArray, targetPeakDb: Float = DEFAULT_NORMALIZE_PEAK_DB): ShortArray {
        if (pcm.isEmpty()) return pcm
        var peak = 0
        for (s in pcm) { val a = abs(s.toInt()); if (a > peak) peak = a }
        if (peak == 0) return pcm.copyOf()
        val target = 10.0.pow(targetPeakDb / 20.0).toFloat() * Short.MAX_VALUE.toFloat()
        val g = target / peak.toFloat()
        val out = ShortArray(pcm.size)
        for (i in pcm.indices) out[i] = (pcm[i] * g).coerceIn(Short.MIN_VALUE.toFloat(), Short.MAX_VALUE.toFloat()).toInt().toShort()
        return out
    }

    fun peakDbfs(pcm: ShortArray): Float {
        if (pcm.isEmpty()) return -Float.MAX_VALUE
        var peak = 0
        for (s in pcm) { val a = abs(s.toInt()); if (a > peak) peak = a }
        if (peak == 0) return -Float.MAX_VALUE
        return (20.0 * kotlin.math.log10(peak / Short.MAX_VALUE.toDouble())).toFloat()
    }

    const val DEFAULT_GAIN_DB = 3.5f
    const val DEFAULT_NORMALIZE_PEAK_DB = -3.0f
}
