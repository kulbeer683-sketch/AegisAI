package com.aegis.ai.media

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MediaSessionController(context: Context) {

    private val appContext = context.applicationContext
    private val msm = appContext.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mutex = Mutex()

    private val _count = MutableStateFlow(0)
    val activeSessionCount: StateFlow<Int> = _count.asStateFlow()

    sealed class MediaTransportResult {
        data class Success(val via: TransportPath, val description: String) : MediaTransportResult()
        data class Failure(val reason: String) : MediaTransportResult()
        enum class TransportPath { SESSION, KEY_EVENT }
    }

    suspend fun play() = op { it.play() } to KeyEvent.KEYCODE_MEDIA_PLAY to "play"
    suspend fun pause() = runOp("pause", KeyEvent.KEYCODE_MEDIA_PAUSE) { it.pause() }
    suspend fun next() = runOp("next", KeyEvent.KEYCODE_MEDIA_NEXT) { it.skipToNext() }
    suspend fun previous() = runOp("previous", KeyEvent.KEYCODE_MEDIA_PREVIOUS) { it.skipToPrevious() }
    suspend fun stop() = runOp("stop", KeyEvent.KEYCODE_MEDIA_STOP) { it.stop() }

    suspend fun togglePlayPause(): MediaTransportResult = mutex.withLock {
        val c = pick()
        if (c != null) {
            val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
            try {
                if (playing) c.transportControls.pause() else c.transportControls.play()
                return@withLock MediaTransportResult.Success(MediaTransportResult.TransportPath.SESSION, if (playing) "paused" else "played")
            } catch (_: Throwable) {}
        }
        dispatchKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, "toggle")
    }

    fun hasActiveSession(): Boolean = pick() != null

    private suspend fun runOp(label: String, keyCode: Int, block: (MediaController.TransportControls) -> Unit): MediaTransportResult = mutex.withLock {
        val c = pick()
        if (c != null) {
            try { block(c.transportControls); return@withLock MediaTransportResult.Success(MediaTransportResult.TransportPath.SESSION, "$label via ${c.packageName}") }
            catch (_: Throwable) {}
        }
        dispatchKey(keyCode, label)
    }

    private fun dispatchKey(code: Int, label: String): MediaTransportResult = try {
        val t = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
        MediaTransportResult.Success(MediaTransportResult.TransportPath.KEY_EVENT, "$label via hardware key")
    } catch (t: Throwable) { MediaTransportResult.Failure("$label failed: ${t.message}") }

    private fun pick(): MediaController? {
        val token: ComponentName = AegisNotificationListenerService.componentNameOrNull() ?: run { _count.value = 0; return null }
        val sessions = try {
            @Suppress("DEPRECATION")
            msm.getActiveSessions(token).orEmpty()
        } catch (_: SecurityException) { emptyList() } catch (_: Throwable) { emptyList() }
        _count.value = sessions.size
        if (sessions.isEmpty()) return null
        sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }?.let { return it }
        sessions.firstOrNull { val s = it.playbackState?.state; s == PlaybackState.STATE_BUFFERING || s == PlaybackState.STATE_PAUSED }?.let { return it }
        return sessions.first()
    }

    private fun op(block: (MediaController.TransportControls) -> Unit): Unit = Unit

    companion object { private const val TAG = AudioConfig.TAG }
}
