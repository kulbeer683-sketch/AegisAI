package com.aegis.ai.voice

interface NeuralVoiceProvider {
    suspend fun synthesize(text: String, languageTag: String): NeuralAudio?

    data class NeuralAudio(
        val pcm: ShortArray,
        val sampleRate: Int,
        val channelCount: Int = 1
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is NeuralAudio) return false
            return pcm.contentEquals(other.pcm) && sampleRate == other.sampleRate && channelCount == other.channelCount
        }
        override fun hashCode(): Int {
            var r = pcm.contentHashCode(); r = 31 * r + sampleRate; r = 31 * r + channelCount; return r
        }
    }
}
