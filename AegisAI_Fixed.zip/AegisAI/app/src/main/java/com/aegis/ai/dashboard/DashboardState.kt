package com.aegis.ai.dashboard

import com.aegis.ai.decision.Phase4DiagnosticsPayload
import com.aegis.ai.power.ThrottleTier
import com.aegis.ai.vitals.VitalsSnapshot
import com.aegis.ai.wakeword.AssistantStateCoordinator

data class DashboardState(
    val serviceRunning: Boolean = false,
    val pipelineRunning: Boolean = false,
    val assistantState: AssistantStateCoordinator.State? = null,
    val vitals: VitalsSnapshot? = null,
    val heartbeat: Map<String, Boolean> = emptyMap(),
    val diagnostics: Phase4DiagnosticsPayload? = null,
    val geminiKeyPresent: Boolean = false,
    val voicePitch: Float = 0.88f,
    val voiceRate: Float = 1.04f,
    val lastError: String? = null,
    val permissions: List<PermissionItem> = emptyList(),
    val permissionStatus: Map<String, Boolean> = emptyMap(),
    val privacyCloudEnabled: Boolean = true,
    val privacyScreenVisionEnabled: Boolean = true,
    val privacyCameraVisionEnabled: Boolean = true,
    val privacyLocationRoutinesEnabled: Boolean = true,
    val throttleTier: ThrottleTier = ThrottleTier.NORMAL,
    val activeWakeLocks: Int = 0,
    val releasedLeaks: Long = 0L
) {
    val grantedCount: Int get() = permissionStatus.count { it.value }
    val totalCount: Int get() = permissionStatus.size
    val allRequiredGranted: Boolean get() = permissions.filter { it.required }.all { permissionStatus[it.id] == true }
}

sealed class KeyValidation {
    data object Idle : KeyValidation()
    data object Validating : KeyValidation()
    data class Success(val maskedKey: String) : KeyValidation()
    data class Failure(val reason: String) : KeyValidation()
}

data class Phase4DiagnosticsPayload(
    val healthy: Boolean = true, val errorCount: Int = 0,
    val enabledRoutineCount: Int = 0, val cachedHighPriorityCount: Int = 0,
    val memoryFactCount: Int = 0, val decisionQueueDepth: Int = 0,
    val errors: List<String> = emptyList()
) {
    companion object { val EMPTY = Phase4DiagnosticsPayload() }
}
