package com.aegis.ai.pipeline

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.ActionExecutor
import com.aegis.ai.intent.IntentMatch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class WorkflowPipelineCoordinator(
    private val scope: CoroutineScope,
    private val executor: ActionExecutor,
    private val inEar: InEarNotificationManager?
) {
    private val mutex = Mutex()

    suspend fun executeWorkflow(
        actions: List<AegisAction>,
        language: IntentMatch.Language = IntentMatch.Language.ENGLISH,
        voicePrefix: String? = null
    ): WorkflowOutcome = mutex.withLock {
        val t0 = SystemClock.elapsedRealtime()
        val tasks = actions.mapIndexed { i, a -> WorkflowTask(i, a, ActionClassifier.classify(a)) }
        val results = runParallelAware(tasks)
        val total = SystemClock.elapsedRealtime() - t0
        val fast = results.filter { it.task.mode == ExecutionMode.CONCURRENT_FAST }
            .maxOfOrNull { it.elapsedMs } ?: 0L
        val synth = FeedbackSynthesizer.synthesize(results, language)
        val reply = buildString {
            val p = voicePrefix?.trim()
            if (!p.isNullOrEmpty()) {
                append(p)
                if (synth.isNotBlank()) { append(". "); append(synth) }
            } else append(synth)
        }
        if (reply.isNotBlank()) runCatching { inEar?.speak(reply) }
        WorkflowOutcome(tasks, results, total, fast, reply)
    }

    private suspend fun runParallelAware(tasks: List<WorkflowTask>): List<SubActionOutcome> = coroutineScope {
        val fast = tasks.filter { it.mode == ExecutionMode.CONCURRENT_FAST }
        val ui = tasks.filter { it.mode == ExecutionMode.SEQUENTIAL_UI }
        val f = if (fast.isNotEmpty())
            async(Dispatchers.Default) { fast.map { async(Dispatchers.Default) { run(it) } }.awaitAll() }
        else null
        val u = if (ui.isNotEmpty())
            async(Dispatchers.Default) { ui.map { run(it) } }
        else null
        val fr = f?.await() ?: emptyList()
        val ur = u?.await() ?: emptyList()
        (fr + ur).sortedBy { it.task.index }
    }

    private suspend fun run(task: WorkflowTask): SubActionOutcome {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            val o = executor.execute(task.action)
            SubActionOutcome(task, o.success, o.message, o.elapsedMs)
        } catch (ce: CancellationException) { throw ce }
        catch (t: Throwable) {
            Log.e(AudioConfig.TAG, "task failed", t)
            SubActionOutcome(task, false, t.message ?: "threw", SystemClock.elapsedRealtime() - t0, t)
        }
    }
}
