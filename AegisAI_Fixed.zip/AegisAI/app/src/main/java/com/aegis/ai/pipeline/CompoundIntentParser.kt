package com.aegis.ai.pipeline

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentGrammar
import com.aegis.ai.intent.IntentMatch

class CompoundIntentParser {

    data class Segment(val index: Int, val rawText: String, val dependsOnPrevious: Boolean)

    private data class Marker(val start: Int, val end: Int, val isSeq: Boolean)

    fun parse(text: String): List<Segment> {
        val n = normalize(text)
        if (n.isEmpty()) return emptyList()
        val markers = findMarkers(n)
        if (markers.isEmpty()) return listOf(Segment(0, n, false))

        val out = ArrayList<Segment>(markers.size + 1)
        var last = 0
        for (m in markers) {
            val c = n.substring(last, m.start).trim()
            if (c.isNotEmpty()) out += Segment(out.size, c, out.isNotEmpty() && m.isSeq)
            last = m.end
        }
        val tail = n.substring(last).trim()
        if (tail.isNotEmpty()) out += Segment(out.size, tail, out.isNotEmpty() && markers.last().isSeq)
        return if (out.size <= 1) listOf(Segment(0, n, false)) else out
    }

    fun parseToActions(text: String): List<AegisAction> {
        val segs = parse(text)
        if (segs.isEmpty()) return emptyList()
        val out = ArrayList<AegisAction>(segs.size)
        for (s in segs) {
            val m: IntentMatch = IntentGrammar.parse(s.rawText)
            out += m.actions
        }
        return out
    }

    private fun findMarkers(n: String): List<Marker> {
        val all = ArrayList<Marker>()
        for (p in SEQ) findAll(n, p).forEach { all += Marker(it.first, it.second, true) }
        for (p in PAR) findAll(n, p).forEach { all += Marker(it.first, it.second, false) }
        if (all.isEmpty()) return emptyList()
        val sorted = all.sortedWith(compareBy<Marker> { it.start }.thenByDescending { it.end - it.start })
        val res = ArrayList<Marker>(sorted.size)
        var last = 0
        for (m in sorted) { if (m.start < last) continue; res += m; last = m.end }
        return res
    }

    private fun findAll(h: String, needle: String): List<Pair<Int, Int>> {
        val lh = h.lowercase(); val ln = needle.lowercase()
        val out = ArrayList<Pair<Int, Int>>()
        var from = 0
        while (true) {
            val i = lh.indexOf(ln, from); if (i < 0) break
            if (ln.all { it.code < 0x0900 }) {
                val b = if (i == 0) null else lh[i - 1]
                val ai = i + ln.length
                val a = if (ai >= lh.length) null else lh[ai]
                val ok = (b == null || !b.isLetterOrDigit()) && (a == null || !a.isLetterOrDigit())
                if (ok) out += i to ai
            } else out += i to (i + ln.length)
            from = i + ln.length
        }
        return out
    }

    private fun normalize(t: String) = t.lowercase().replace(Regex("[\\p{Punct}&&[^\\u0900-\\u097F,]]"), " ").replace(Regex("\\s+"), " ").trim()

    private companion object {
        val SEQ = listOf("after that", "then", "uske baad", "ke baad", "उसके बाद", "के बाद", "फिर")
        val PAR = listOf("as well as", "and", "also", "aur", "bhi", "और", "तथा", "भी")
    }
}
