package com.aegis.ai.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.WindowManager
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureEngine(
    context: Context,
    private val defaultTargetMaxWidth: Int = DEFAULT_WIDTH,
    private val defaultJpegQuality: Int = DEFAULT_QUALITY,
    private val powerCoordinator: com.aegis.ai.power.PowerBudgetCoordinator? = null
) {

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val mutex = Mutex()

    data class CaptureResult(
        val jpegBytes: ByteArray, val width: Int, val height: Int,
        val isBlankSuspected: Boolean, val capturedAtMs: Long
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is CaptureResult) return false
            return jpegBytes.contentEquals(other.jpegBytes) && width == other.width && height == other.height
        }
        override fun hashCode(): Int = jpegBytes.contentHashCode()
    }

    sealed class CaptureError {
        data object NoPermission : CaptureError()
        data class Timeout(val ms: Long) : CaptureError()
        data class ImageReaderFailure(val message: String) : CaptureError()
        data class EmptyFrame(val message: String) : CaptureError()
        data class CompressFailed(val message: String) : CaptureError()
        data class Internal(val message: String) : CaptureError()
    }

    sealed class Outcome {
        data class Success(val result: CaptureResult) : Outcome()
        data class Failure(val error: CaptureError) : Outcome()
    }

    fun hasPermission(): Boolean = MediaProjectionHolder.isGranted()

    suspend fun captureJpeg(
        targetMaxWidth: Int = defaultTargetMaxWidth,
        jpegQuality: Int = defaultJpegQuality,
        timeoutMs: Long = 3_500L
    ): Outcome = mutex.withLock {
        if (powerCoordinator?.allowsCapability(com.aegis.ai.power.PowerBudgetCoordinator.Capability.SCREEN_VISION) == false) {
            return@withLock Outcome.Failure(CaptureError.Internal("power_critical"))
        }
        if (!hasPermission()) return@withLock Outcome.Failure(CaptureError.NoPermission)

        val code = MediaProjectionHolder.resultCode
        val data = MediaProjectionHolder.resultData ?: return@withLock Outcome.Failure(CaptureError.NoPermission)

        val mpm = appContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
            ?: return@withLock Outcome.Failure(CaptureError.Internal("no MPM"))

        try {
            withTimeoutOrNull(timeoutMs) { performCapture(mpm, code, data, targetMaxWidth, jpegQuality) }
                ?: Outcome.Failure(CaptureError.Timeout(timeoutMs))
        } catch (ce: CancellationException) { throw ce }
        catch (t: Throwable) { Outcome.Failure(CaptureError.Internal(t.message ?: "unknown")) }
    }

    private suspend fun performCapture(
        mpm: MediaProjectionManager, code: Int, data: Intent,
        targetMaxWidth: Int, jpegQuality: Int
    ): Outcome = withContext(Dispatchers.Main.immediate) {
        val completion = CompletableDeferred<Outcome>()
        var session: Session? = null
        try {
            val projection = mpm.getMediaProjection(code, data) ?: return@withContext Outcome.Failure(CaptureError.ImageReaderFailure("null projection"))
            val m = readScreenMetrics()
            if (m.width <= 0 || m.height <= 0) { runCatching { projection.stop() }; return@withContext Outcome.Failure(CaptureError.ImageReaderFailure("bad dims")) }

            val ht = HandlerThread("aegis-vision").apply { start() }
            val bh = Handler(ht.looper)
            val reader = try {
                ImageReader.newInstance(m.width, m.height, PixelFormat.RGBA_8888, 2)
            } catch (t: Throwable) {
                runCatching { projection.stop() }; runCatching { ht.quitSafely() }
                return@withContext Outcome.Failure(CaptureError.ImageReaderFailure(t.message ?: "newInstance"))
            }

            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    if (!completion.isCompleted) completion.complete(Outcome.Failure(CaptureError.Internal("projection stopped")))
                }
            }
            runCatching { projection.registerCallback(cb, mainHandler) }

            val vd = try {
                projection.createVirtualDisplay("aegis-vision", m.width, m.height, m.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, bh)
            } catch (t: Throwable) {
                runCatching { projection.unregisterCallback(cb) }; runCatching { reader.close() }
                runCatching { projection.stop() }; runCatching { ht.quitSafely() }
                return@withContext Outcome.Failure(CaptureError.Internal(t.message ?: "createVD"))
            }

            session = Session(projection, reader, vd, ht, cb, mainHandler)

            reader.setOnImageAvailableListener({ r ->
                val img: Image? = runCatching { r.acquireLatestImage() }.getOrNull()
                if (img == null) return@setOnImageAvailableListener
                try {
                    val o = processImage(img, m.width, m.height, targetMaxWidth, jpegQuality)
                    if (!completion.isCompleted) completion.complete(o)
                } finally {
                    runCatching { img.close() }
                    mainHandler.post { session?.release() }
                }
            }, bh)

            completion.await()
        } catch (t: Throwable) {
            session?.release()
            Outcome.Failure(CaptureError.Internal(t.message ?: "unknown"))
        }
    }

    private fun processImage(img: Image, cw: Int, ch: Int, targetMaxW: Int, jpegQ: Int): Outcome {
        val plane = img.planes.firstOrNull() ?: return Outcome.Failure(CaptureError.EmptyFrame("no plane"))
        val buf = plane.buffer; val ps = plane.pixelStride; val rs = plane.rowStride
        if (buf.remaining() <= 0) return Outcome.Failure(CaptureError.EmptyFrame("empty buffer"))
        if (ps < 4) return Outcome.Failure(CaptureError.Internal("pixelStride=$ps"))

        val pad = rs - ps * cw
        val pw = cw + pad / ps

        val pb = try { Bitmap.createBitmap(pw, ch, Bitmap.Config.ARGB_8888) } catch (t: Throwable) { return Outcome.Failure(CaptureError.Internal("bitmap")) }
        try { buf.rewind(); pb.copyPixelsFromBuffer(buf) } catch (t: Throwable) { pb.recycle(); return Outcome.Failure(CaptureError.Internal("copy")) }

        val cropped = if (pad != 0) {
            try { Bitmap.createBitmap(pb, 0, 0, cw, ch).also { pb.recycle() } }
            catch (t: Throwable) { pb.recycle(); return Outcome.Failure(CaptureError.Internal("crop")) }
        } else pb

        try {
            val blank = isLikelyBlank(cropped)
            val scaled = if (targetMaxW in 1 until cropped.width) {
                val s = targetMaxW.toFloat() / cropped.width
                val nh = (cropped.height * s).toInt().coerceAtLeast(1)
                try { Bitmap.createScaledBitmap(cropped, targetMaxW, nh, true) } catch (_: Throwable) { cropped }
            } else cropped

            val bytes = try {
                val baos = ByteArrayOutputStream(192 * 1024)
                if (!scaled.compress(Bitmap.CompressFormat.JPEG, jpegQ, baos)) throw IllegalStateException("compress false")
                baos.toByteArray()
            } catch (t: Throwable) {
                if (scaled !== cropped) scaled.recycle()
                return Outcome.Failure(CaptureError.CompressFailed(t.message ?: "compress"))
            }

            val fw = scaled.width; val fh = scaled.height
            if (scaled !== cropped) scaled.recycle()
            return Outcome.Success(CaptureResult(bytes, fw, fh, blank, SystemClock.elapsedRealtime()))
        } finally { cropped.recycle() }
    }

    private fun isLikelyBlank(b: Bitmap): Boolean = try {
        val sw = 32; val sh = 32
        val s = if (b.width == sw && b.height == sh) b else Bitmap.createScaledBitmap(b, sw, sh, false)
        try {
            val px = IntArray(sw * sh); s.getPixels(px, 0, sw, 0, 0, sw, sh)
            var dark = 0; var uniform = 0; val first = px[0]
            for (p in px) {
                val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
                if (r < 12 && g < 12 && bl < 12) dark++
                if (p == first) uniform++
            }
            val tot = px.size.toFloat()
            dark / tot > 0.98f || uniform / tot > 0.99f
        } finally { if (s !== b) s.recycle() }
    } catch (_: Throwable) { false }

    private data class ScreenMetrics(val width: Int, val height: Int, val densityDpi: Int)

    private fun readScreenMetrics(): ScreenMetrics = try {
        val d = appContext.resources.displayMetrics.densityDpi
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val wm = appContext.getSystemService(WindowManager::class.java)
            val b = wm.currentWindowMetrics.bounds
            ScreenMetrics(b.width(), b.height(), d)
        } else {
            val dm = appContext.resources.displayMetrics
            ScreenMetrics(dm.widthPixels, dm.heightPixels, d)
        }
    } catch (_: Throwable) { val dm = appContext.resources.displayMetrics; ScreenMetrics(dm.widthPixels, dm.heightPixels, dm.densityDpi) }

    private class Session(
        private val projection: MediaProjection, private val reader: ImageReader,
        private val vd: VirtualDisplay, private val ht: HandlerThread,
        private val cb: MediaProjection.Callback, private val mh: Handler
    ) {
        private val released = AtomicBoolean(false)
        fun release() {
            if (!released.compareAndSet(false, true)) return
            mh.post {
                runCatching { reader.setOnImageAvailableListener(null, null) }
                runCatching { reader.close() }
                runCatching { projection.unregisterCallback(cb) }
                runCatching { vd.release() }
                runCatching { projection.stop() }
                runCatching { ht.quitSafely() }
            }
        }
    }

    private companion object {
        const val TAG = AudioConfig.TAG
        const val DEFAULT_WIDTH = 720
        const val DEFAULT_QUALITY = 78
    }
}

object MediaProjectionHolder {
    @Volatile var resultCode: Int = Activity.RESULT_CANCELED; private set
    @Volatile var resultData: Intent? = null; private set
    fun isGranted(): Boolean = resultCode == Activity.RESULT_OK && resultData != null
    fun set(code: Int, data: Intent?) { resultCode = code; resultData = data }
    fun clear() { resultCode = Activity.RESULT_CANCELED; resultData = null }
}
