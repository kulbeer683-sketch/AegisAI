package com.aegis.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.aegis.ai.MainActivity
import com.aegis.ai.R
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioDspPipeline
import com.aegis.ai.call.CallAutomationManager
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.conversation.ConversationContextManager
import com.aegis.ai.conversation.SlotFillingCoordinator
import com.aegis.ai.dashboard.DiagnosticsSpeaker
import com.aegis.ai.dashboard.Phase4DiagnosticsPayload
import com.aegis.ai.decision.AutonomousDecisionMatrix
import com.aegis.ai.decision.CapabilityRouter
import com.aegis.ai.decision.DecisionOrigin
import com.aegis.ai.decision.ExecutionCapability
import com.aegis.ai.hardware.ConnectivityController
import com.aegis.ai.hardware.FlashlightController
import com.aegis.ai.hardware.VolumeController
import com.aegis.ai.intent.ActionExecutor
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.FastIntentRouter
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.intent.RouteOutcome
import com.aegis.ai.intent.SpeechIntentEngine
import com.aegis.ai.memory.LongTermMemoryManager
import com.aegis.ai.overlay.AegisFloatingOverlay
import com.aegis.ai.overlay.OverlayMode
import com.aegis.ai.pipeline.WorkflowPipelineCoordinator
import com.aegis.ai.privacy.MemoryWipeManager
import com.aegis.ai.privacy.WipeOutcome
import com.aegis.ai.security.SecureKeyStorage
import com.aegis.ai.vitals.DeviceVitalsMonitor
import com.aegis.ai.voice.VoicePersonaPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class AegisForegroundService : LifecycleService() {

    private lateinit var pipeline: AudioDspPipeline
    private lateinit var intentEngine: SpeechIntentEngine
    private lateinit var flashlight: FlashlightController
    private lateinit var volume: VolumeController
    private lateinit var connectivity: ConnectivityController
    private lateinit var inEar: InEarNotificationManager
    private lateinit var vitals: DeviceVitalsMonitor
    private lateinit var memory: LongTermMemoryManager
    private lateinit var conversation: ConversationContextManager
    private lateinit var wipeManager: MemoryWipeManager
    private lateinit var overlay: AegisFloatingOverlay
    private lateinit var slotFilling: SlotFillingCoordinator
    private lateinit var callManager: CallAutomationManager
    private lateinit var secureKeys: SecureKeyStorage
    private lateinit var voicePrefs: VoicePersonaPreferences
    private lateinit var capabilityRouter: CapabilityRouter
    private lateinit var decisionMatrix: AutonomousDecisionMatrix
    private lateinit var workflow: WorkflowPipelineCoordinator
    private lateinit var executor: ActionExecutor
    private lateinit var router: FastIntentRouter

    private var frameJob: Job? = null
    private var isForeground = false

    override fun onCreate() {
        super.onCreate()
        Log.i(AudioConfig.TAG, "AegisForegroundService onCreate")

        pipeline = AudioDspPipeline(applicationContext)
        intentEngine = SpeechIntentEngine(lifecycleScope)
        flashlight = FlashlightController(applicationContext)
        volume = VolumeController(applicationContext)
        connectivity = ConnectivityController(applicationContext)
        inEar = InEarNotificationManager(applicationContext)
        vitals = DeviceVitalsMonitor(applicationContext); vitals.start()
        memory = LongTermMemoryManager(applicationContext)
        conversation = ConversationContextManager()
        wipeManager = MemoryWipeManager(applicationContext, memory, conversation)
        overlay = AegisFloatingOverlay(applicationContext)
        secureKeys = SecureKeyStorage(applicationContext)
        voicePrefs = VoicePersonaPreferences(applicationContext)
        callManager = CallAutomationManager(applicationContext, lifecycleScope); callManager.start()

        slotFilling = SlotFillingCoordinator(
            lifecycleScope, conversation, inEar,
            onEnterAwaitingSlot = { Log.d(AudioConfig.TAG, "AWAITING_SLOT") },
            onExitAwaitingSlot = { Log.d(AudioConfig.TAG, "PASSIVE_SLEEP") }
        )

        capabilityRouter = CapabilityRouter(
            isCloudAvailable = { false },
            isScreenVisionAvailable = { false },
            isCameraVisionAvailable = { false }
        )

        decisionMatrix = AutonomousDecisionMatrix(lifecycleScope) { req, _ ->
            val m = req.match ?: return@AutonomousDecisionMatrix false
            val outcome = router.route(m)
            outcome.allSucceeded
        }

        createChannel()

        // Two-phase init: workflow needs the executor, executor needs slotFilling.
        // Wire executor with slot filling set to null first; then set the runner.
        executor = ActionExecutor(
            context = applicationContext,
            flashlight = flashlight,
            volume = volume,
            connectivity = connectivity,
            inEar = inEar,
            vitals = vitals,
            memory = memory,
            wipeManager = wipeManager,
            overlay = overlay,
            callManager = callManager,
            diagnosticsProvider = { buildDiagnostics() }
        )
        workflow = WorkflowPipelineCoordinator(lifecycleScope, executor, inEar)
        router = FastIntentRouter(executor, lifecycleScope)

        slotFilling.setActionRunner { a ->
            val o = executor.execute(a)
            SlotFillingCoordinator.SlotActionOutcome(o.success, o.message)
        }

        intentEngine.bindTo(pipeline)
        frameJob = lifecycleScope.launch(Dispatchers.Default) {
            pipeline.frames.onEach { /* wake word / VAD hooks can go here */ }.launchIn(this)
        }

        intentEngine.matches.onEach { match ->
            if (slotFilling.isActive()) {
                if (slotFilling.provideSlot(match.rawText)) return@onEach
            }
            val outcome = router.route(match)
            handleOutcome(outcome)
        }.launchIn(lifecycleScope)

        callManager.events.onEach { e ->
            when (e) {
                is com.aegis.ai.call.CallEvent.IncomingAnnouncementReady ->
                    lifecycleScope.launch { inEar.speak("Incoming call from " + e.identity) }
                else -> {}
            }
        }.launchIn(lifecycleScope)

        overlay.attach()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> {
                lifecycleScope.launch { pipeline.stop(); stopForegroundAndSelf() }
                return START_NOT_STICKY
            }
            ACTION_TEXT -> {
                promoteToForeground()
                val text = intent.getStringExtra(EXTRA_TEXT).orEmpty()
                if (text.isNotBlank()) lifecycleScope.launch { intentEngine.submitText(text) }
                return START_STICKY
            }
            ACTION_START, null -> {
                promoteToForeground()
                lifecycleScope.launch {
                    val ok = pipeline.start(false)
                    if (!ok) { Log.e(AudioConfig.TAG, "Pipeline failed"); stopForegroundAndSelf() }
                    else inEar.speak("एजिस ऑनलाइन। सभी सब-सिस्टम सक्रिय हैं, सर।", priority = true)
                }
                return START_STICKY
            }
            ACTION_SELF_CHECK -> {
                promoteToForeground()
                lifecycleScope.launch {
                    val p = buildDiagnostics()
                    inEar.speak(DiagnosticsSpeaker.speak(p), priority = true)
                }
                return START_STICKY
            }
        }
        promoteToForeground()
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }

    override fun onDestroy() {
        frameJob?.cancel()
        runCatching { decisionMatrix.shutdown() }
        runCatching { callManager.close() }
        runCatching { vitals.stop() }
        runCatching { inEar.close() }
        runCatching { overlay.detach() }
        runCatching { intentEngine.shutdown() }
        runCatching { flashlight.close() }
        runCatching { pipeline.shutdown() }
        isForeground = false
        super.onDestroy()
    }

    private fun handleOutcome(outcome: RouteOutcome) {
        when (outcome.path) {
            RouteOutcome.Path.COGNITIVE -> {
                lifecycleScope.launch {
                    inEar.speak("क्लाउड सुविधा इस बिल्ड में उपलब्ध नहीं है", priority = false)
                }
            }
            else -> {
                outcome.executed.forEach { o ->
                    Log.i(AudioConfig.TAG, (if (o.success) "OK " else "ERR ") +
                        o.action::class.simpleName + " " + o.elapsedMs + "ms — " + o.message)
                }
            }
        }
    }

    private fun buildDiagnostics(): Phase4DiagnosticsPayload {
        val v = vitals.current()
        val errors = mutableListOf<String>()
        if (pipeline.stats.value.state == AudioDspPipeline.State.ERROR) errors += "audio"
        if (v.batteryPercent in 1..10) errors += "battery"
        return Phase4DiagnosticsPayload(
            healthy = errors.isEmpty(),
            errorCount = errors.size,
            errors = errors,
            memoryFactCount = memory.factCount(),
            decisionQueueDepth = decisionMatrix.queueDepth(),
            throttleTier = if (v.batteryTempC >= 43f) "CRITICAL"
                else if (v.batteryTempC >= 39f) "THROTTLED" else "NORMAL"
        )
    }

    private fun promoteToForeground() {
        if (isForeground) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
        isForeground = true
    }

    private fun stopForegroundAndSelf() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        isForeground = false
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val m = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (m.getNotificationChannel(CHANNEL_ID) != null) return
        m.createNotificationChannel(
            NotificationChannel(CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.notif_channel_desc)
                setShowBadge(false)
            }
        )
    }

    private fun buildNotification(): Notification {
        val content = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AegisForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(R.drawable.ic_aegis_notification)
            .setContentIntent(content)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val ACTION_START = "com.aegis.ai.action.START"
        const val ACTION_STOP = "com.aegis.ai.action.STOP"
        const val ACTION_TEXT = "com.aegis.ai.action.TEXT"
        const val ACTION_SELF_CHECK = "com.aegis.ai.action.SELF_CHECK"
        const val EXTRA_TEXT = "com.aegis.ai.extra.TEXT"

        private const val CHANNEL_ID = "aegis_foreground_service"
        private const val NOTIFICATION_ID = 0xA361

        fun startIntent(context: Context): Intent =
            Intent(context, AegisForegroundService::class.java).apply { action = ACTION_START }
        fun stopIntent(context: Context): Intent =
            Intent(context, AegisForegroundService::class.java).apply { action = ACTION_STOP }
        fun textIntent(context: Context, text: String): Intent =
            Intent(context, AegisForegroundService::class.java).apply {
                action = ACTION_TEXT; putExtra(EXTRA_TEXT, text)
            }
        fun selfCheckIntent(context: Context): Intent =
            Intent(context, AegisForegroundService::class.java).apply { action = ACTION_SELF_CHECK }
    }
}
