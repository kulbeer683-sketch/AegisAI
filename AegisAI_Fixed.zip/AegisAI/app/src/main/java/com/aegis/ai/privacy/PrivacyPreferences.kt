package com.aegis.ai.privacy

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PrivacyPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private val _cloud = MutableStateFlow(readBool(KEY_CLOUD, true))
    val cloudReasoning: StateFlow<Boolean> = _cloud.asStateFlow()

    private val _screen = MutableStateFlow(readBool(KEY_SCREEN, true))
    val screenVision: StateFlow<Boolean> = _screen.asStateFlow()

    private val _camera = MutableStateFlow(readBool(KEY_CAMERA, true))
    val cameraVision: StateFlow<Boolean> = _camera.asStateFlow()

    private val _location = MutableStateFlow(readBool(KEY_LOCATION, true))
    val locationRoutines: StateFlow<Boolean> = _location.asStateFlow()

    fun isCloudReasoningEnabled() = _cloud.value
    fun isScreenVisionEnabled() = _screen.value
    fun isCameraVisionEnabled() = _camera.value
    fun isLocationRoutinesEnabled() = _location.value

    fun setCloudReasoningEnabled(v: Boolean) { writeBool(KEY_CLOUD, v); _cloud.value = v }
    fun setScreenVisionEnabled(v: Boolean) { writeBool(KEY_SCREEN, v); _screen.value = v }
    fun setCameraVisionEnabled(v: Boolean) { writeBool(KEY_CAMERA, v); _camera.value = v }
    fun setLocationRoutinesEnabled(v: Boolean) { writeBool(KEY_LOCATION, v); _location.value = v }

    fun refresh() {
        _cloud.value = readBool(KEY_CLOUD, true)
        _screen.value = readBool(KEY_SCREEN, true)
        _camera.value = readBool(KEY_CAMERA, true)
        _location.value = readBool(KEY_LOCATION, true)
    }

    private fun readBool(k: String, d: Boolean) = runCatching { prefs.getBoolean(k, d) }.getOrDefault(d)
    private fun writeBool(k: String, v: Boolean) = runCatching { prefs.edit().putBoolean(k, v).apply() }

    private companion object {
        const val TAG = AudioConfig.TAG
        const val FILE = "aegis_privacy"
        const val KEY_CLOUD = "capability_cloud_reasoning"
        const val KEY_SCREEN = "capability_screen_vision"
        const val KEY_CAMERA = "capability_camera_vision"
        const val KEY_LOCATION = "capability_location_routines"
    }
}
