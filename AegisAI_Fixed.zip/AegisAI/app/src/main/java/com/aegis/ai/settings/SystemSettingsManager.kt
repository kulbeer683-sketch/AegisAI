package com.aegis.ai.settings

import android.app.NotificationManager
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.appcompat.app.AppCompatDelegate
import com.aegis.ai.hardware.ControllerResult

class SystemSettingsManager(context: Context) {

    private val appContext = context.applicationContext
    private val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val ui = appContext.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
    private val lm = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    fun hasDndAccess(): Boolean = runCatching { nm.isNotificationPolicyAccessGranted }.getOrDefault(false)
    fun hasWriteSettingsAccess(): Boolean = runCatching { Settings.System.canWrite(appContext) }.getOrDefault(false)

    fun isDndEnabled(): Boolean = runCatching { nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL }.getOrDefault(false)

    fun setDnd(enabled: Boolean): ControllerResult {
        if (!hasDndAccess()) return ControllerResult.NeedsUserIntent(dndAccessIntent(), "DND access required")
        val t = if (enabled) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL
        return try {
            nm.setInterruptionFilter(t)
            ControllerResult.Success(if (enabled) "DND enabled" else "DND disabled")
        } catch (_: SecurityException) { ControllerResult.NeedsUserIntent(dndAccessIntent(), "DND access revoked") }
        catch (t2: Throwable) { ControllerResult.Failure(t2.message ?: "dnd failed") }
    }

    fun dndAccessIntent(): Intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun isAutoRotationEnabled(): Boolean = runCatching { Settings.System.getInt(appContext.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1 }.getOrDefault(false)

    fun setAutoRotation(enabled: Boolean): ControllerResult {
        if (!hasWriteSettingsAccess()) return ControllerResult.NeedsUserIntent(writeSettingsIntent(), "Write settings required")
        return try {
            val ok = Settings.System.putInt(appContext.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (enabled) 1 else 0)
            if (ok) ControllerResult.Success(if (enabled) "Auto-rotate on" else "Auto-rotate off")
            else ControllerResult.Failure("putInt false")
        } catch (_: SecurityException) { ControllerResult.NeedsUserIntent(writeSettingsIntent(), "WRITE_SETTINGS revoked") }
        catch (t: Throwable) { ControllerResult.Failure(t.message ?: "rotation failed") }
    }

    fun writeSettingsIntent(): Intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.fromParts("package", appContext.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun isSystemNightModeEnabled(): Boolean = runCatching { (appContext.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES }.getOrDefault(false)

    fun setNightMode(enabled: Boolean): ControllerResult {
        try { AppCompatDelegate.setDefaultNightMode(if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO) }
        catch (t: Throwable) { return ControllerResult.Failure(t.message ?: "night failed") }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching { ui.setApplicationNightMode(if (enabled) UiModeManager.MODE_NIGHT_YES else UiModeManager.MODE_NIGHT_NO) }
        }
        return ControllerResult.Success(if (enabled) "Dark mode on" else "Light mode on")
    }

    fun getScreenTimeoutMs(): Long = runCatching { Settings.System.getLong(appContext.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, DEFAULT_TIMEOUT) }.getOrDefault(DEFAULT_TIMEOUT)

    fun setScreenTimeout(ms: Long): ControllerResult {
        if (!hasWriteSettingsAccess()) return ControllerResult.NeedsUserIntent(writeSettingsIntent(), "Write settings required")
        val c = ms.coerceIn(MIN_TIMEOUT, MAX_TIMEOUT)
        return try {
            val ok = Settings.System.putLong(appContext.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, c)
            if (ok) ControllerResult.Success("Screen timeout set to ${formatTimeout(c)}") else ControllerResult.Failure("putLong false")
        } catch (_: SecurityException) { ControllerResult.NeedsUserIntent(writeSettingsIntent(), "WRITE_SETTINGS revoked") }
        catch (t: Throwable) { ControllerResult.Failure(t.message ?: "timeout failed") }
    }

    fun formatTimeout(ms: Long): String = when { ms < 60_000 -> "${ms / 1000} seconds"; ms % 60_000 == 0L -> "${ms / 60_000} minutes"; else -> "${ms / 60_000} min ${(ms % 60_000) / 1000} s" }

    fun isAirplaneModeEnabled(): Boolean = runCatching { Settings.Global.getInt(appContext.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 }.getOrDefault(false)
    fun requestAirplaneModePanel(): ControllerResult = ControllerResult.NeedsUserIntent(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), "Airplane mode requires confirmation")

    fun isLocationEnabled(): Boolean = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) lm.isLocationEnabled
        else { @Suppress("DEPRECATION") lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }
    }.getOrDefault(false)

    fun requestLocationPanel(): ControllerResult = ControllerResult.NeedsUserIntent(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), "Location requires confirmation")

    private companion object {
        const val DEFAULT_TIMEOUT = 30_000L
        const val MIN_TIMEOUT = 15_000L
        const val MAX_TIMEOUT = 30 * 60_000L
    }
}
