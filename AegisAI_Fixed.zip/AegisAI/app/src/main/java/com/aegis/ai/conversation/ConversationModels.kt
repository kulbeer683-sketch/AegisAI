package com.aegis.ai.conversation

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch

data class ConversationTurn(
    val id: Long,
    val userText: String,
    val assistantText: String?,
    val actions: List<AegisAction>,
    val timestampMs: Long,
    val language: IntentMatch.Language
)

data class PendingAction(
    val type: PendingActionType,
    val originalUtterance: String,
    val filledSlots: Map<String, String>,
    val missingSlots: List<String>,
    val createdAtMs: Long
)

enum class PendingActionType { SEND_WHATSAPP, PLAY_YOUTUBE }

data class EntityMemory(
    val activeContact: String?,
    val lastTargetApp: String?,
    val pendingAction: PendingAction?
) {
    companion object { val EMPTY = EntityMemory(null, null, null) }
}

data class ConversationSnapshot(
    val turns: List<ConversationTurn>,
    val entities: EntityMemory,
    val lastActivityMs: Long
) {
    companion object { val EMPTY = ConversationSnapshot(emptyList(), EntityMemory.EMPTY, 0L) }
}
