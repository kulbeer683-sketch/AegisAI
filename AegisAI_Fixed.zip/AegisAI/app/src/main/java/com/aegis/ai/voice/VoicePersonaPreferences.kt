package com.aegis.ai.voice

import android.content.Context

class VoicePersonaPreferences(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("aegis_voice_persona", Context.MODE_PRIVATE)

    fun getPitch(): Float = prefs.getFloat(KEY_PITCH, DEFAULT_PITCH).coerceIn(MIN_PITCH, MAX_PITCH)
    fun getRate(): Float = prefs.getFloat(KEY_RATE, DEFAULT_RATE).coerceIn(MIN_RATE, MAX_RATE)
    fun setPitch(v: Float) { prefs.edit().putFloat(KEY_PITCH, v.coerceIn(MIN_PITCH, MAX_PITCH)).apply() }
    fun setRate(v: Float) { prefs.edit().putFloat(KEY_RATE, v.coerceIn(MIN_RATE, MAX_RATE)).apply() }
    fun adjustPitch(d: Float): Float { val n = (getPitch() + d).coerceIn(MIN_PITCH, MAX_PITCH); setPitch(n); return n }
    fun adjustRate(d: Float): Float { val n = (getRate() + d).coerceIn(MIN_RATE, MAX_RATE); setRate(n); return n }
    fun resetPitchAndRate() { prefs.edit().putFloat(KEY_PITCH, DEFAULT_PITCH).putFloat(KEY_RATE, DEFAULT_RATE).apply() }

    companion object {
        private const val KEY_PITCH = "pitch_multiplier"
        private const val KEY_RATE = "rate_multiplier"
        const val DEFAULT_PITCH = 0.88f
        const val DEFAULT_RATE = 1.04f
        const val MIN_PITCH = 0.55f
        const val MAX_PITCH = 1.45f
        const val MIN_RATE = 0.70f
        const val MAX_RATE = 1.50f
        const val PITCH_STEP = 0.04f
        const val RATE_STEP = 0.05f
    }
}
