package com.aegis.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aegis.ai.accessibility.UiNodeResolver
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class AegisAccessibilityService : AccessibilityService() {

    @Volatile var foregroundPackage: String? = null; private set

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
        Log.i(AudioConfig.TAG, "Accessibility connected")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            e.packageName?.toString()?.let { if (it != foregroundPackage) foregroundPackage = it }
        }
    }

    override fun onInterrupt() { Log.w(AudioConfig.TAG, "Accessibility interrupted") }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    suspend fun goHome(): Boolean = global(GLOBAL_ACTION_HOME)
    suspend fun goBack(): Boolean = global(GLOBAL_ACTION_BACK)
    suspend fun showRecents(): Boolean = global(GLOBAL_ACTION_RECENTS)
    suspend fun openNotifications(): Boolean = global(GLOBAL_ACTION_NOTIFICATIONS)

    suspend fun performLockScreen(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
        return global(GLOBAL_ACTION_LOCK_SCREEN)
    }

    suspend fun tap(x: Float, y: Float): Boolean = gesture(Path().apply { moveTo(x, y) }, 50L)

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long = 280L): Boolean =
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, dur)

    suspend fun findNode(pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? =
        withContext(Dispatchers.Main.immediate) {
            val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext null
            try { UiNodeResolver.findByPredicate(root, pred) } finally { UiNodeResolver.recycle(root) }
        }

    suspend fun awaitNode(timeoutMs: Long, intervalMs: Long = 100L, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? =
        withContext(Dispatchers.Main.immediate) {
            withTimeoutOrNull(timeoutMs) {
                while (isActive) {
                    val root = runCatching { rootInActiveWindow }.getOrNull()
                    if (root != null) {
                        val m = try { UiNodeResolver.findByPredicate(root, pred) } catch (_: Throwable) { null }
                        finally { UiNodeResolver.recycle(root) }
                        if (m != null) return@withTimeoutOrNull m
                    }
                    delay(intervalMs.coerceAtLeast(40L))
                }
                null
            }
        }

    suspend fun clickNode(node: AccessibilityNodeInfo?): Boolean = withContext(Dispatchers.Main.immediate) {
        val n = node ?: return@withContext false
        try {
            val t = UiNodeResolver.findClickableAncestor(n) ?: n
            t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (_: Throwable) { false }
    }

    suspend fun clickByText(text: String): Boolean = withContext(Dispatchers.Main.immediate) {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext false
        try { UiNodeResolver.clickByText(root, text) } finally { UiNodeResolver.recycle(root) }
    }

    suspend fun snapshotText(max: Int = 2000): String = withContext(Dispatchers.Main.immediate) {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext ""
        try { UiNodeResolver.extractTextSnapshot(root, max) } finally { UiNodeResolver.recycle(root) }
    }

    private suspend fun global(action: Int): Boolean = withContext(Dispatchers.Main.immediate) {
        runCatching { performGlobalAction(action) }.getOrDefault(false)
    }

    private suspend fun gesture(path: Path, durationMs: Long): Boolean =
        withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { cont ->
                val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
                val desc = GestureDescription.Builder().addStroke(stroke).build()
                val cb = object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                    override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
                }
                val ok = runCatching { dispatchGesture(desc, cb, null) }.getOrDefault(false)
                if (!ok && cont.isActive) cont.resume(false)
            }
        }

    @Suppress("unused")
    private fun bounds(): Rect = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getSystemService(WindowManager::class.java).currentWindowMetrics.bounds
        } else {
            val dm = resources.displayMetrics; Rect(0, 0, dm.widthPixels, dm.heightPixels)
        }
    } catch (_: Throwable) {
        val dm = resources.displayMetrics; Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    companion object {
        @Volatile private var instance: AegisAccessibilityService? = null
        fun get(): AegisAccessibilityService? = instance
        fun isConnected(): Boolean = instance != null
    }
}
