package com.aegis.ai.routine

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.power.PowerBudgetCoordinator
import com.aegis.ai.power.ThrottleTier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class RoutineSchedulerService(
    private val context: Context,
    private val scope: CoroutineScope,
    private val trigger: ContextTriggerEngine,
    private val engine: AutonomousRoutineEngine,
    private val prefs: RoutinePreferences
) {

    private var job: Job? = null
    @Volatile private var started = false
    @Volatile private var power: PowerBudgetCoordinator? = null

    fun attachPowerCoordinator(p: PowerBudgetCoordinator) { power = p }

    fun start() {
        if (started) return; started = true
        trigger.start()
        job = scope.launch {
            runCatching { evaluateOnce() }
            while (isActive) {
                delay(currentTick())
                runCatching { if (shouldSkip()) continue else evaluateOnce() }
            }
        }
        schedulePeriodic()
    }

    fun stop() {
        if (!started) return; started = false
        job?.cancel(); job = null
        trigger.stop()
        runCatching { WorkManager.getInstance(context).cancelUniqueWork(WORK) }
    }

    suspend fun evaluateOnce(): List<RoutineKind> {
        val trigs = trigger.evaluate()
        if (trigs.isEmpty()) return emptyList()
        val fired = ArrayList<RoutineKind>(trigs.size)
        for (t in trigs) { if (runCatching { engine.handle(t) }.getOrDefault(false)) fired += t.kind }
        return fired
    }

    fun setEnabled(k: RoutineKind, v: Boolean) { prefs.setEnabled(k, v) }
    fun statusReport() = engine.statusReport()

    private fun currentTick(): Long = when (power?.currentTier()) {
        ThrottleTier.CRITICAL -> TICK * 4
        ThrottleTier.THROTTLED -> TICK * 2
        else -> TICK
    }

    private fun shouldSkip() = power?.currentTier() == ThrottleTier.CRITICAL

    private fun schedulePeriodic() {
        runCatching {
            val req = PeriodicWorkRequestBuilder<RoutinePeriodicWorker>(30, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().build())
                .addTag(WORK)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val TICK = 60_000L
        private const val WORK = "aegis_routine_periodic"
    }
}
