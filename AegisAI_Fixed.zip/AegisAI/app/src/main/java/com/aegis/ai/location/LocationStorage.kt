package com.aegis.ai.location

import android.content.Context
import android.content.SharedPreferences
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

class LocationStorage(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val lock = Any()

    fun saveZone(z: LearnedZone) {
        val p = prefix(z.context) ?: return
        prefs.edit().putLong("${p}_lat", z.latitude.toRawBits()).putLong("${p}_lon", z.longitude.toRawBits())
            .putFloat("${p}_r", z.radiusMeters).putString("${p}_ssid", z.ssid)
            .putLong("${p}_t", z.learnedAtMs).apply()
    }

    fun loadZone(c: GeoContext): LearnedZone? {
        val p = prefix(c) ?: return null
        if (!prefs.contains("${p}_lat")) return null
        return runCatching {
            LearnedZone(c, Double.fromBits(prefs.getLong("${p}_lat", 0L)), Double.fromBits(prefs.getLong("${p}_lon", 0L)),
                prefs.getFloat("${p}_r", DEFAULT_R), prefs.getString("${p}_ssid", null), prefs.getLong("${p}_t", 0L))
        }.getOrNull()
    }

    fun getLastContext(): GeoContext = runCatching { prefs.getString(KEY_CTX, null)?.let { GeoContext.valueOf(it) } }.getOrNull() ?: GeoContext.UNKNOWN
    fun setLastContext(c: GeoContext) { prefs.edit().putString(KEY_CTX, c.name).apply() }
    fun getLastTransitionMs(): Long = prefs.getLong(KEY_TRANS, 0L)
    fun setLastTransitionMs(ms: Long) { prefs.edit().putLong(KEY_TRANS, ms).apply() }

    fun addReminder(r: LocationReminder) = synchronized(lock) { writeReminders(readReminders() + r) }
    fun remindersFor(t: GeoContext): List<LocationReminder> = synchronized(lock) { readReminders().filter { it.target == t } }
    fun allReminders(): List<LocationReminder> = synchronized(lock) { readReminders() }
    fun removeReminders(ids: Collection<String>) = synchronized(lock) {
        if (ids.isEmpty()) return@synchronized
        writeReminders(readReminders().filterNot { it.id in ids.toHashSet() })
    }

    private fun readReminders(): List<LocationReminder> {
        val raw = prefs.getString(KEY_REM, null) ?: return emptyList()
        return runCatching { json.decodeFromString(ListSerializer(LocationReminder.serializer()), raw) }.getOrDefault(emptyList())
    }

    private fun writeReminders(list: List<LocationReminder>) {
        runCatching { prefs.edit().putString(KEY_REM, json.encodeToString(ListSerializer(LocationReminder.serializer()), list)).apply() }
    }

    private fun prefix(c: GeoContext): String? = when (c) { GeoContext.HOME -> "home"; GeoContext.WORK -> "work"; else -> null }

    companion object {
        private const val FILE = "aegis_location"
        private const val KEY_CTX = "last_context"
        private const val KEY_TRANS = "last_transition_ms"
        private const val KEY_REM = "reminders_json"
        const val DEFAULT_R = 150f
        const val COARSE_R = 500f
    }
}
