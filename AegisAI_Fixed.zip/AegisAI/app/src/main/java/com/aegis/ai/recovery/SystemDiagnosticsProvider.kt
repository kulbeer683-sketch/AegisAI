package com.aegis.ai.recovery

fun interface SystemDiagnosticsProvider {
    fun buildHealthSummary(): String
}
