package com.aegis.ai.recovery

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.service.AegisAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

class UiWatchdogSupervisor(
    private val scope: CoroutineScope,
    private val accessibilityProvider: () -> AegisAccessibilityService?,
    private val inEar: InEarNotificationManager?
) {

    private val sessions = ConcurrentHashMap<String, WatchdogSession>()
    private val sessionMutex = Mutex()
    private var tickerJob: Job? = null
    private val lastAdvisoryMs = AtomicLong(0L)

    @Volatile private var started = false

    fun start() {
        if (started) return
        started = true
        tickerJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(TICK_MS)
                runCatching { checkTimeouts() }
            }
        }
    }

    fun stop() {
        if (!started) return
        started = false
        tickerJob?.cancel(); tickerJob = null
        sessions.clear()
    }

    fun startSession(description: String, initialPhase: String, deadlineMs: Long = DEFAULT_PHASE_DEADLINE_MS): String {
        val id = UUID.randomUUID().toString()
        sessions[id] = WatchdogSession(id, initialPhase, SystemClock.elapsedRealtime(), deadlineMs, description)
        return id
    }

    fun beginPhase(sessionId: String, phaseName: String, deadlineMs: Long = DEFAULT_PHASE_DEADLINE_MS) {
        val prev = sessions[sessionId] ?: return
        sessions[sessionId] = prev.copy(phaseName = phaseName, startedAtMs = SystemClock.elapsedRealtime(), deadlineMs = deadlineMs)
    }

    fun endSession(sessionId: String) { sessions.remove(sessionId) }
    fun activeSessionCount(): Int = sessions.size

    suspend fun <T> guardPhase(sessionId: String, phaseName: String, deadlineMs: Long = DEFAULT_PHASE_DEADLINE_MS, block: suspend () -> T): T? {
        beginPhase(sessionId, phaseName, deadlineMs)
        return withTimeoutOrNull(deadlineMs + GRACE_MS) { block() }
    }

    private suspend fun checkTimeouts() {
        val now = SystemClock.elapsedRealtime()
        val expired = sessions.values.filter { it.isExpired(now) }
        if (expired.isEmpty()) return
        for (s in expired) {
            sessionMutex.withLock {
                if (sessions.remove(s.id) == null) return@withLock
                handleTimeout(s)
            }
        }
    }

    private suspend fun handleTimeout(s: WatchdogSession) {
        Log.w(TAG, "Session ${s.id} exceeded deadline phase='${s.phaseName}'")
        runCatching { RecoveryRegistry.abortAll("watchdog timeout ${s.id}") }
        try {
            accessibilityProvider()?.let {
                it.goBack()
                delay(150L)
            }
        } catch (ce: CancellationException) { throw ce } catch (_: Throwable) {}
        speakAdvisory()
    }

    private suspend fun speakAdvisory() {
        val mgr = inEar ?: return
        val now = SystemClock.elapsedRealtime()
        val prev = lastAdvisoryMs.get()
        if (now - prev < ADVISORY_DEBOUNCE_MS) return
        if (!lastAdvisoryMs.compareAndSet(prev, now)) return
        runCatching { mgr.speak("क्रिया पूरी नहीं हो सकी, स्क्रीन रीसेट की गई", priority = true) }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val DEFAULT_PHASE_DEADLINE_MS = 4_000L
        private const val TICK_MS = 500L
        private const val GRACE_MS = 500L
        private const val ADVISORY_DEBOUNCE_MS = 45_000L
    }
}
