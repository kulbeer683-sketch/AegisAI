package com.aegis.ai.location

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat

class GeofenceRegistrar(context: Context, private val storage: LocationStorage) {

    private val appContext = context.applicationContext
    private val lm = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    @Suppress("MissingPermission")
    fun register(target: GeoContext): Boolean {
        if (target != GeoContext.HOME && target != GeoContext.WORK) return false
        if (!hasAny()) return false
        val z = storage.loadZone(target) ?: return false
        val intent = GeofenceTransitionReceiver.buildIntent(appContext, target)
        val pi = PendingIntent.getBroadcast(appContext, reqCode(target), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return try {
            runCatching { lm.removeProximityAlert(pi) }
            lm.addProximityAlert(z.latitude, z.longitude, z.radiusMeters.coerceAtLeast(100f), -1L, pi)
            true
        } catch (_: Throwable) { false }
    }

    fun unregister(target: GeoContext) {
        if (target != GeoContext.HOME && target != GeoContext.WORK) return
        val intent = GeofenceTransitionReceiver.buildIntent(appContext, target)
        val pi = PendingIntent.getBroadcast(appContext, reqCode(target), intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        runCatching { lm.removeProximityAlert(pi) }
    }

    fun registerAll() { for (t in listOf(GeoContext.HOME, GeoContext.WORK)) if (storage.loadZone(t) != null) register(t) }
    fun unregisterAll() { for (t in listOf(GeoContext.HOME, GeoContext.WORK)) unregister(t) }

    private fun hasAny(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun reqCode(t: GeoContext) = if (t == GeoContext.HOME) 0xA361 else 0xA362
}
