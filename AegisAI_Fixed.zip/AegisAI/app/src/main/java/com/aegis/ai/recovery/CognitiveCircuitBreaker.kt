package com.aegis.ai.recovery

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class CognitiveCircuitBreaker(
    private val failureThreshold: Int = DEFAULT_FAILURE_THRESHOLD,
    private val openDurationMs: Long = DEFAULT_OPEN_DURATION_MS
) {

    private val stateRef = AtomicReference(CircuitState.CLOSED)
    private val failures = AtomicLong(0L)
    private val openedAtMs = AtomicLong(0L)
    private val successes = AtomicLong(0L)
    private val totalFailures = AtomicLong(0L)
    private val rejections = AtomicLong(0L)

    fun state(): CircuitState {
        val cur = stateRef.get()
        if (cur == CircuitState.OPEN) {
            val elapsed = SystemClock.elapsedRealtime() - openedAtMs.get()
            if (elapsed >= openDurationMs) {
                if (stateRef.compareAndSet(CircuitState.OPEN, CircuitState.HALF_OPEN)) {
                    Log.i(TAG, "Breaker OPEN → HALF_OPEN after ${elapsed}ms")
                }
                return CircuitState.HALF_OPEN
            }
        }
        return stateRef.get()
    }

    fun shouldAttempt(): Boolean = when (state()) {
        CircuitState.CLOSED, CircuitState.HALF_OPEN -> true
        CircuitState.OPEN -> { rejections.incrementAndGet(); false }
    }

    fun recordSuccess() {
        successes.incrementAndGet(); failures.set(0L)
        val prev = stateRef.getAndSet(CircuitState.CLOSED)
        if (prev != CircuitState.CLOSED) Log.i(TAG, "Breaker $prev → CLOSED")
    }

    fun recordTransientFailure() {
        totalFailures.incrementAndGet()
        when (stateRef.get()) {
            CircuitState.HALF_OPEN -> {
                openedAtMs.set(SystemClock.elapsedRealtime())
                stateRef.set(CircuitState.OPEN)
            }
            CircuitState.CLOSED -> {
                val n = failures.incrementAndGet()
                if (n >= failureThreshold) {
                    openedAtMs.set(SystemClock.elapsedRealtime())
                    stateRef.set(CircuitState.OPEN)
                    Log.w(TAG, "Breaker CLOSED → OPEN after $n failures")
                }
            }
            CircuitState.OPEN -> {}
        }
    }

    fun recordPersistentFailure() { Log.d(TAG, "Persistent failure recorded — breaker stays ${stateRef.get()}") }

    fun statusString(): String = buildString {
        append("breaker=").append(state())
        append(" consec=").append(failures.get())
        append(" ok=").append(successes.get())
        append(" fail=").append(totalFailures.get())
    }

    fun reset() { stateRef.set(CircuitState.CLOSED); failures.set(0L); openedAtMs.set(0L) }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val DEFAULT_FAILURE_THRESHOLD = 3
        const val DEFAULT_OPEN_DURATION_MS = 2 * 60_000L
    }
}
