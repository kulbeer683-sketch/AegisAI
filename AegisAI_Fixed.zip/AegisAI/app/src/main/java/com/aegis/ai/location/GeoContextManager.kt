package com.aegis.ai.location

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

class GeoContextManager(context: Context, private val storage: LocationStorage) {

    private val appContext = context.applicationContext
    private val lm = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val wm = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val mutex = Mutex()

    fun hasFineLocation() = check(Manifest.permission.ACCESS_FINE_LOCATION)
    fun hasCoarseLocation() = check(Manifest.permission.ACCESS_COARSE_LOCATION)
    fun hasAnyLocation() = hasFineLocation() || hasCoarseLocation()
    fun hasBackgroundLocation(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return true
        return check(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    private fun check(p: String) = ContextCompat.checkSelfPermission(appContext, p) == PackageManager.PERMISSION_GRANTED

    suspend fun query(): GeoQueryResult = mutex.withLock {
        if (!hasAnyLocation()) return@withLock GeoQueryResult(GeoContext.UNKNOWN, GeoQueryResult.Confidence.LOW, null, null, null, 0L)
        val ssid = readSsid()
        val loc = readLast()

        if (ssid != null) {
            for (t in listOf(GeoContext.HOME, GeoContext.WORK)) {
                val z = storage.loadZone(t) ?: continue
                if (z.ssid != null && z.ssid.equals(ssid, true)) return@withLock GeoQueryResult(t, GeoQueryResult.Confidence.HIGH, z.latitude, z.longitude, ssid, 0L)
            }
        }
        if (loc != null) {
            val coarseOnly = !hasFineLocation()
            for (t in listOf(GeoContext.HOME, GeoContext.WORK)) {
                val z = storage.loadZone(t) ?: continue
                val r = if (coarseOnly) maxOf(z.radiusMeters, LocationStorage.COARSE_R) else z.radiusMeters
                val d = haversine(loc.latitude, loc.longitude, z.latitude, z.longitude)
                if (d <= r) return@withLock GeoQueryResult(t, if (coarseOnly) GeoQueryResult.Confidence.MEDIUM else GeoQueryResult.Confidence.HIGH, loc.latitude, loc.longitude, ssid, SystemClock.elapsedRealtime() - loc.time)
            }
            if (loc.hasSpeed() && loc.speed > TRANSIT_MPS && loc.speed.isFinite()) return@withLock GeoQueryResult(GeoContext.TRANSIT, GeoQueryResult.Confidence.MEDIUM, loc.latitude, loc.longitude, ssid, SystemClock.elapsedRealtime() - loc.time)
            return@withLock GeoQueryResult(GeoContext.UNKNOWN, GeoQueryResult.Confidence.LOW, loc.latitude, loc.longitude, ssid, SystemClock.elapsedRealtime() - loc.time)
        }
        GeoQueryResult(GeoContext.UNKNOWN, GeoQueryResult.Confidence.LOW, null, null, ssid, 0L)
    }

    suspend fun learnCurrentZone(target: GeoContext): Boolean = mutex.withLock {
        if (target != GeoContext.HOME && target != GeoContext.WORK) return@withLock false
        val loc = readLast() ?: return@withLock false
        val ssid = readSsid()
        val r = if (!hasFineLocation()) LocationStorage.COARSE_R else LocationStorage.DEFAULT_R
        storage.saveZone(LearnedZone(target, loc.latitude, loc.longitude, r, ssid))
        true
    }

    @Suppress("DEPRECATION")
    private fun readSsid(): String? {
        if (!hasFineLocation()) return null
        val active = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(active) ?: return null
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null
        return runCatching {
            val info = wm?.connectionInfo ?: return null
            info.ssid?.trim('"')?.takeIf { it.isNotEmpty() && it != "<unknown ssid>" }
        }.getOrNull()
    }

    @Suppress("MissingPermission")
    private fun readLast(): Location? {
        var best: Location? = null
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            runCatching {
                if (!lm.isProviderEnabled(p)) return@runCatching
                val l = lm.getLastKnownLocation(p) ?: return@runCatching
                if (best == null || l.time > best!!.time) best = l
            }
        }
        if (best != null && System.currentTimeMillis() - best!!.time > MAX_AGE) return null
        return best
    }

    private fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6_371_000.0
        val p1 = Math.toRadians(lat1); val p2 = Math.toRadians(lat2)
        val dp = Math.toRadians(lat2 - lat1); val dl = Math.toRadians(lon2 - lon1)
        val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return r * 2 * asin(sqrt(a))
    }

    private companion object {
        const val TRANSIT_MPS = 3.0f
        const val MAX_AGE = 15 * 60_000L
    }
}
