package com.aegis.ai.intent

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class FastIntentRouter(
    private val executor: ActionExecutor,
    private val scope: CoroutineScope
) {
    private val mutex = Mutex()
    private val _outcomes = MutableSharedFlow<RouteOutcome>(
        extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val outcomes: SharedFlow<RouteOutcome> = _outcomes.asSharedFlow()

    suspend fun route(match: IntentMatch): RouteOutcome = mutex.withLock {
        val t0 = SystemClock.elapsedRealtime()
        if (match.actions.isEmpty()) return@withLock finish(RouteOutcome.Path.UNKNOWN, match, emptyList(), null, t0)

        val cognitive = match.actions.any {
            it is AegisAction.Unresolved || it is AegisAction.OpenApp
        }
        if (cognitive) {
            Log.i(AudioConfig.TAG, "COGNITIVE: " + match.rawText)
            return@withLock finish(RouteOutcome.Path.COGNITIVE, match, emptyList(), match.rawText, t0)
        }

        val results = ArrayList<ActionOutcome>(match.actions.size)
        for (a in match.actions) results += executor.execute(a)
        val allOk = results.all { it.success }
        val automation = match.actions.any { it.isAutomation() }
        val path = when {
            !allOk -> RouteOutcome.Path.MIXED
            automation -> RouteOutcome.Path.AUTOMATION
            else -> RouteOutcome.Path.FAST
        }
        Log.i(AudioConfig.TAG, "ROUTE[$path] ${match.actions.size} actions ${SystemClock.elapsedRealtime() - t0}ms")
        finish(path, match, results, null, t0)
    }

    fun routeAsync(m: IntentMatch) { scope.launch { route(m) } }

    private fun finish(
        path: RouteOutcome.Path, m: IntentMatch,
        executed: List<ActionOutcome>, prompt: String?, start: Long
    ): RouteOutcome {
        val o = RouteOutcome(path, m, executed, prompt, SystemClock.elapsedRealtime() - start)
        _outcomes.tryEmit(o)
        return o
    }
}
