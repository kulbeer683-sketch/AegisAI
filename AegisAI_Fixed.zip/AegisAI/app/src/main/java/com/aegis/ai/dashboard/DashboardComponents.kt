package com.aegis.ai.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.aegis.ai.dashboard.theme.AegisPalette

@Composable
fun AegisSectionCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AegisPalette.Surface),
        border = BorderStroke(1.dp, AegisPalette.SurfaceOutline)
    ) { Column(Modifier.padding(16.dp)) { content() } }
}

@Composable
fun AegisSectionHeader(label: String, subtitle: String? = null) {
    Text(label, style = MaterialTheme.typography.labelLarge, color = AegisPalette.Accent)
    if (subtitle != null) { Spacer(Modifier.height(2.dp)); Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary) }
    Spacer(Modifier.height(12.dp))
}

@Composable
fun StatusChip(granted: Boolean, grantedText: String = "GRANTED", requiredText: String = "REQUIRED") {
    val bg = if (granted) AegisPalette.AccentFaint else AegisPalette.Warning.copy(alpha = 0.15f)
    val fg = if (granted) AegisPalette.Accent else AegisPalette.Warning
    val text = if (granted) grantedText else requiredText
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(bg).border(1.dp, fg.copy(alpha = 0.45f), RoundedCornerShape(20.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = fg, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetricRow(icon: ImageVector, label: String, value: String, accent: Color = AegisPalette.TextPrimary) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = AegisPalette.TextSecondary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyLarge, color = accent, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun MasterToggleHeader(state: DashboardState, onToggle: (Boolean) -> Unit) {
    AegisSectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AEGIS AI", style = MaterialTheme.typography.displayLarge, color = AegisPalette.Accent)
                Spacer(Modifier.height(4.dp))
                Text(if (state.serviceRunning) "Assistant online" else "Assistant offline",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (state.serviceRunning) AegisPalette.Success else AegisPalette.TextSecondary)
            }
            Switch(checked = state.serviceRunning, onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(checkedThumbColor = AegisPalette.Black, checkedTrackColor = AegisPalette.Accent,
                    uncheckedThumbColor = AegisPalette.TextSecondary, uncheckedTrackColor = AegisPalette.SurfaceElevated))
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(when (state.assistantState) {
                com.aegis.ai.wakeword.AssistantStateCoordinator.State.ACTIVE_LISTENING -> AegisPalette.Accent
                com.aegis.ai.wakeword.AssistantStateCoordinator.State.SPEAKING -> AegisPalette.Info
                com.aegis.ai.wakeword.AssistantStateCoordinator.State.PROCESSING -> AegisPalette.Warning
                com.aegis.ai.wakeword.AssistantStateCoordinator.State.AWAITING_SLOT -> AegisPalette.Warning
                else -> AegisPalette.TextTertiary
            }))
            Spacer(Modifier.width(8.dp))
            Text(state.assistantState?.name ?: "OFFLINE", style = MaterialTheme.typography.labelLarge, color = AegisPalette.TextSecondary)
            Spacer(Modifier.weight(1f))
            if (state.pipelineRunning) Text("MIC LIVE", style = MaterialTheme.typography.labelSmall, color = AegisPalette.Accent)
        }
    }
}

@Composable
fun PermissionChecklist(state: DashboardState, onOpenSettings: (PermissionItem) -> Unit) {
    AegisSectionCard {
        AegisSectionHeader("SYSTEM PERMISSIONS", "${state.grantedCount} of ${state.totalCount} granted")
        state.permissions.groupBy { it.category }.forEach { (cat, items) ->
            Spacer(Modifier.height(6.dp))
            Text(catLabel(cat), style = MaterialTheme.typography.labelSmall, color = AegisPalette.TextTertiary)
            Spacer(Modifier.height(6.dp))
            items.forEach { item ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(AegisPalette.SurfaceElevated).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (state.permissionStatus[item.id] == true) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber, contentDescription = null,
                        tint = if (state.permissionStatus[item.id] == true) AegisPalette.Success else AegisPalette.Warning, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, style = MaterialTheme.typography.bodyLarge, color = AegisPalette.TextPrimary)
                        Text(item.description, style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
                    }
                    Spacer(Modifier.width(8.dp))
                    StatusChip(granted = state.permissionStatus[item.id] == true)
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { onOpenSettings(item) }) {
                        Text(if (state.permissionStatus[item.id] == true) "Review" else "Fix", style = MaterialTheme.typography.labelLarge, color = AegisPalette.Accent)
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

private fun catLabel(c: PermissionCategory) = when (c) {
    PermissionCategory.AUDIO_AND_HARDWARE -> "AUDIO & HARDWARE"
    PermissionCategory.PHONE_AND_CONTACTS -> "PHONE & CONTACTS"
    PermissionCategory.LOCATION -> "LOCATION"
    PermissionCategory.CAMERA -> "CAMERA"
    PermissionCategory.CONNECTIVITY -> "CONNECTIVITY"
    PermissionCategory.NOTIFICATIONS -> "NOTIFICATIONS"
    PermissionCategory.SPECIAL_ACCESS -> "SPECIAL ACCESS"
}

@Composable
fun VitalsCard(state: DashboardState) {
    AegisSectionCard {
        AegisSectionHeader("DEVICE VITALS")
        val v = state.vitals
        if (v == null) Text("Awaiting telemetry…", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
        else {
            MetricRow(Icons.Filled.Bolt, "Battery", "${v.batteryPercent}%  ${if (v.isCharging) "· charging" else ""}",
                accent = when { v.batteryPercent <= 15 -> AegisPalette.Danger; v.batteryPercent <= 30 -> AegisPalette.Warning; else -> AegisPalette.TextPrimary })
            MetricRow(Icons.Filled.Thermostat, "Temperature", "${"%.1f".format(v.batteryTempC)} °C",
                accent = when { v.batteryTempC >= 42f -> AegisPalette.Danger; v.batteryTempC >= 39f -> AegisPalette.Warning; else -> AegisPalette.TextPrimary })
            MetricRow(Icons.Filled.Wifi, "Network", v.networkType.name)
            MetricRow(Icons.Filled.Speed, "Power mode", state.throttleTier.name,
                accent = when (state.throttleTier) { com.aegis.ai.power.ThrottleTier.NORMAL -> AegisPalette.Success; com.aegis.ai.power.ThrottleTier.THROTTLED -> AegisPalette.Warning; com.aegis.ai.power.ThrottleTier.CRITICAL -> AegisPalette.Danger })
        }
    }
}

@Composable
fun HeartbeatCard(state: DashboardState) {
    AegisSectionCard {
        AegisSectionHeader("BACKGROUND DAEMONS", "${state.heartbeat.count { it.value }} / ${state.heartbeat.size} healthy")
        if (state.heartbeat.isEmpty()) Text("Heartbeat data unavailable.", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
        else state.heartbeat.forEach { (n, h) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (h) AegisPalette.Success else AegisPalette.Danger))
                Spacer(Modifier.width(10.dp))
                Text(n.replace('_', ' ').uppercase(), style = MaterialTheme.typography.labelSmall, color = AegisPalette.TextSecondary, modifier = Modifier.weight(1f))
                Text(if (h) "OK" else "DOWN", style = MaterialTheme.typography.labelSmall, color = if (h) AegisPalette.Success else AegisPalette.Danger)
            }
        }
    }
}

@Composable
fun DiagnosticsCard(state: DashboardState, onRun: () -> Unit) {
    AegisSectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { AegisSectionHeader("SYSTEM DIAGNOSTICS") }
            TextButton(onClick = onRun) {
                Icon(Icons.Filled.Refresh, contentDescription = null, tint = AegisPalette.Accent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Run", color = AegisPalette.Accent, style = MaterialTheme.typography.labelLarge)
            }
        }
        val d = state.diagnostics
        if (d == null) Text("Tap Run to sample every subsystem.", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
        else {
            MetricRow(Icons.Filled.CheckCircle, "Health", if (d.healthy) "Healthy" else "${d.errorCount} issue(s)", accent = if (d.healthy) AegisPalette.Success else AegisPalette.Warning)
            MetricRow(Icons.Filled.Settings, "Routines enabled", d.enabledRoutineCount.toString())
            MetricRow(Icons.Filled.Notifications, "Notifications cached", d.cachedHighPriorityCount.toString())
            MetricRow(Icons.Filled.Bolt, "Memory facts", d.memoryFactCount.toString())
            MetricRow(Icons.Filled.Speed, "Decision queue", "${d.decisionQueueDepth} queued")
            Spacer(Modifier.height(8.dp))
            MetricRow(Icons.Filled.Lock, "WakeLocks", "${state.activeWakeLocks} active, ${state.releasedLeaks} leaks")
        }
    }
}

@Composable
fun GeminiKeyCard(state: DashboardState, validation: KeyValidation, onSave: (String) -> Unit, onValidate: (String) -> Unit, onClear: () -> Unit, onDismiss: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    AegisSectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                AegisSectionHeader("GEMINI CLOUD BRAIN")
                Text(if (state.geminiKeyPresent) "Encrypted API key stored" else "No API key configured",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (state.geminiKeyPresent) AegisPalette.Success else AegisPalette.TextSecondary)
            }
            StatusChip(granted = state.geminiKeyPresent, grantedText = "SET", requiredText = "NOT SET")
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { show = true }, colors = ButtonDefaults.buttonColors(containerColor = AegisPalette.Accent, contentColor = AegisPalette.Black)) {
                Text(if (state.geminiKeyPresent) "Replace key" else "Add key")
            }
            if (state.geminiKeyPresent) TextButton(onClick = onClear) { Text("Clear", color = AegisPalette.Warning) }
        }
        when (validation) {
            is KeyValidation.Validating -> { Spacer(Modifier.height(10.dp)); Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(modifier = Modifier.size(14.dp), color = AegisPalette.Accent, strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text("Validating…", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary) } }
            is KeyValidation.Success -> { Spacer(Modifier.height(10.dp)); Text("✓ Valid · ${validation.maskedKey}", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.Success) }
            is KeyValidation.Failure -> { Spacer(Modifier.height(10.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text("✕ ${validation.reason}", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.Danger, modifier = Modifier.weight(1f)); TextButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = null, tint = AegisPalette.TextSecondary, modifier = Modifier.size(16.dp)) } } }
            else -> {}
        }
    }
    if (show) {
        var k by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { show = false }, containerColor = AegisPalette.SurfaceElevated,
            title = { Text("Gemini API Key", style = MaterialTheme.typography.titleLarge, color = AegisPalette.TextPrimary) },
            text = { Column {
                Text("Stored locally using EncryptedSharedPreferences.", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = k, onValueChange = { k = it }, singleLine = true, label = { Text("API key") }, visualTransformation = PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = AegisPalette.TextPrimary, unfocusedTextColor = AegisPalette.TextPrimary, focusedBorderColor = AegisPalette.Accent, unfocusedBorderColor = AegisPalette.SurfaceOutline),
                    modifier = Modifier.fillMaxWidth())
            } },
            confirmButton = { TextButton(onClick = { onValidate(k); onSave(k); show = false }) { Text("Save & validate", color = AegisPalette.Accent) } },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel", color = AegisPalette.TextSecondary) } }
        )
    }
}

@Composable
fun VoicePersonaCard(state: DashboardState, onPitch: (Float) -> Unit, onRate: (Float) -> Unit, onTest: () -> Unit) {
    AegisSectionCard {
        AegisSectionHeader("VOICE PERSONA", "Deep-bass Jarvis calibration")
        Text("Pitch  ${"%.2f".format(state.voicePitch)}×", style = MaterialTheme.typography.labelSmall, color = AegisPalette.TextSecondary)
        Slider(value = state.voicePitch, onValueChange = onPitch, valueRange = 0.55f..1.45f,
            colors = SliderDefaults.colors(thumbColor = AegisPalette.Accent, activeTrackColor = AegisPalette.Accent, inactiveTrackColor = AegisPalette.SurfaceOutline))
        Spacer(Modifier.height(6.dp))
        Text("Rate  ${"%.2f".format(state.voiceRate)}×", style = MaterialTheme.typography.labelSmall, color = AegisPalette.TextSecondary)
        Slider(value = state.voiceRate, onValueChange = onRate, valueRange = 0.70f..1.50f,
            colors = SliderDefaults.colors(thumbColor = AegisPalette.Accent, activeTrackColor = AegisPalette.Accent, inactiveTrackColor = AegisPalette.SurfaceOutline))
        Spacer(Modifier.height(10.dp))
        Button(onClick = onTest, colors = ButtonDefaults.buttonColors(containerColor = AegisPalette.Accent, contentColor = AegisPalette.Black)) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Test voice")
        }
    }
}

@Composable
fun MasterPowerCard(state: DashboardState, onToggle: (Boolean) -> Unit) {
    AegisSectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.PowerSettingsNew, contentDescription = null, tint = if (state.serviceRunning) AegisPalette.Accent else AegisPalette.TextSecondary, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (state.serviceRunning) "Aegis is active" else "Aegis is stopped", style = MaterialTheme.typography.bodyLarge, color = AegisPalette.TextPrimary)
                Text(if (state.serviceRunning) "Microphone live · wake-word listening" else "Tap to start the assistant", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
            }
            Switch(checked = state.serviceRunning, onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(checkedThumbColor = AegisPalette.Black, checkedTrackColor = AegisPalette.Accent, uncheckedThumbColor = AegisPalette.TextSecondary, uncheckedTrackColor = AegisPalette.SurfaceElevated))
        }
        state.lastError?.let { e ->
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.WarningAmber, contentDescription = null, tint = AegisPalette.Warning, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(e, style = MaterialTheme.typography.bodyMedium, color = AegisPalette.Warning)
            }
        }
    }
}
