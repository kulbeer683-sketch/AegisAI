package com.aegis.ai.audio

import android.media.AudioFormat
import android.media.MediaRecorder
import kotlin.math.max

object AudioConfig {
    const val TAG = "AegisAudio"
    const val SAMPLE_RATE: Int = 16000
    const val CHANNEL_MASK: Int = AudioFormat.CHANNEL_IN_MONO
    const val ENCODING: Int = AudioFormat.ENCODING_PCM_16BIT
    const val AUDIO_SOURCE: Int = MediaRecorder.AudioSource.VOICE_COMMUNICATION
    const val FRAME_DURATION_MS: Int = 20
    const val FRAME_SIZE: Int = SAMPLE_RATE * FRAME_DURATION_MS / 1000
    const val BANDPASS_LOW_HZ: Double = 300.0
    const val BANDPASS_HIGH_HZ: Double = 3400.0
    const val BANDPASS_Q: Double = 0.7071067811865476

    fun bufferSizeBytes(minPlatformBuffer: Int): Int =
        max(minPlatformBuffer, FRAME_SIZE * 2 * 4)
}
