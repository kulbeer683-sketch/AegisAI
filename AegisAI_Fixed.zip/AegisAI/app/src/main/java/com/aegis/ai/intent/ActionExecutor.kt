package com.aegis.ai.intent

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.CallAutomationManager
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.dashboard.DiagnosticsSpeaker
import com.aegis.ai.dashboard.Phase4DiagnosticsPayload
import com.aegis.ai.hardware.ConnectivityController
import com.aegis.ai.hardware.ControllerResult
import com.aegis.ai.hardware.FlashlightController
import com.aegis.ai.hardware.VolumeController
import com.aegis.ai.memory.LongTermMemoryManager
import com.aegis.ai.overlay.AegisFloatingOverlay
import com.aegis.ai.privacy.MemoryWipeManager
import com.aegis.ai.privacy.WipeOutcome
import com.aegis.ai.service.AegisAccessibilityService
import com.aegis.ai.vitals.DeviceVitalsMonitor
import com.aegis.ai.vitals.VitalsResponder

class ActionExecutor(
    private val context: Context,
    private val flashlight: FlashlightController,
    private val volume: VolumeController,
    private val connectivity: ConnectivityController,
    private val inEar: InEarNotificationManager?,
    private val vitals: DeviceVitalsMonitor?,
    private val memory: LongTermMemoryManager?,
    private val wipeManager: MemoryWipeManager?,
    private val overlay: AegisFloatingOverlay?,
    private val callManager: CallAutomationManager?,
    private val diagnosticsProvider: (() -> Phase4DiagnosticsPayload)? = null
) {

    suspend fun execute(action: AegisAction): ActionOutcome {
        val t0 = SystemClock.elapsedRealtime()
        val (ok, msg, pending) = try { dispatch(action) }
        catch (t: Throwable) {
            Log.e(AudioConfig.TAG, "dispatch failed: " + action, t)
            Triple(false, (t.message ?: "dispatch failed"), null)
        }
        return ActionOutcome(action, ok, msg, pending, SystemClock.elapsedRealtime() - t0)
    }

    private suspend fun dispatch(a: AegisAction): Triple<Boolean, String, Intent?> = when (a) {

        AegisAction.TorchOn -> flashlight.setTorch(true).triple()
        AegisAction.TorchOff -> flashlight.setTorch(false).triple()
        AegisAction.TorchToggle -> flashlight.toggle().triple()

        is AegisAction.VolumeSet -> volume.setVolume(a.stream, a.percent).triple()
        is AegisAction.VolumeAdjust -> volume.adjustVolume(a.stream, a.direction).triple()
        is AegisAction.VolumeMute -> volume.setMute(a.stream, a.mute).triple()

        AegisAction.BluetoothOn -> connectivity.setBluetooth(true).triple()
        AegisAction.BluetoothOff -> connectivity.setBluetooth(false).triple()
        AegisAction.BluetoothToggle -> connectivity.toggleBluetooth().triple()
        AegisAction.WifiOn -> connectivity.setWifi(true).triple()
        AegisAction.WifiOff -> connectivity.setWifi(false).triple()
        AegisAction.WifiToggle -> connectivity.toggleWifi().triple()

        AegisAction.GoHome -> acc { it.goHome() } then "HOME"
        AegisAction.GoBack -> acc { it.goBack() } then "BACK"
        AegisAction.ShowRecents -> acc { it.showRecents() } then "RECENTS"
        AegisAction.ShowNotifications -> acc { it.openNotifications() } then "NOTIFICATIONS"
        AegisAction.LockScreen -> acc { it.performLockScreen() } then "LOCK_SCREEN"

        is AegisAction.SetDnd -> setDnd(a.enabled)
        is AegisAction.SetAutoRotation -> setRotation(a.enabled)
        is AegisAction.SetNightMode -> setNight(a.enabled)
        is AegisAction.SetScreenTimeout -> setScreenTimeout(a.timeoutMs)
        AegisAction.RequestAirplanePanel ->
            Triple(false, "Airplane mode requires confirmation",
                Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        AegisAction.RequestLocationPanel ->
            Triple(false, "Location requires confirmation",
                Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

        is AegisAction.QueryVitals -> {
            val v = vitals?.current()
            if (v == null) Triple(false, "Vitals unavailable", null)
            else Triple(true, VitalsResponder.respond(a.query, v), null)
        }

        AegisAction.QueryPowerStatus -> {
            val v = vitals?.current()
            val s = if (v == null) "" else "बैटरी " + v.batteryPercent + "%, तापमान " +
                "%.0f".format(v.batteryTempC) + " डिग्री, " +
                (if (v.isCharging) "चार्जिंग पर" else "चार्जिंग पर नहीं")
            Triple(true, s, null)
        }

        AegisAction.QueryLocation -> Triple(true, "आपकी लोकेशन उपलब्ध नहीं है", null)

        AegisAction.SystemDiagnostics -> {
            val p = diagnosticsProvider?.invoke() ?: Phase4DiagnosticsPayload.EMPTY
            Triple(true, DiagnosticsSpeaker.speak(p), null)
        }

        is AegisAction.RememberFact -> {
            val m = memory
            if (m == null) Triple(false, "Memory unavailable", null)
            else {
                val ok = m.rememberFact(a.key, a.value)
                Triple(ok, if (ok) "याद रख लिया" else "याद नहीं रख सका", null)
            }
        }

        is AegisAction.QueryMemory -> {
            val m = memory
            if (m == null) Triple(false, "Memory unavailable", null)
            else {
                val key = a.key
                if (key.isNullOrBlank()) {
                    Triple(true, "मुझे " + m.factCount() + " बातें याद हैं", null)
                } else {
                    val v = m.lookup(key)
                    Triple(true, if (v == null) "यह याद नहीं है" else key + " = " + v, null)
                }
            }
        }

        AegisAction.ForgetAllMemory -> {
            val w = wipeManager
            if (w == null) Triple(false, "Wipe unavailable", null)
            else {
                val out = w.handleResponse("yes")
                Triple(out is WipeOutcome.Success, "याददाश्त मिटा दी गई", null)
            }
        }

        is AegisAction.OverlayControl -> {
            val o = overlay
            if (o == null) Triple(false, "Overlay unavailable", null)
            else {
                if (a.enabled) { o.resetDismissal(); o.attach(); Triple(true, "ओवरले चालू", null) }
                else { o.setMode(com.aegis.ai.overlay.OverlayMode.HIDDEN); Triple(true, "ओवरले बंद", null) }
            }
        }

        AegisAction.AcceptCall -> {
            val c = callManager
            if (c == null) Triple(false, "Call manager unavailable", null)
            else c.answerCall().triple()
        }

        AegisAction.RejectCall -> {
            val c = callManager
            if (c == null) Triple(false, "Call manager unavailable", null)
            else c.rejectCall().triple()
        }

        is AegisAction.OpenApp -> {
            Triple(false, "ऐप खोलने के लिए क्लाउड कनेक्शन चाहिए", null)
        }

        is AegisAction.SendWhatsApp -> {
            Triple(false, "व्हाट्सएप ऑटोमेशन इस बिल्ड में उपलब्ध नहीं है", null)
        }

        is AegisAction.PlayYouTube -> {
            Triple(false, "यूट्यूब ऑटोमेशन इस बिल्ड में उपलब्ध नहीं है", null)
        }

        is AegisAction.InspectScreen, is AegisAction.InspectRealWorld -> {
            Triple(false, "विज़न इस बिल्ड में उपलब्ध नहीं है", null)
        }

        is AegisAction.IncompleteWhatsApp, is AegisAction.IncompleteYouTube -> {
            Triple(false, "अपूर्ण कमांड", null)
        }

        is AegisAction.Unresolved -> Triple(false, "समझ नहीं आया", null)

        AegisAction.MediaPlay, AegisAction.MediaPause, AegisAction.MediaTogglePlayPause,
        AegisAction.MediaNext, AegisAction.MediaPrevious, AegisAction.MediaStop -> {
            Triple(false, "मीडिया कंट्रोल इस बिल्ड में उपलब्ध नहीं है", null)
        }
    }

    // ---- helpers ---------------------------------------------------------

    private fun setDnd(enabled: Boolean): Triple<Boolean, String, Intent?> {
        return try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE)
                as android.app.NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) {
                return Triple(false, "DND access required",
                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            val target = if (enabled) android.app.NotificationManager.INTERRUPTION_FILTER_NONE
                         else android.app.NotificationManager.INTERRUPTION_FILTER_ALL
            nm.setInterruptionFilter(target)
            Triple(true, if (enabled) "DND enabled" else "DND disabled", null)
        } catch (t: Throwable) { Triple(false, t.message ?: "dnd failed", null) }
    }

    private fun setRotation(enabled: Boolean): Triple<Boolean, String, Intent?> {
        return try {
            if (!Settings.System.canWrite(context)) {
                return Triple(false, "WRITE_SETTINGS required",
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.fromParts("package", context.packageName, null))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Settings.System.putInt(context.contentResolver,
                Settings.System.ACCELEROMETER_ROTATION, if (enabled) 1 else 0)
            Triple(true, if (enabled) "Auto-rotate on" else "Auto-rotate off", null)
        } catch (t: Throwable) { Triple(false, t.message ?: "rotation failed", null) }
    }

    private fun setNight(enabled: Boolean): Triple<Boolean, String, Intent?> {
        return try {
            val mode = if (enabled) androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES
                       else androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(mode)
            Triple(true, if (enabled) "Dark mode on" else "Light mode on", null)
        } catch (t: Throwable) { Triple(false, t.message ?: "night failed", null) }
    }

    private fun setScreenTimeout(ms: Long): Triple<Boolean, String, Intent?> {
        return try {
            if (!Settings.System.canWrite(context)) {
                return Triple(false, "WRITE_SETTINGS required",
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.fromParts("package", context.packageName, null))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            val clamped = ms.coerceIn(15_000L, 30 * 60_000L)
            Settings.System.putLong(context.contentResolver,
                Settings.System.SCREEN_OFF_TIMEOUT, clamped)
            Triple(true, "Screen timeout updated", null)
        } catch (t: Throwable) { Triple(false, t.message ?: "timeout failed", null) }
    }

    private suspend fun acc(block: suspend (AegisAccessibilityService) -> Boolean): Boolean {
        val svc = AegisAccessibilityService.get() ?: return false
        return try { block(svc) } catch (_: Throwable) { false }
    }

    private infix fun Boolean.then(label: String): Triple<Boolean, String, Intent?> =
        Triple(this, if (this) "OK: $label" else "Rejected: $label", null)

    private fun ControllerResult.triple(): Triple<Boolean, String, Intent?> = when (this) {
        is ControllerResult.Success -> Triple(true, message, null)
        is ControllerResult.Failure -> Triple(false, message, null)
        is ControllerResult.NeedsUserIntent -> Triple(false, message, intent)
    }
}
