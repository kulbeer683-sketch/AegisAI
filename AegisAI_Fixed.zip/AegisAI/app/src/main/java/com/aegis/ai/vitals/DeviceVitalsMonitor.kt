package com.aegis.ai.vitals

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DeviceVitalsMonitor(context: Context) : AutoCloseable {

    private val appContext = context.applicationContext
    private val batteryManager =
        appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val powerManager =
        appContext.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val telephonyManager =
        appContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val cm =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _snapshot = MutableStateFlow(bootstrap())
    val snapshot: StateFlow<VitalsSnapshot> = _snapshot.asStateFlow()

    private var receiver: BroadcastReceiver? = null
    private var thermal: PowerManager.OnThermalStatusChangedListener? = null

    @Volatile private var started = false

    fun start() {
        if (started) return; started = true
        registerBattery()
        registerThermal()
    }

    fun stop() {
        if (!started) return; started = false
        receiver?.let { runCatching { appContext.unregisterReceiver(it) } }; receiver = null
        thermal?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) runCatching { powerManager.removeThermalStatusListener(it) }
        }
        thermal = null
    }

    override fun close() = stop()

    fun current(): VitalsSnapshot = _snapshot.value

    private fun registerBattery() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) { intent?.let { handle(it) } }
        }
        runCatching {
            ContextCompat.registerReceiver(appContext, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
                ContextCompat.RECEIVER_NOT_EXPORTED)
            receiver = r
        }
    }

    private fun handle(intent: Intent) {
        runCatching {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val volt = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
            val t10 = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            val tc = if (t10 != Int.MIN_VALUE) t10 / 10.0f else Float.NaN

            val s = _snapshot.value.copy(
                batteryPercent = if (pct in 0..100) pct else _snapshot.value.batteryPercent,
                batteryStatus = mapStatus(status),
                batteryPlugged = mapPlugged(plugged),
                batteryVoltageMv = if (volt > 0) volt else _snapshot.value.batteryVoltageMv,
                batteryTempC = if (!tc.isNaN()) tc else _snapshot.value.batteryTempC,
                networkType = netType(),
                timestampMs = SystemClock.elapsedRealtime()
            )
            _snapshot.value = s
        }
    }

    private fun mapStatus(raw: Int) = when (raw) {
        BatteryManager.BATTERY_STATUS_CHARGING -> BatteryStatus.CHARGING
        BatteryManager.BATTERY_STATUS_DISCHARGING -> BatteryStatus.DISCHARGING
        BatteryManager.BATTERY_STATUS_FULL -> BatteryStatus.FULL
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> BatteryStatus.NOT_CHARGING
        else -> BatteryStatus.UNKNOWN
    }

    private fun mapPlugged(raw: Int) = when {
        raw and BatteryManager.BATTERY_PLUGGED_AC != 0 -> Plugged.AC
        raw and BatteryManager.BATTERY_PLUGGED_USB != 0 -> Plugged.USB
        raw and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> Plugged.WIRELESS
        else -> Plugged.NONE
    }

    private fun registerThermal() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val l = PowerManager.OnThermalStatusChangedListener { status ->
            _snapshot.value = _snapshot.value.copy(thermalStatus = mapThermal(status),
                timestampMs = SystemClock.elapsedRealtime())
        }
        runCatching {
            powerManager.addThermalStatusListener(ContextCompat.getMainExecutor(appContext), l)
            thermal = l
            _snapshot.value = _snapshot.value.copy(thermalStatus = mapThermal(powerManager.currentThermalStatus))
        }
    }

    private fun mapThermal(raw: Int) = when (raw) {
        PowerManager.THERMAL_STATUS_NONE -> ThermalStatus.NONE
        PowerManager.THERMAL_STATUS_LIGHT -> ThermalStatus.LIGHT
        PowerManager.THERMAL_STATUS_MODERATE -> ThermalStatus.MODERATE
        PowerManager.THERMAL_STATUS_SEVERE -> ThermalStatus.SEVERE
        PowerManager.THERMAL_STATUS_CRITICAL -> ThermalStatus.CRITICAL
        PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalStatus.EMERGENCY
        PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStatus.SHUTDOWN
        else -> ThermalStatus.UNKNOWN
    }

    private fun netType(): NetworkType = try {
        val active = cm.activeNetwork ?: return NetworkType.NONE
        val caps = cm.getNetworkCapabilities(active) ?: return NetworkType.NONE
        when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                @Suppress("DEPRECATION")
                when (telephonyManager.dataNetworkType) {
                    TelephonyManager.NETWORK_TYPE_NR -> NetworkType.NR_5G
                    TelephonyManager.NETWORK_TYPE_LTE -> NetworkType.LTE
                    TelephonyManager.NETWORK_TYPE_HSPAP,
                    TelephonyManager.NETWORK_TYPE_HSPA,
                    TelephonyManager.NETWORK_TYPE_HSDPA -> NetworkType.HSPA
                    TelephonyManager.NETWORK_TYPE_UMTS -> NetworkType.UMTS
                    TelephonyManager.NETWORK_TYPE_EDGE,
                    TelephonyManager.NETWORK_TYPE_GPRS -> NetworkType.GSM
                    else -> NetworkType.UNKNOWN
                }
            }
            else -> NetworkType.UNKNOWN
        }
    } catch (_: Throwable) { NetworkType.UNKNOWN }

    private fun bootstrap(): VitalsSnapshot {
        val p = runCatching { batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100) }.getOrDefault(50)
        val v = runCatching { batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_VOLTAGE).takeIf { it > 0 } ?: 0 }.getOrDefault(0)
        val th = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            runCatching { mapThermal(powerManager.currentThermalStatus) }.getOrDefault(ThermalStatus.UNKNOWN)
        else ThermalStatus.UNKNOWN
        return VitalsSnapshot(p, BatteryStatus.UNKNOWN, Plugged.NONE, v, 25f, th,
            netType(), 0, SystemClock.elapsedRealtime())
    }
}
