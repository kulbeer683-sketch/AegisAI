package com.aegis.ai.location

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.notifications.DigestResult
import com.aegis.ai.notifications.NotificationDigestEngine
import com.aegis.ai.notifications.SmartNotificationListener
import com.aegis.ai.pipeline.WorkflowPipelineCoordinator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SpatialRoutineCoordinator(
    private val storage: LocationStorage,
    private val workflow: WorkflowPipelineCoordinator,
    private val inEar: InEarNotificationManager?,
    private val language: IntentMatch.Language = IntentMatch.Language.HINGLISH
) {

    private val mutex = Mutex()

    suspend fun handleTransition(target: GeoContext, entering: Boolean): Boolean = mutex.withLock {
        val now = SystemClock.elapsedRealtime()
        val last = storage.getLastTransitionMs()
        if (last > 0L && now - last < HYSTERESIS_MS) return@withLock false
        Log.i(TAG, "Transition $target entering=$entering")
        try {
            when {
                target == GeoContext.HOME && entering -> runEnterHome()
                target == GeoContext.HOME && !entering -> runExitHome()
                target == GeoContext.WORK && entering -> runEnterWork()
                else -> return@withLock false
            }
        } catch (ce: CancellationException) { throw ce }
        catch (t: Throwable) { Log.e(TAG, "transition threw", t); return@withLock false }
        storage.setLastTransitionMs(now)
        storage.setLastContext(target)
        true
    }

    fun resetHysteresis() { storage.setLastTransitionMs(0L) }

    private suspend fun runEnterHome() {
        val greeting = buildWelcomeBriefing()
        val actions = listOf(
            AegisAction.WifiOn, AegisAction.SetDnd(false),
            AegisAction.VolumeSet(AudioStream.RING, 40)
        )
        runCatching { workflow.executeWorkflow(actions, language, voicePrefix = greeting) }
        fireReminders(GeoContext.HOME)
    }

    private suspend fun runExitHome() {
        val actions = listOf(AegisAction.WifiOff, AegisAction.VolumeSet(AudioStream.RING, 80), AegisAction.VolumeMute(AudioStream.MEDIA, mute = true))
        runCatching { workflow.executeWorkflow(actions, language) }
    }

    private suspend fun runEnterWork() {
        val actions = listOf(AegisAction.WifiOn, AegisAction.SetDnd(false), AegisAction.VolumeSet(AudioStream.RING, 40))
        runCatching { workflow.executeWorkflow(actions, language) }
        fireReminders(GeoContext.WORK)
    }

    private suspend fun fireReminders(t: GeoContext) {
        val r = storage.remindersFor(t)
        if (r.isEmpty()) return
        for (x in r) runCatching { inEar?.speak(x.message) }
        storage.removeReminders(r.map { it.id })
    }

    private fun buildWelcomeBriefing(): String {
        val engine = NotificationDigestEngine(language)
        val d = engine.digest { SmartNotificationListener.get() }
        val greet = if (language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH) "घर पहुँच गए हैं" else "Welcome home"
        return when (d) {
            is DigestResult.Success -> "$greet, ${d.spoken}"
            else -> greet
        }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val HYSTERESIS_MS = 10 * 60_000L
    }
}
