package com.aegis.ai.dashboard

data class Phase4DiagnosticsPayload(
    val healthy: Boolean = true,
    val errorCount: Int = 0,
    val errors: List<String> = emptyList(),
    val enabledRoutineCount: Int = 0,
    val cachedHighPriorityCount: Int = 0,
    val memoryFactCount: Int = 0,
    val decisionQueueDepth: Int = 0,
    val activeWakeLocks: Int = 0,
    val releasedLeaks: Long = 0L,
    val throttleTier: String = "NORMAL",
    val circuitBreakerState: String = "CLOSED"
) {
    companion object { val EMPTY = Phase4DiagnosticsPayload() }
}

object DiagnosticsSpeaker {
    fun speak(p: Phase4DiagnosticsPayload): String {
        val head = if (p.healthy) "सभी सिस्टम ठीक हैं"
                   else p.errorCount.toString() + " समस्या हैं: " + p.errors.joinToString(", ").take(80)
        return (head + ". रूटीन " + p.enabledRoutineCount +
                ", यादें " + p.memoryFactCount +
                ", पावर " + p.throttleTier).take(220)
    }
}
