package com.aegis.ai.decision

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch

class CapabilityRouter(
    private val isCloudAvailable: () -> Boolean,
    private val isScreenVisionAvailable: () -> Boolean,
    private val isCameraVisionAvailable: () -> Boolean
) {
    fun route(match: IntentMatch?): ExecutionCapability {
        if (match == null || match.actions.isEmpty()) return ExecutionCapability.BLOCKED
        val a = match.actions

        if (a.any { it is AegisAction.Unresolved || it is AegisAction.OpenApp }) {
            return if (isCloudAvailable()) ExecutionCapability.CLOUD_LLM else ExecutionCapability.BLOCKED
        }
        if (a.any { it is AegisAction.InspectScreen }) {
            return if (isScreenVisionAvailable()) ExecutionCapability.SCREEN_VISION else ExecutionCapability.BLOCKED
        }
        if (a.any { it is AegisAction.InspectRealWorld }) {
            return if (isCameraVisionAvailable()) ExecutionCapability.CAMERA_VISION else ExecutionCapability.BLOCKED
        }
        if (a.all { it.isFastPath() }) {
            val needsCtx = a.any {
                it is AegisAction.QueryVitals || it is AegisAction.QueryPowerStatus ||
                it is AegisAction.QueryLocation || it is AegisAction.SystemDiagnostics
            }
            return if (needsCtx) ExecutionCapability.CONTEXTUAL_LOCAL else ExecutionCapability.FAST_PATH
        }
        return if (isCloudAvailable()) ExecutionCapability.CLOUD_LLM else ExecutionCapability.BLOCKED
    }
}
