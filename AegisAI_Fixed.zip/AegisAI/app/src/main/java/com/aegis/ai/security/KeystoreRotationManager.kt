package com.aegis.ai.security

import android.content.Context
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.aegis.ai.audio.AudioConfig
import java.io.File
import java.security.KeyStore

class KeystoreRotationManager(context: Context) {

    private val appContext = context.applicationContext

    fun rotateAll(): Boolean {
        var ok = true
        for (alias in ALIASES) if (!deleteAlias(alias)) ok = false
        for (f in SECURE_PREF_FILES) deletePrefsFile(f)
        Log.i(TAG, "Keystore rotation complete (success=$ok)")
        return ok
    }

    fun aliasExists(alias: String): Boolean = runCatching {
        KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.containsAlias(alias)
    }.getOrDefault(false)

    fun isSecureStoreReadable(): Boolean = runCatching {
        val mk = MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            appContext, "aegis_secure_keys", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        true
    }.getOrDefault(false)

    private fun deleteAlias(alias: String): Boolean = runCatching {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(alias)) { ks.deleteEntry(alias); Log.i(TAG, "alias deleted: $alias") }
        true
    }.getOrElse { Log.e(TAG, "deleteAlias '$alias' failed", it); false }

    private fun deletePrefsFile(name: String) {
        runCatching {
            val f = File(appContext.dataDir, "shared_prefs/$name.xml")
            if (f.exists() && f.delete()) Log.i(TAG, "prefs file deleted: $name.xml")
        }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private val ALIASES = listOf(
            "_androidx_security_master_key_",
            "_androidx_security_master_key_memory_"
        )
        private val SECURE_PREF_FILES = listOf("aegis_secure_keys", "aegis_memory_key")
        fun aliases(): List<String> = ALIASES
    }
}
