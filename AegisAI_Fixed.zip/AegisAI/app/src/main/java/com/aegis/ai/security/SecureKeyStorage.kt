package com.aegis.ai.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.aegis.ai.audio.AudioConfig

class SecureKeyStorage(context: Context) {

    private val appContext = context.applicationContext

    @Volatile private var prefs: SharedPreferences? = create()
    private val lock = Any()

    private fun create(): SharedPreferences? = try {
        val mk = MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            appContext, FILE, mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (t: Throwable) {
        Log.e(AudioConfig.TAG, "EncryptedSharedPreferences init failed", t)
        null
    }

    private fun ensure(): SharedPreferences? {
        prefs?.let { return it }
        synchronized(lock) { prefs?.let { return it }; return create().also { prefs = it } }
    }

    fun getGeminiApiKey(): String? = runCatching {
        ensure()?.getString(KEY_GEMINI, null)?.trim()?.takeIf { it.isNotEmpty() }
    }.getOrNull()

    fun setGeminiApiKey(key: String?) {
        runCatching {
            val p = ensure() ?: return
            if (key.isNullOrEmpty()) p.edit().remove(KEY_GEMINI).apply()
            else p.edit().putString(KEY_GEMINI, key.trim()).apply()
        }
    }

    fun hasGeminiApiKey(): Boolean = !getGeminiApiKey().isNullOrBlank()
    fun clearGeminiApiKey() = setGeminiApiKey(null)

    companion object {
        private const val FILE = "aegis_secure_keys"
        private const val KEY_GEMINI = "gemini_api_key_v1"
    }
}
