package com.aegis.ai.cognitive

import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.ActionExecutor
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.intent.RouteOutcome
import com.aegis.ai.memory.LongTermMemoryManager
import com.aegis.ai.privacy.PrivacyPreferences
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

class CognitiveBridge(
    private val scope: CoroutineScope,
    private val apiClient: GeminiApiClient,
    private val networkMonitor: NetworkMonitor,
    private val actionExecutor: ActionExecutor,
    private val inEar: InEarNotificationManager?,
    private val contextManager: com.aegis.ai.conversation.ConversationContextManager? = null,
    private val contextualResolver: com.aegis.ai.conversation.ContextualResolver? = null,
    private val memoryManager: LongTermMemoryManager? = null,
    private val privacyPreferences: PrivacyPreferences? = null
) {

    private val turnMutex = Mutex()
    private val _events = MutableSharedFlow<BridgeEvent>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<BridgeEvent> = _events.asSharedFlow()

    fun handleOutcome(outcome: RouteOutcome) {
        if (outcome.path != RouteOutcome.Path.COGNITIVE) return
        val prompt = outcome.forwardedPrompt
        if (prompt.isNullOrBlank()) return
        scope.launch { processTurn(outcome.source, prompt) }
    }

    fun handleText(userText: String): Job = scope.launch {
        val match = IntentMatch(
            rawText = userText, normalizedText = userText.lowercase().trim(),
            language = IntentMatch.Language.ENGLISH, clauses = listOf(userText.lowercase().trim()),
            actions = listOf(com.aegis.ai.intent.AegisAction.Unresolved(userText)), confidence = 0f
        )
        processTurn(match, userText)
    }

    private suspend fun processTurn(match: IntentMatch, prompt: String) = turnMutex.withLock {
        _events.tryEmit(BridgeEvent.TurnStarted(match.rawText))

        if (privacyPreferences?.isCloudReasoningEnabled() == false) {
            speak("क्लाउड सुविधा बंद है")
            _events.tryEmit(BridgeEvent.Failed(BridgeFailure.CloudDisabled, match.rawText))
            return@withLock
        }
        if (!networkMonitor.isOnline()) {
            speak("नेटवर्क कनेक्शन उपलब्ध नहीं है")
            _events.tryEmit(BridgeEvent.Failed(BridgeFailure.Offline, match.rawText))
            return@withLock
        }

        val history = contextManager?.dialogHistory().orEmpty()
        val contextBlock = contextualResolver?.contextBlockForPrompt()
        val memoryBlock = memoryManager?.buildMemoryBlock()

        val result = withTimeoutOrNull(TURN_TIMEOUT_MS) {
            apiClient.generate(prompt, history, contextBlock, memoryBlock)
        } ?: GeminiResult.UnknownError("timeout")

        when (result) {
            is GeminiResult.Success -> handleSuccess(match, result.text)
            GeminiResult.Offline -> { speak("नेटवर्क कनेक्शन उपलब्ध नहीं है"); fail(match, BridgeFailure.Offline) }
            GeminiResult.NoApiKey -> { speak("Gemini API key सेट नहीं है"); fail(match, BridgeFailure.NoApiKey) }
            is GeminiResult.Unauthorized -> { speak("API key मान्य नहीं है"); fail(match, BridgeFailure.Unauthorized) }
            is GeminiResult.Forbidden -> { speak("यह अनुरोध की अनुमति नहीं है"); fail(match, BridgeFailure.Forbidden) }
            is GeminiResult.BadRequest -> { speak("अनुरोध समझ नहीं आया"); fail(match, BridgeFailure.BadRequest(result.message)) }
            is GeminiResult.SafetyBlocked -> { speak("इस अनुरोध का उत्तर नहीं दे सकता"); fail(match, BridgeFailure.SafetyBlocked(result.reason)) }
            is GeminiResult.UnknownError -> { speak("सर्वर से जवाब नहीं मिला"); fail(match, BridgeFailure.Unknown(result.message)) }
            is GeminiResult.Retryable -> { speak("सर्वर से जवाब नहीं मिला"); fail(match, BridgeFailure.Unknown(result.reason.toString())) }
        }
    }

    private suspend fun fail(match: IntentMatch, failure: BridgeFailure) {
        recordTurn(match, null)
        _events.tryEmit(BridgeEvent.Failed(failure, match.rawText))
    }

    private suspend fun handleSuccess(match: IntentMatch, text: String) {
        val action = CognitiveActionParser.parse(text)
        if (action != null) {
            val outcome = try { actionExecutor.execute(action) }
            catch (ce: CancellationException) { throw ce }
            catch (t: Throwable) { null }
            if (outcome != null && outcome.success) {
                if (!action.isAutomation()) speak(shortAck(action))
                _events.tryEmit(BridgeEvent.ActionExecuted(action, true, outcome.message, outcome.elapsedMs))
            } else {
                speak(shortFailure(action))
                _events.tryEmit(BridgeEvent.ActionExecuted(action, false, outcome?.message ?: "threw", outcome?.elapsedMs ?: 0L))
            }
            recordTurn(match, text, listOf(action))
            return
        }
        val clean = sanitizeForSpeech(text)
        if (clean.isBlank()) return
        speak(clean)
        _events.tryEmit(BridgeEvent.Spoken(match.rawText, clean))
        recordTurn(match, clean)
    }

    private fun sanitizeForSpeech(raw: String): String {
        var s = raw.trim().removePrefix("```").removeSuffix("```").trim()
        s = s.replace(Regex("^[\\-\\*•●○▪▫]+\\s*", RegexOption.MULTILINE), "")
        s = s.replace(Regex("`{1,3}"), "").replace(Regex("\\*{1,3}"), "").replace(Regex("_{1,3}"), "")
        s = s.replace(Regex("\\[([^\\]]+)]\\([^)]+\\)"), "$1")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun shortAck(a: com.aegis.ai.intent.AegisAction): String = when (a) {
        com.aegis.ai.intent.AegisAction.AcceptCall -> "कॉल उठा रहा हूँ"
        com.aegis.ai.intent.AegisAction.RejectCall -> "कॉल काट रहा हूँ"
        else -> "ठीक है"
    }

    private fun shortFailure(a: com.aegis.ai.intent.AegisAction): String = "यह नहीं कर सका"

    private suspend fun speak(text: String) {
        val mgr = inEar ?: return
        runCatching { mgr.speak(text) }
    }

    private suspend fun recordTurn(match: IntentMatch, assistantText: String?, actions: List<com.aegis.ai.intent.AegisAction> = emptyList()) {
        val mgr = contextManager ?: return
        runCatching { mgr.recordTurn(match.rawText, assistantText, actions, language = match.language) }
    }

    sealed class BridgeEvent {
        data class TurnStarted(val utterance: String) : BridgeEvent()
        data class Spoken(val utterance: String, val reply: String) : BridgeEvent()
        data class ActionExecuted(val action: com.aegis.ai.intent.AegisAction, val success: Boolean, val message: String, val elapsedMs: Long) : BridgeEvent()
        data class Failed(val failure: BridgeFailure, val utterance: String) : BridgeEvent()
    }

    sealed class BridgeFailure {
        data object Offline : BridgeFailure()
        data object NoApiKey : BridgeFailure()
        data object Unauthorized : BridgeFailure()
        data object Forbidden : BridgeFailure()
        data class BadRequest(val message: String) : BridgeFailure()
        data class SafetyBlocked(val reason: String) : BridgeFailure()
        data class Unknown(val message: String?) : BridgeFailure()
        data object CloudDisabled : BridgeFailure()
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val TURN_TIMEOUT_MS = 15_000L
    }
}
