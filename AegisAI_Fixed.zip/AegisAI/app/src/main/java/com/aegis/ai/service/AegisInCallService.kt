package com.aegis.ai.service

import android.os.Build
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.util.Log
import com.aegis.ai.audio.AudioConfig

class AegisInCallService : InCallService() {

    override fun onCreate() { super.onCreate(); boundInstance = this }

    override fun onDestroy() {
        if (boundInstance === this) boundInstance = null
        currentCall = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) { super.onCallAdded(call); currentCall = call }
    override fun onCallRemoved(call: Call) { super.onCallRemoved(call); if (currentCall === call) currentCall = null }
    override fun onSilenceRinger() { super.onSilenceRinger() }

    private fun answerInternal(call: Call): Boolean = try { call.answer(VideoProfile.STATE_AUDIO_ONLY); true } catch (t: Throwable) { false }
    private fun rejectInternal(call: Call): Boolean = try { call.disconnect(); true } catch (t: Throwable) { false }

    companion object {
        private const val TAG = AudioConfig.TAG

        @Volatile private var boundInstance: AegisInCallService? = null
        @Volatile private var currentCall: Call? = null

        fun currentCallNumber(): String? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) currentCall?.details?.handle?.schemeSpecificPart else null
        } catch (_: Throwable) { null }

        fun answerCurrentCall(): Boolean {
            val svc = boundInstance ?: return false
            val call = currentCall ?: return false
            return svc.answerInternal(call)
        }

        fun rejectCurrentCall(): Boolean {
            val svc = boundInstance ?: return false
            val call = currentCall ?: return false
            return svc.rejectInternal(call)
        }
    }
}
