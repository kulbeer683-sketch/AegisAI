package com.aegis.ai.dashboard.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val Scheme = darkColorScheme(
    primary = AegisPalette.Accent, onPrimary = AegisPalette.Black,
    primaryContainer = AegisPalette.AccentDim, onPrimaryContainer = AegisPalette.TextPrimary,
    secondary = AegisPalette.Info, onSecondary = AegisPalette.Black,
    background = AegisPalette.Black, onBackground = AegisPalette.TextPrimary,
    surface = AegisPalette.Surface, onSurface = AegisPalette.TextPrimary,
    surfaceVariant = AegisPalette.SurfaceElevated, onSurfaceVariant = AegisPalette.TextSecondary,
    outline = AegisPalette.SurfaceOutline, outlineVariant = AegisPalette.SurfaceOutline,
    error = AegisPalette.Danger, onError = AegisPalette.Black
)

@Composable
fun AegisTheme(@Suppress("UNUSED_PARAMETER") darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AegisTypography, content = content)
}
