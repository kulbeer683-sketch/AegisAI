package com.aegis.ai.pipeline

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch

object FeedbackSynthesizer {

    fun synthesize(results: List<SubActionOutcome>, lang: IntentMatch.Language): String {
        if (results.isEmpty()) return ""
        val h = lang == IntentMatch.Language.HINDI || lang == IntentMatch.Language.HINGLISH
        val ok = results.filter { it.success }.map { success(it.task.action, h) }.filter { it.isNotBlank() }
        val fail = results.filter { !it.success }.map { failure(it.task.action, h) }.filter { it.isNotBlank() }
        if (ok.isEmpty() && fail.isEmpty()) return ""
        return buildString {
            when {
                ok.isEmpty() -> append(fail.joinToString(", "))
                fail.isEmpty() -> append(ok.joinToString(", "))
                else -> {
                    append(ok.joinToString(", "))
                    append(if (h) ", पर " else ", but ")
                    append(fail.joinToString(", "))
                }
            }
        }
    }

    private fun success(a: AegisAction, h: Boolean): String = when (a) {
        AegisAction.TorchOn -> if (h) "टॉर्च चालू कर दी" else "Torch on"
        AegisAction.TorchOff -> if (h) "टॉर्च बंद कर दी" else "Torch off"
        AegisAction.TorchToggle -> if (h) "टॉर्च बदल दी" else "Torch toggled"
        is AegisAction.VolumeSet -> if (h) "वॉल्यूम " + a.percent + "% किया" else "Volume " + a.percent + "%"
        is AegisAction.VolumeAdjust -> if (h) "वॉल्यूम बदल दिया" else "Volume adjusted"
        is AegisAction.VolumeMute -> if (a.mute) (if (h) "म्यूट कर दिया" else "Muted") else (if (h) "अनम्यूट" else "Unmuted")
        AegisAction.WifiOn -> if (h) "वाईफाई चालू कर दी" else "Wi-Fi on"
        AegisAction.WifiOff -> if (h) "वाईफाई बंद कर दी" else "Wi-Fi off"
        AegisAction.WifiToggle -> if (h) "वाईफाई बदल दी" else "Wi-Fi toggled"
        AegisAction.BluetoothOn -> if (h) "ब्लूटूथ चालू" else "Bluetooth on"
        AegisAction.BluetoothOff -> if (h) "ब्लूटूथ बंद" else "Bluetooth off"
        AegisAction.BluetoothToggle -> if (h) "ब्लूटूथ बदला" else "Bluetooth toggled"
        AegisAction.GoHome -> if (h) "होम" else "Home"
        AegisAction.GoBack -> if (h) "पीछे" else "Back"
        AegisAction.LockScreen -> if (h) "लॉक कर दी" else "Locked"
        is AegisAction.SetDnd -> if (a.enabled) (if (h) "साइलेंट चालू" else "DND on") else (if (h) "साइलेंट बंद" else "DND off")
        is AegisAction.SetNightMode -> if (a.enabled) (if (h) "डार्क मोड" else "Dark mode") else (if (h) "लाइट मोड" else "Light mode")
        is AegisAction.QueryVitals, is AegisAction.QueryPowerStatus, is AegisAction.SystemDiagnostics -> ""
        else -> ""
    }

    private fun failure(a: AegisAction, h: Boolean): String = when (a) {
        AegisAction.TorchOn, AegisAction.TorchOff, AegisAction.TorchToggle ->
            if (h) "टॉर्च नहीं बदल सका" else "Couldn't toggle torch"
        is AegisAction.VolumeSet, is AegisAction.VolumeAdjust, is AegisAction.VolumeMute ->
            if (h) "वॉल्यूम नहीं बदल सका" else "Couldn't change volume"
        AegisAction.WifiOn, AegisAction.WifiOff, AegisAction.WifiToggle ->
            if (h) "वाईफाई नहीं बदल सका" else "Couldn't toggle Wi-Fi"
        AegisAction.BluetoothOn, AegisAction.BluetoothOff, AegisAction.BluetoothToggle ->
            if (h) "ब्लूटूथ नहीं बदल सका" else "Couldn't toggle Bluetooth"
        else -> if (h) "कुछ नहीं हो सका" else "Something didn't work"
    }
}
