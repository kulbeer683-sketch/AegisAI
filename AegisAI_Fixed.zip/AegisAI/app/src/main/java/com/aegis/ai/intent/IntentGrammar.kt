package com.aegis.ai.intent

internal object IntentGrammar {

    private const val SPLIT = "\u0001"
    private val CONJ = Regex("\\b(and|aur|phir|then)\\b")
    private val DEV_CONJ = Regex("और|फिर")
    private val PUNCT = Regex("[,;+]")
    private val NUM = Regex("(\\d{1,3})")
    private val DEV = Regex("[\\u0900-\\u097F]")
    private val LAT = Regex("[A-Za-z]")

    private val TORCH = setOf("torch","flashlight","light","lamp","batti","टॉर्च","लाइट","बत्ती")
    private val VOL = setOf("volume","vol","sound","audio","awaz","aawaz","awaaz","वॉल्यूम","आवाज़","आवाज")
    private val WIFI = setOf("wifi","wireless","वाईफाई","वाई")
    private val BT = setOf("bluetooth","bt","ब्लूटूथ")
    private val LOCK = setOf("lock","लॉक")
    private val SCREEN = setOf("screen","display","स्क्रीन")
    private val ON = setOf("on","enable","chalu","chalao","jalao","jala","start","शुरू","ऑन","चालू","जलाओ","जला")
    private val OFF = setOf("off","disable","band","bujhao","stop","बंद","ऑफ","बुझाओ","बुझा","रोको")
    private val UP = setOf("up","increase","raise","louder","tez","badhao","बढ़ाओ","तेज","ऊपर")
    private val DOWN = setOf("down","decrease","lower","quieter","kam","ghatao","कम","घटाओ","नीचे")
    private val MUTE = setOf("mute","silent","म्यूट","साइलेंट","चुप")
    private val CALL = setOf("call","phone","कॉल","फोन")
    private val RING = setOf("ring","ringer","रिंग")
    private val NOTIF = setOf("notification","notifications","नोटिफिकेशन","सूचना")
    private val OPEN = setOf("open","launch","kholo","खोलो")
    private val HOME = setOf("home","launcher","होम")
    private val BACK = setOf("back","वापस","बैक","पीछे")
    private val RECENTS = setOf("recents","recent","overview","रीसेंट")
    private val DND = setOf("dnd","zen","साइलेंट","ज़ेन","डीएनडी")
    private val DISTURB = setOf("disturb","interruption","डिस्टर्ब")
    private val DARK = setOf("dark","night","डार्क","नाइट")
    private val LIGHT = setOf("light","day","लाइट")
    private val MODE = setOf("mode","theme","मोड","थीम")
    private val ROT = setOf("rotate","rotation","autorotate","रोटेशन")
    private val TIMEOUT = setOf("timeout","sleep","टाइमआउट","स्लीप")
    private val SEC = setOf("second","seconds","sec","सेकंड")
    private val MIN = setOf("minute","minutes","min","मिनट")
    private val AIRPLANE = setOf("airplane","flight","एयरप्लेन","फ्लाइट")
    private val LOCATION = setOf("location","gps","लोकेशन","जीपीएस")
    private val BATTERY = setOf("battery","charge","charging","बैटरी","चार्ज")
    private val TEMP = setOf("temperature","temp","heat","hot","तापमान","गर्मी")
    private val THERMAL = setOf("thermal","थर्मल")
    private val NET = setOf("network","signal","नेटवर्क","सिग्नल")
    private val VITALS = setOf("vitals","health","स्वास्थ्य")
    private val POWER = setOf("power","energy","drain","पावर","ऊर्जा")
    private val DIAG = setOf("diagnostic","diagnostics","self","test","status","स्टेटस","जाँच","जांच")
    private val SYSTEM_OK = setOf("सब","ठीक","sab","theek")

    private val HIN = setOf("karo","kar","chalu","band","jalao","badhao","kam","kholo","awaz","batti","tez","jao")
    private val STOP = setOf("the","a","an","app","please","को","का","की","के")

    fun parse(text: String): IntentMatch {
        val n = normalize(text)
        val lang = detectLanguage(text, n)
        val clauses = split(n).ifEmpty { listOf(n) }
        val actions = ArrayList<AegisAction>(clauses.size)
        var ok = 0
        for (c in clauses) {
            val a = match(c)
            if (a != null) { actions += a; ok++ }
            else if (c.isNotBlank()) actions += AegisAction.Unresolved(c)
        }
        val conf = if (clauses.isEmpty()) 0f else ok.toFloat() / clauses.size
        return IntentMatch(text, n, lang, clauses, actions, conf)
    }

    private fun normalize(t: String) = t.lowercase().replace(Regex("\\s+"), " ").trim()

    private fun detectLanguage(raw: String, n: String): IntentMatch.Language {
        val d = DEV.containsMatchIn(raw); val l = LAT.containsMatchIn(raw)
        val h = HIN.any { n.contains(it) }
        return when {
            d && l -> IntentMatch.Language.MIXED
            d -> IntentMatch.Language.HINDI
            h -> IntentMatch.Language.HINGLISH
            l -> IntentMatch.Language.ENGLISH
            else -> IntentMatch.Language.UNKNOWN
        }
    }

    private fun split(n: String): List<String> {
        var s = n
        s = s.replace(CONJ, SPLIT)
        s = s.replace(DEV_CONJ, SPLIT)
        s = s.replace(PUNCT, SPLIT)
        return s.split(SPLIT).map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun tokens(c: String): Set<String> =
        c.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()

    private fun match(c: String): AegisAction? {
        val t = tokens(c)
        if (t.isEmpty()) return null

        if (t.any { it in DIAG } || t.any { it in SYSTEM_OK }) return AegisAction.SystemDiagnostics
        if (t.any { it in POWER }) return AegisAction.QueryPowerStatus
        if (t.any { it in BATTERY } && t.any { it in TEMP }) return AegisAction.QueryVitals(VitalsQuery.BATTERY_TEMP)
        if (t.any { it in BATTERY }) return AegisAction.QueryVitals(VitalsQuery.BATTERY_STATUS)
        if (t.any { it in THERMAL } || t.any { it in TEMP }) return AegisAction.QueryVitals(VitalsQuery.THERMAL_STATUS)
        if (t.any { it in NET }) return AegisAction.QueryVitals(VitalsQuery.NETWORK_STATUS)
        if (t.any { it in VITALS }) return AegisAction.QueryVitals(VitalsQuery.FULL_REPORT)

        if (t.any { it in DND } || t.any { it in DISTURB }) {
            return when {
                t.any { it in OFF } || t.any { it in MUTE } -> AegisAction.SetDnd(false)
                else -> AegisAction.SetDnd(true)
            }
        }
        if (t.any { it in DARK } && t.any { it in MODE }) return AegisAction.SetNightMode(true)
        if (t.any { it in LIGHT } && t.any { it in MODE }) return AegisAction.SetNightMode(false)
        if (t.any { it in ROT }) return AegisAction.SetAutoRotation(!t.any { it in OFF })
        if (t.any { it in TIMEOUT }) {
            val num = NUM.find(c)?.groupValues?.get(1)?.toLongOrNull()
            if (num != null) {
                val ms = when {
                    t.any { it in MIN } -> num * 60000L
                    t.any { it in SEC } -> num * 1000L
                    num < 100L -> num * 1000L
                    else -> num * 60000L
                }
                return AegisAction.SetScreenTimeout(ms)
            }
        }
        if (t.any { it in AIRPLANE }) return AegisAction.RequestAirplanePanel
        if (t.any { it in LOCATION }) return AegisAction.RequestLocationPanel

        if (t.any { it in VOL }) {
            val num = NUM.find(c)?.groupValues?.get(1)?.toIntOrNull()
            val stream = stream(t)
            if (num != null) return AegisAction.VolumeSet(stream, num.coerceIn(0, 100))
            if (t.any { it in MUTE }) return AegisAction.VolumeMute(stream, true)
            if (t.any { it in UP }) return AegisAction.VolumeAdjust(stream, AegisAction.Direction.UP)
            if (t.any { it in DOWN }) return AegisAction.VolumeAdjust(stream, AegisAction.Direction.DOWN)
        }
        if (t.any { it in TORCH }) {
            return when {
                t.any { it in OFF } -> AegisAction.TorchOff
                t.any { it in ON } -> AegisAction.TorchOn
                else -> AegisAction.TorchToggle
            }
        }
        if (t.any { it in WIFI }) {
            return when {
                t.any { it in OFF } -> AegisAction.WifiOff
                t.any { it in ON } -> AegisAction.WifiOn
                else -> AegisAction.WifiToggle
            }
        }
        if (t.any { it in BT }) {
            return when {
                t.any { it in OFF } -> AegisAction.BluetoothOff
                t.any { it in ON } -> AegisAction.BluetoothOn
                else -> AegisAction.BluetoothToggle
            }
        }
        if (t.any { it in HOME }) return AegisAction.GoHome
        if (t.any { it in RECENTS }) return AegisAction.ShowRecents
        if (t.any { it in NOTIF }) return AegisAction.ShowNotifications
        if (t.any { it in BACK }) return AegisAction.GoBack
        if (t.any { it in LOCK } && (t.any { it in SCREEN } || t.size <= 3)) return AegisAction.LockScreen
        if (t.any { it in OPEN }) {
            val app = t.filter { it !in STOP && it !in ON && it !in OFF }.joinToString(" ")
            if (app.isNotBlank()) return AegisAction.OpenApp(app)
        }
        return null
    }

    private fun stream(t: Set<String>): AudioStream = when {
        t.any { it in CALL } -> AudioStream.CALL
        t.any { it in RING } -> AudioStream.RING
        t.any { it in NOTIF } -> AudioStream.NOTIFICATION
        else -> AudioStream.MEDIA
    }
}
