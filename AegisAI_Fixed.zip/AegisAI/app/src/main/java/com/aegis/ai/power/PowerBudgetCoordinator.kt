package com.aegis.ai.power

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.vitals.DeviceVitalsMonitor
import com.aegis.ai.vitals.ThermalStatus
import com.aegis.ai.vitals.VitalsSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicReference

class PowerBudgetCoordinator(
    private val scope: CoroutineScope,
    private val vitalsMonitor: DeviceVitalsMonitor
) {

    private val tierRef = AtomicReference(ThrottleTier.NORMAL)
    private val _tier = MutableStateFlow(ThrottleTier.NORMAL)
    val tier: StateFlow<ThrottleTier> = _tier.asStateFlow()

    private val _transitions = MutableSharedFlow<ThrottleTransition>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val transitions: SharedFlow<ThrottleTransition> = _transitions.asSharedFlow()

    private val mutex = Mutex()
    private var relaxationStreak = 0
    private var job: Job? = null

    @Volatile private var lastTransition: ThrottleTransition? = null

    fun start() {
        job?.cancel()
        job = vitalsMonitor.snapshot
            .distinctUntilChanged { o, n -> o.batteryPercent == n.batteryPercent && o.batteryTempC == n.batteryTempC && o.thermalStatus == n.thermalStatus && o.isCharging == n.isCharging }
            .onEach { evaluate(it) }
            .launchIn(scope)
    }

    fun stop() { job?.cancel(); job = null }

    fun currentTier(): ThrottleTier = tierRef.get()
    fun lastTransitionOrNull(): ThrottleTransition? = lastTransition

    fun reevaluateNow() { scope.launch { evaluate(vitalsMonitor.current()) } }

    fun allowsCapability(cap: Capability): Boolean {
        val t = tierRef.get()
        return when (cap) {
            Capability.HUD_ANIMATION -> t != ThrottleTier.CRITICAL
            Capability.SCREEN_VISION -> t != ThrottleTier.CRITICAL
            Capability.CAMERA_VISION -> t != ThrottleTier.CRITICAL
            Capability.PROACTIVE_ROUTINES -> t != ThrottleTier.CRITICAL
            Capability.FULL_DIAGNOSTICS -> t == ThrottleTier.NORMAL
            Capability.NON_CRITICAL_TTS -> t != ThrottleTier.CRITICAL
            Capability.WAKE_WORD_KWS, Capability.FAST_INTENTS -> true
        }
    }

    enum class Capability {
        HUD_ANIMATION, SCREEN_VISION, CAMERA_VISION, PROACTIVE_ROUTINES,
        FULL_DIAGNOSTICS, NON_CRITICAL_TTS, WAKE_WORD_KWS, FAST_INTENTS
    }

    private suspend fun evaluate(s: VitalsSnapshot) = mutex.withLock {
        val cur = tierRef.get()
        val next = computeDesired(s, cur)
        if (next == cur) return@withLock
        val t = ThrottleTransition(cur, next, reasonFor(s, cur, next), s.batteryTempC, s.batteryPercent, SystemClock.elapsedRealtime())
        tierRef.set(next); _tier.value = next; lastTransition = t; relaxationStreak = 0
        Log.w(TAG, "Throttle ${cur.name} → ${next.name} (temp=${"%.1f".format(s.batteryTempC)}°C bat=${s.batteryPercent}%) — ${t.reason}")
        _transitions.tryEmit(t)
    }

    private fun computeDesired(s: VitalsSnapshot, cur: ThrottleTier): ThrottleTier {
        val temp = s.batteryTempC; val bat = s.batteryPercent
        val thermalSevere = s.thermalStatus == ThermalStatus.SEVERE || s.thermalStatus == ThermalStatus.CRITICAL || s.thermalStatus == ThermalStatus.EMERGENCY
        return when (cur) {
            ThrottleTier.NORMAL -> when {
                thermalSevere -> ThrottleTier.CRITICAL
                temp >= ESCALATE_TO_THROTTLED_TEMP_C -> ThrottleTier.THROTTLED
                bat <= ESCALATE_TO_THROTTLED_BATTERY_PCT -> ThrottleTier.THROTTLED
                else -> ThrottleTier.NORMAL
            }
            ThrottleTier.THROTTLED -> when {
                thermalSevere -> ThrottleTier.CRITICAL
                temp >= ESCALATE_TO_CRITICAL_TEMP_C -> ThrottleTier.CRITICAL
                bat <= ESCALATE_TO_CRITICAL_BATTERY_PCT -> ThrottleTier.CRITICAL
                temp <= RELAX_TO_NORMAL_TEMP_C && bat >= RELAX_TO_NORMAL_BATTERY_PCT -> {
                    relaxationStreak++
                    if (relaxationStreak >= RELAX_TO_NORMAL_STREAK) { relaxationStreak = 0; ThrottleTier.NORMAL } else ThrottleTier.THROTTLED
                }
                else -> { relaxationStreak = 0; ThrottleTier.THROTTLED }
            }
            ThrottleTier.CRITICAL -> when {
                temp <= RELAX_TO_THROTTLED_TEMP_C && bat >= RELAX_TO_THROTTLED_BATTERY_PCT -> {
                    relaxationStreak++
                    if (relaxationStreak >= RELAX_TO_THROTTLED_STREAK) { relaxationStreak = 0; ThrottleTier.THROTTLED } else ThrottleTier.CRITICAL
                }
                else -> { relaxationStreak = 0; ThrottleTier.CRITICAL }
            }
        }
    }

    private fun reasonFor(s: VitalsSnapshot, from: ThrottleTier, to: ThrottleTier): String = when {
        to.ordinal > from.ordinal && s.batteryTempC >= ESCALATE_TO_CRITICAL_TEMP_C -> "temp critical"
        to.ordinal > from.ordinal && s.batteryPercent <= ESCALATE_TO_CRITICAL_BATTERY_PCT -> "battery critical"
        to.ordinal > from.ordinal && s.batteryTempC >= ESCALATE_TO_THROTTLED_TEMP_C -> "temp high"
        to.ordinal > from.ordinal && s.batteryPercent <= ESCALATE_TO_THROTTLED_BATTERY_PCT -> "battery low"
        to.ordinal < from.ordinal -> "recovered"
        else -> "state change"
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val ESCALATE_TO_THROTTLED_TEMP_C = 39.0f
        const val ESCALATE_TO_THROTTLED_BATTERY_PCT = 20
        const val ESCALATE_TO_CRITICAL_TEMP_C = 43.0f
        const val ESCALATE_TO_CRITICAL_BATTERY_PCT = 10
        const val RELAX_TO_NORMAL_TEMP_C = 38.0f
        const val RELAX_TO_NORMAL_BATTERY_PCT = 22
        const val RELAX_TO_NORMAL_STREAK = 3
        const val RELAX_TO_THROTTLED_TEMP_C = 42.0f
        const val RELAX_TO_THROTTLED_BATTERY_PCT = 12
        const val RELAX_TO_THROTTLED_STREAK = 5
    }
}
