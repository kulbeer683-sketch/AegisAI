package com.aegis.ai.notifications

enum class NotificationCategory { MESSAGING, BANKING, OTP, CALENDAR, CALL, OTHER }
enum class NotificationPriority { HIGH, LOW }

data class CachedNotification(
    val key: String, val packageName: String, val category: NotificationCategory,
    val priority: NotificationPriority, val sender: String?, val title: String?,
    val body: String?, val hasReplyAction: Boolean, val postedAtMs: Long,
    val digested: Boolean = false
) {
    val logTag: String get() = "${category.name.lowercase()}:${packageName.substringAfterLast('.')}"
}

sealed class ReplyResult {
    data class Success(val packageName: String) : ReplyResult()
    data object NotificationNotFound : ReplyResult()
    data object NoReplyAction : ReplyResult()
    data object PendingIntentCanceled : ReplyResult()
    data class Failure(val message: String) : ReplyResult()
}

sealed class DigestResult {
    data class Success(val spoken: String, val count: Int) : DigestResult()
    data object NothingToReport : DigestResult()
    data object ListenerUnavailable : DigestResult()
}
