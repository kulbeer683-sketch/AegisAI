package com.aegis.ai.notifications

import android.os.SystemClock
import com.aegis.ai.intent.IntentMatch

class NotificationDigestEngine(private val language: IntentMatch.Language = IntentMatch.Language.HINGLISH) {

    fun digest(listenerProvider: () -> SmartNotificationListener?): DigestResult {
        val listener = listenerProvider() ?: return DigestResult.ListenerUnavailable
        val all = listener.recentHighPriority()
        if (all.isEmpty()) return DigestResult.NothingToReport
        val fresh = all.filter { !it.digested && isRecent(it) }
        if (fresh.isEmpty()) return DigestResult.NothingToReport
        val spoken = buildSummary(fresh, language)
        if (spoken.isBlank()) return DigestResult.NothingToReport
        listener.markDigested(fresh.map { it.key })
        return DigestResult.Success(spoken, fresh.size)
    }

    private fun buildSummary(list: List<CachedNotification>, lang: IntentMatch.Language): String {
        val hindi = lang == IntentMatch.Language.HINDI || lang == IntentMatch.Language.HINGLISH || lang == IntentMatch.Language.MIXED
        val byCat = list.groupBy { it.category }
        val clauses = ArrayList<String>(4)
        byCat[NotificationCategory.MESSAGING]?.let { clauses += messaging(it, hindi) }
        byCat[NotificationCategory.BANKING]?.let { clauses += banking(it, hindi) }
        byCat[NotificationCategory.OTP]?.let { clauses += otp(it, hindi) }
        byCat[NotificationCategory.CALENDAR]?.let { clauses += calendar(it, hindi) }
        byCat[NotificationCategory.CALL]?.let { clauses += call(it, hindi) }
        byCat[NotificationCategory.OTHER]?.let { clauses += other(it, hindi) }
        if (clauses.isEmpty()) return ""
        val conn = if (hindi) " और " else ", and "
        return clauses.joinToString(conn).take(220)
    }

    private fun messaging(msgs: List<CachedNotification>, hindi: Boolean): String {
        val senders = msgs.mapNotNull { it.sender }.distinct()
        return when {
            msgs.size == 1 && senders.size == 1 -> if (hindi) "${senders.first()} ने मैसेज भेजा है" else "a message from ${senders.first()}"
            senders.size == 1 -> if (hindi) "${senders.first()} के ${msgs.size} मैसेज हैं" else "${msgs.size} messages from ${senders.first()}"
            else -> if (hindi) "${msgs.size} मैसेजेस हैं" else "${msgs.size} messages"
        }
    }

    private fun banking(l: List<CachedNotification>, h: Boolean) = if (h) (if (l.size == 1) "एक बैंकिंग अलर्ट है" else "${l.size} बैंकिंग अलर्ट्स हैं") else (if (l.size == 1) "one banking alert" else "${l.size} banking alerts")
    private fun otp(l: List<CachedNotification>, h: Boolean) = if (h) (if (l.size == 1) "एक OTP आया है" else "${l.size} OTP आए हैं") else (if (l.size == 1) "an OTP arrived" else "${l.size} OTPs arrived")
    private fun calendar(l: List<CachedNotification>, h: Boolean) = if (h) (if (l.size == 1) "एक कैलेंडर रिमाइंडर है" else "${l.size} कैलेंडर रिमाइंडर हैं") else (if (l.size == 1) "a calendar reminder" else "${l.size} calendar reminders")
    private fun call(l: List<CachedNotification>, h: Boolean) = if (h) (if (l.size == 1) "एक मिस्ड कॉल है" else "${l.size} मिस्ड कॉल्स हैं") else (if (l.size == 1) "a missed call" else "${l.size} missed calls")
    private fun other(l: List<CachedNotification>, h: Boolean) = if (h) (if (l.size == 1) "एक और सूचना है" else "${l.size} और सूचनाएँ हैं") else (if (l.size == 1) "one more notification" else "${l.size} more notifications")

    private fun isRecent(e: CachedNotification): Boolean = (SystemClock.elapsedRealtime() - e.postedAtMs) <= FRESH_WINDOW_MS

    private companion object { const val FRESH_WINDOW_MS = 30 * 60_000L }
}
