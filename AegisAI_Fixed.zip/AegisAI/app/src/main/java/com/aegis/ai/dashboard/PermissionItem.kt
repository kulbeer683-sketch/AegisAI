package com.aegis.ai.dashboard

import android.content.Context

data class PermissionItem(
    val id: String, val title: String, val description: String,
    val category: PermissionCategory, val required: Boolean,
    val isGranted: (Context) -> Boolean, val openSettings: (Context) -> Unit
)

enum class PermissionCategory {
    AUDIO_AND_HARDWARE, PHONE_AND_CONTACTS, LOCATION, CAMERA, CONNECTIVITY, NOTIFICATIONS, SPECIAL_ACCESS
}
