package com.aegis.ai.decision

import com.aegis.ai.intent.IntentMatch

enum class DecisionPriority(val level: Int) {
    P0_CRITICAL(0), P1_USER_ACTIVE(1), P2_HIGH_NOTIFICATION(2), P3_PROACTIVE(3);
    fun canPreempt(other: DecisionPriority): Boolean = level < other.level
    companion object {
        fun forOrigin(o: DecisionOrigin): DecisionPriority = when (o) {
            DecisionOrigin.TELEPHONY, DecisionOrigin.CRITICAL_BATTERY,
            DecisionOrigin.THERMAL_ALERT -> P0_CRITICAL
            DecisionOrigin.WAKE_WORD, DecisionOrigin.VOICE_COMMAND,
            DecisionOrigin.SLOT_FILLING -> P1_USER_ACTIVE
            DecisionOrigin.NOTIFICATION_HIGH -> P2_HIGH_NOTIFICATION
            DecisionOrigin.SPATIAL_ROUTINE, DecisionOrigin.SCHEDULED_ROUTINE,
            DecisionOrigin.HEARTBEAT, DecisionOrigin.MANUAL -> P3_PROACTIVE
        }
    }
}

enum class DecisionOrigin {
    TELEPHONY, CRITICAL_BATTERY, THERMAL_ALERT, WAKE_WORD, VOICE_COMMAND,
    SLOT_FILLING, NOTIFICATION_HIGH, SPATIAL_ROUTINE, SCHEDULED_ROUTINE,
    HEARTBEAT, MANUAL
}

enum class ExecutionCapability {
    FAST_PATH, CONTEXTUAL_LOCAL, SCREEN_VISION, CAMERA_VISION, CLOUD_LLM, BLOCKED
}

data class DecisionRequest(
    val id: String,
    val origin: DecisionOrigin,
    val priority: DecisionPriority,
    val match: IntentMatch?,
    val label: String,
    val correlationId: String? = null
)

data class DecisionOutcome(
    val request: DecisionRequest,
    val admitted: Boolean,
    val capability: ExecutionCapability,
    val reason: String,
    val preemptedExisting: Boolean
)

data class PreemptionEvent(
    val victim: DecisionRequest,
    val byPriority: DecisionPriority,
    val byLabel: String
)
