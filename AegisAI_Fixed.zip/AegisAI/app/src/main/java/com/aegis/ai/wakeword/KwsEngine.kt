package com.aegis.ai.wakeword

import com.aegis.ai.audio.AudioConfig
import kotlin.math.log10
import kotlin.math.sqrt

interface KwsEngine : AutoCloseable {
    val frameSize: Int
    val sampleRate: Int
    val keywords: List<String>
    fun reset()
    fun process(frame: ShortArray): FloatArray
}

class TemplateKwsEngine(
    override val frameSize: Int = AudioConfig.FRAME_SIZE,
    override val sampleRate: Int = AudioConfig.SAMPLE_RATE,
    override val keywords: List<String> = DEFAULT_KEYWORDS
) : KwsEngine {

    private val historySize = 80
    private val rms = FloatArray(historySize) { SILENCE }
    private var idx = 0
    private var count = 0

    override fun reset() { for (i in rms.indices) rms[i] = SILENCE; idx = 0; count = 0 }

    override fun process(frame: ShortArray): FloatArray {
        require(frame.size == frameSize)
        val r = computeRms(frame)
        rms[idx] = r; idx = (idx + 1) % historySize
        if (count < historySize) count++
        val s = score(r)
        return FloatArray(keywords.size) { s }
    }

    override fun close() { reset() }

    private fun score(cur: Float): Float {
        if (count < MIN_HISTORY) return 0f
        val ordered = FloatArray(count)
        val start = if (count < historySize) 0 else idx
        for (i in 0 until count) ordered[i] = rms[(start + i) % historySize]

        var st = 0; var b1 = 0; var b2 = 0; var gap = 0; var b1e = 0f; var b2e = 0f
        for (i in ordered.indices) {
            val loud = ordered[i] >= LOUD
            val quiet = ordered[i] <= QUIET
            when (st) {
                0 -> if (loud) { st = 1; b1 = i; b1e = ordered[i] }
                1 -> if (quiet) { b1 = i - b1; st = 2; gap = 1 } else b1e = maxOf(b1e, ordered[i])
                2 -> if (loud) { st = 3; b2 = i; b2e = ordered[i] } else { gap++; if (gap > MAX_GAP) st = 0 }
                3 -> if (quiet) { b2 = i - b2; st = 4; break } else b2e = maxOf(b2e, ordered[i])
            }
        }

        if (st == 4 && b1 >= MIN_B1 && gap in MIN_GAP..MAX_GAP && b2 >= MIN_B2) {
            val len = minOf(1f, b2 / 10f) * minOf(1f, b1 / 6f)
            val e = (minOf(b1e, b2e) - QUIET) / (LOUD - QUIET).coerceAtLeast(1f)
            val q = cur <= QUIET
            val sc = len.coerceIn(0f, 1f) * 0.4f + e.coerceIn(0f, 1f) * 0.4f + if (q) 0.2f else 0f
            idx = 0; count = 0
            return sc.coerceIn(0f, 1f)
        }
        return 0f
    }

    private fun computeRms(f: ShortArray): Float {
        var s = 0.0
        for (v in f) { val d = v.toDouble(); s += d * d }
        val r = sqrt(s / f.size)
        if (r < 1.0) return SILENCE
        return (20.0 * log10(r / 32768.0)).toFloat()
    }

    companion object {
        private val DEFAULT_KEYWORDS = listOf("hey aegis", "सुनो एजिस")
        private const val SILENCE = -100f
        private const val QUIET = -48f
        private const val LOUD = -32f
        private const val MIN_HISTORY = 30
        private const val MIN_B1 = 3
        private const val MIN_B2 = 4
        private const val MIN_GAP = 1
        private const val MAX_GAP = 12
    }
}
