package com.aegis.ai.memory.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "knowledge_memory",
    indices = [Index(value = ["key"], unique = true), Index(value = ["category"])]
)
data class KnowledgeMemoryEntity(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") val id: Long = 0L,
    @ColumnInfo(name = "key") val key: String,
    @ColumnInfo(name = "display_key") val displayKey: String,
    @ColumnInfo(name = "value") val value: String,
    @ColumnInfo(name = "category") val category: String = "general",
    @ColumnInfo(name = "source_utterance") val sourceUtterance: String? = null,
    @ColumnInfo(name = "created_at_ms") val createdAtMs: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at_ms") val updatedAtMs: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "hit_count") val hitCount: Long = 0L
)
