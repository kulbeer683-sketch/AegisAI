package com.aegis.ai.vitals

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class ProactiveAlertLoop(
    private val scope: CoroutineScope,
    private val vitalsMonitor: DeviceVitalsMonitor,
    private val inEar: InEarNotificationManager?,
    private val tickIntervalMs: Long = TICK_MS,
    private val cooldownMs: Long = COOLDOWN_MS
) {

    private val firedAt = mutableMapOf<AlertKind, Long>()
    private val cooldownMutex = Mutex()
    private var loopJob: Job? = null

    fun start() {
        if (loopJob != null) return
        loopJob = scope.launch {
            delay(tickIntervalMs)
            while (isActive) {
                try { evaluate() } catch (t: Throwable) { Log.e(TAG, "evaluate threw", t) }
                delay(tickIntervalMs)
            }
        }
    }

    fun stop() { loopJob?.cancel(); loopJob = null }

    private suspend fun evaluate() {
        val s = vitalsMonitor.current()
        val now = SystemClock.elapsedRealtime()

        if (s.batteryPercent in 1..LOW_BATTERY && !s.isCharging) {
            tryFire(AlertKind.LOW_BATTERY, now) { speak("बैटरी ${s.batteryPercent}% बची है, क्या पावर सेवर ऑन करूँ?") }
        }
        if (s.batteryPercent >= 100 && (s.batteryStatus == BatteryStatus.FULL || (s.isPluggedAcOrUsb && s.batteryStatus == BatteryStatus.CHARGING))) {
            tryFire(AlertKind.FULL_BATTERY, now) { speak("बैटरी फुल चार्ज हो चुकी है") }
        }
        val tempHigh = !s.batteryTempC.isNaN() && s.batteryTempC >= THERMAL_TEMP_C
        val thermalHigh = s.thermalStatus == ThermalStatus.SEVERE || s.thermalStatus == ThermalStatus.CRITICAL || s.thermalStatus == ThermalStatus.EMERGENCY
        if (tempHigh || thermalHigh) {
            tryFire(AlertKind.THERMAL_WARNING, now) { speak("डिवाइस का तापमान अधिक है") }
        }
    }

    private suspend fun tryFire(kind: AlertKind, now: Long, block: suspend () -> Unit) {
        val allowed = cooldownMutex.withLock {
            val last = firedAt[kind] ?: 0L
            if (now - last < cooldownMs) false
            else { firedAt[kind] = now; true }
        }
        if (allowed) block()
    }

    private suspend fun speak(text: String) {
        runCatching { inEar?.speak(text) }
    }

    enum class AlertKind { LOW_BATTERY, FULL_BATTERY, THERMAL_WARNING }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val TICK_MS = 30_000L
        private const val COOLDOWN_MS = 15 * 60_000L
        private const val LOW_BATTERY = 15
        private const val THERMAL_TEMP_C = 42.0f
    }
}
