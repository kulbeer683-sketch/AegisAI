package com.aegis.ai.cognitive

import android.util.Base64
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.recovery.CognitiveCircuitBreaker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.min
import kotlin.math.pow

class GeminiApiClient(
    private val apiKeyProvider: () -> String?,
    private val networkMonitor: NetworkMonitor,
    private val circuitBreaker: CognitiveCircuitBreaker? = null
) {

    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        encodeDefaults = true
    }

    private val httpDispatcher = Dispatcher().apply {
        maxRequests = 8
        maxRequestsPerHost = 4
    }

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .dispatcher(httpDispatcher)
        .connectionPool(ConnectionPool(2, 5, TimeUnit.MINUTES))
        .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .callTimeout(CALL_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val requestCounter = AtomicInteger(0)

    suspend fun generate(
        userText: String,
        history: List<DialogTurn> = emptyList(),
        contextBlock: String? = null,
        memoryBlock: String? = null,
        temperature: Double = 0.35,
        maxOutputTokens: Int = 256
    ): GeminiResult {
        if (userText.isBlank()) return GeminiResult.BadRequest("Empty prompt")
        val apiKey = apiKeyProvider()?.trim().orEmpty()
        if (apiKey.isBlank()) return GeminiResult.NoApiKey
        if (!networkMonitor.isOnline()) return GeminiResult.Offline
        circuitBreaker?.let { if (!it.shouldAttempt()) return GeminiResult.Offline }

        val body = buildRequestBody(userText, history, contextBlock, memoryBlock, temperature, maxOutputTokens)
        val n = requestCounter.incrementAndGet()
        Log.d(TAG, "Gemini request #$n turns=${history.size + 1} len=${userText.length}")
        return observeResult(postWithRetries(apiKey, body))
    }

    suspend fun analyzeScreenContent(
        userPrompt: String,
        imageBytes: ByteArray,
        mimeType: String = "image/jpeg",
        temperature: Double = 0.25,
        maxOutputTokens: Int = 220
    ): GeminiResult {
        if (imageBytes.isEmpty()) return GeminiResult.BadRequest("Empty image")
        if (userPrompt.isBlank()) return GeminiResult.BadRequest("Empty prompt")
        val apiKey = apiKeyProvider()?.trim().orEmpty()
        if (apiKey.isBlank()) return GeminiResult.NoApiKey
        if (!networkMonitor.isOnline()) return GeminiResult.Offline
        circuitBreaker?.let { if (!it.shouldAttempt()) return GeminiResult.Offline }

        val b64 = Base64.encodeToString(imageBytes, Base64.NO_WRAP)
        val body = buildVisionBody(userPrompt, VISION_SYSTEM_INSTRUCTION, mimeType, b64, temperature, maxOutputTokens)
        Log.d(TAG, "Gemini vision request imageBytes=${imageBytes.size}")
        return observeResult(postWithRetries(apiKey, body))
    }

    suspend fun analyzeRealWorldScene(
        userQuery: String,
        imageBytes: ByteArray,
        mimeType: String = "image/jpeg",
        temperature: Double = 0.25,
        maxOutputTokens: Int = 220
    ): GeminiResult {
        if (imageBytes.isEmpty()) return GeminiResult.BadRequest("Empty image")
        if (userQuery.isBlank()) return GeminiResult.BadRequest("Empty prompt")
        val apiKey = apiKeyProvider()?.trim().orEmpty()
        if (apiKey.isBlank()) return GeminiResult.NoApiKey
        if (!networkMonitor.isOnline()) return GeminiResult.Offline
        circuitBreaker?.let { if (!it.shouldAttempt()) return GeminiResult.Offline }

        val b64 = Base64.encodeToString(imageBytes, Base64.NO_WRAP)
        val body = buildVisionBody(userQuery, REAL_WORLD_SYSTEM_INSTRUCTION, mimeType, b64, temperature, maxOutputTokens)
        Log.d(TAG, "Gemini real-world request imageBytes=${imageBytes.size}")
        return observeResult(postWithRetries(apiKey, body))
    }

    fun shutdown() {
        runCatching { httpDispatcher.executorService.shutdown(); httpClient.connectionPool.evictAll() }
    }

    private fun observeResult(r: GeminiResult): GeminiResult {
        circuitBreaker?.let { cb ->
            when (r) {
                is GeminiResult.Success -> cb.recordSuccess()
                GeminiResult.Offline, is GeminiResult.UnknownError, is GeminiResult.Retryable -> cb.recordTransientFailure()
                else -> cb.recordPersistentFailure()
            }
        }
        return r
    }

    private suspend fun postWithRetries(apiKey: String, body: String): GeminiResult {
        var attempt = 0
        var last: GeminiResult = GeminiResult.UnknownError("no attempt")
        while (attempt <= MAX_RETRIES) {
            if (attempt > 0) delay(computeBackoff(attempt))
            when (val r = executeOnce(apiKey, body)) {
                is GeminiResult.Success -> return r
                is GeminiResult.Retryable -> { last = r.reason; attempt++ }
                is GeminiResult.BadRequest, is GeminiResult.Unauthorized, is GeminiResult.Forbidden,
                is GeminiResult.SafetyBlocked, GeminiResult.NoApiKey, GeminiResult.Offline -> return r
                is GeminiResult.UnknownError -> { last = r; attempt++ }
            }
        }
        return last
    }

    private suspend fun executeOnce(apiKey: String, body: String): GeminiResult {
        val req = try {
            Request.Builder()
                .url("$BASE_URL$MODEL_ID:generateContent?key=$apiKey")
                .header("Content-Type", "application/json; charset=utf-8")
                .post(body.toRequestBody(JSON_MEDIA))
                .build()
        } catch (t: Throwable) { return GeminiResult.BadRequest("Request build failed: ${t.message}") }

        val resp = try { httpClient.newCall(req).await() }
        catch (ce: CancellationException) { throw ce }
        catch (io: IOException) {
            return GeminiResult.Retryable(
                if (networkMonitor.isOnline()) GeminiResult.UnknownError("IO: ${io.message}")
                else GeminiResult.Offline
            )
        } catch (t: Throwable) { return GeminiResult.Retryable(GeminiResult.UnknownError(t.message)) }

        resp.use { r ->
            val text = try { r.body?.string().orEmpty() } catch (_: Throwable) { "" }
            return when (r.code) {
                200 -> parseSuccess(text)
                400 -> GeminiResult.BadRequest(err(text) ?: "HTTP 400")
                401 -> GeminiResult.Unauthorized(err(text) ?: "HTTP 401")
                403 -> GeminiResult.Forbidden(err(text) ?: "HTTP 403")
                404 -> GeminiResult.BadRequest("Model not found")
                408, 425 -> GeminiResult.Retryable(GeminiResult.UnknownError("HTTP ${r.code}"))
                429 -> GeminiResult.Retryable(GeminiResult.UnknownError("Rate limited"))
                in 500..599 -> GeminiResult.Retryable(GeminiResult.UnknownError("Server HTTP ${r.code}"))
                else -> GeminiResult.BadRequest("Unexpected HTTP ${r.code}")
            }
        }
    }

    private fun parseSuccess(body: String): GeminiResult {
        if (body.isBlank()) return GeminiResult.UnknownError("Empty response")
        val parsed = try { json.decodeFromString(GeminiResponse.serializer(), body) }
        catch (t: Throwable) { return GeminiResult.UnknownError("Malformed JSON") }
        parsed.promptFeedback?.blockReason?.let { return GeminiResult.SafetyBlocked(it) }
        val text = parsed.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
        if (text.isNullOrBlank()) return GeminiResult.UnknownError("Model returned no text")
        return GeminiResult.Success(text)
    }

    private fun buildRequestBody(
        userText: String, history: List<DialogTurn>, contextBlock: String?,
        memoryBlock: String?, temperature: Double, maxOutputTokens: Int
    ): String {
        val contents = ArrayList<GeminiContent>(history.size + 1)
        for (t in history) contents += GeminiContent(role = t.role, parts = listOf(GeminiPart(text = t.text)))
        val currentPart = buildString {
            if (!memoryBlock.isNullOrBlank()) { append(memoryBlock.trim()); append("\n\n") }
            if (!contextBlock.isNullOrBlank()) { append("[CONVERSATION_CONTEXT]\n"); append(contextBlock.trim()); append("\n\n") }
            append("[USER]\n"); append(userText.trim())
        }
        contents += GeminiContent(role = "user", parts = listOf(GeminiPart(text = currentPart)))
        val req = GeminiRequest(
            contents = contents,
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = SYSTEM_INSTRUCTION))),
            generationConfig = GenerationConfig(temperature, 0.9, 40, maxOutputTokens, 1, emptyList()),
            safetySettings = defaultSafety()
        )
        return json.encodeToString(GeminiRequest.serializer(), req)
    }

    private fun buildVisionBody(
        userPrompt: String, systemInstruction: String, mime: String,
        b64: String, temperature: Double, maxOutputTokens: Int
    ): String {
        val req = GeminiRequest(
            contents = listOf(
                GeminiContent(role = "user", parts = listOf(
                    GeminiPart(text = userPrompt),
                    GeminiPart(inlineData = InlineData(mimeType = mime, data = b64))
                ))
            ),
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemInstruction))),
            generationConfig = GenerationConfig(temperature, 0.9, 40, maxOutputTokens, 1, emptyList()),
            safetySettings = defaultSafety()
        )
        return json.encodeToString(GeminiRequest.serializer(), req)
    }

    private fun defaultSafety(): List<SafetySetting> = listOf(
        SafetySetting("HARM_CATEGORY_HARASSMENT", "BLOCK_MEDIUM_AND_ABOVE"),
        SafetySetting("HARM_CATEGORY_HATE_SPEECH", "BLOCK_MEDIUM_AND_ABOVE"),
        SafetySetting("HARM_CATEGORY_SEXUALLY_EXPLICIT", "BLOCK_MEDIUM_AND_ABOVE"),
        SafetySetting("HARM_CATEGORY_DANGEROUS_CONTENT", "BLOCK_MEDIUM_AND_ABOVE")
    )

    private fun err(body: String): String? = try {
        json.decodeFromString(GeminiErrorEnvelope.serializer(), body).error?.message
    } catch (_: Throwable) { body.take(160) }

    private fun computeBackoff(attempt: Int): Long {
        val exp = BASE_BACKOFF_MS * 2.0.pow((attempt - 1).toDouble())
        val capped = min(exp, MAX_BACKOFF_MS.toDouble())
        return (capped * (0.5 + Math.random() * 0.5)).toLong().coerceAtLeast(150L)
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { if (cont.isActive) cont.resumeWithException(e) }
            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }
        })
        cont.invokeOnCancellation { runCatching { cancel() } }
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"
        private const val MODEL_ID = "gemini-1.5-flash"
        private const val CONNECT_TIMEOUT_SECONDS = 6L
        private const val WRITE_TIMEOUT_SECONDS = 6L
        private const val READ_TIMEOUT_SECONDS = 10L
        private const val CALL_TIMEOUT_SECONDS = 14L
        private const val MAX_RETRIES = 2
        private const val BASE_BACKOFF_MS = 400L
        private const val MAX_BACKOFF_MS = 2_500L
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

        val SYSTEM_INSTRUCTION: String = """
You are Aegis — a Jarvis-grade personal OS assistant embedded in the user's Android phone. You are calm, precise, and proactive, and you speak directly into the user's earbuds.

VOICE OUTPUT RULES (mandatory):
- Reply in at most 1–2 short spoken sentences. Never longer.
- Never use markdown, bullet points, numbered lists, emojis, or code fences.
- Match the user's language: Hindi or Hinglish in → Hindi or Hinglish out.
- If a request cannot be fulfilled, say so briefly and suggest one concrete alternative.

DEVICE ACTION PROTOCOL:
When the user's request requires a device action you should perform rather than describe, respond with EXACTLY one JSON object and nothing else:
  {"action": "<ACTION_NAME>", "params": { ... }}

Supported ACTION_NAME values:
  TORCH_ON, TORCH_OFF, TORCH_TOGGLE,
  VOLUME_SET {"stream":"MEDIA|CALL|RING|ALARM|NOTIFICATION","percent":0-100},
  VOLUME_UP, VOLUME_DOWN, VOLUME_MUTE,
  BLUETOOTH_ON, BLUETOOTH_OFF, BLUETOOTH_TOGGLE,
  WIFI_ON, WIFI_OFF, WIFI_TOGGLE,
  GO_HOME, GO_BACK, SHOW_RECENTS, SHOW_NOTIFICATIONS, LOCK_SCREEN,
  SEND_WHATSAPP {"recipient":"<name>","message":"<text>"}

If the user is asking a question or making conversation, respond with plain spoken text, NOT JSON.

The [REMEMBERED_USER_CONTEXT] block, when present, contains facts the user has explicitly asked you to remember. Use them naturally.
        """.trimIndent()

        val VISION_SYSTEM_INSTRUCTION: String = """
You are Aegis, describing the user's screen into their earbuds.
- Answer the user's specific question in at most 1–2 short spoken sentences.
- No markdown, no lists, no emojis.
- Match the user's language.
- NEVER read passwords, OTP codes, PINs, card numbers, or full phone numbers.
        """.trimIndent()

        val REAL_WORLD_SYSTEM_INSTRUCTION: String = """
You are Aegis, describing what the camera sees directly into the user's earbuds.
- Answer the user's specific question in at most 1–2 short spoken sentences.
- No markdown, no lists, no emojis.
- Match the user's language.
- NEVER read card numbers, OTP codes, PINs, ID numbers, or medical records.
- Do not speculate about people's identity, mood, age, gender, or ethnicity.
        """.trimIndent()
    }
}

sealed class GeminiResult {
    data class Success(val text: String) : GeminiResult()
    data class Retryable(val reason: GeminiResult) : GeminiResult()
    data object Offline : GeminiResult()
    data object NoApiKey : GeminiResult()
    data class Unauthorized(val message: String) : GeminiResult()
    data class Forbidden(val message: String) : GeminiResult()
    data class BadRequest(val message: String) : GeminiResult()
    data class SafetyBlocked(val reason: String) : GeminiResult()
    data class UnknownError(val message: String?) : GeminiResult()
}
