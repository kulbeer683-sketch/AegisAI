package com.aegis.ai.memory.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey @ColumnInfo(name = "id") val id: Int = SINGLETON_ID,
    @ColumnInfo(name = "preferred_name") val preferredName: String? = null,
    @ColumnInfo(name = "language_preference") val languagePreference: String? = null,
    @ColumnInfo(name = "emergency_contact_name") val emergencyContactName: String? = null,
    @ColumnInfo(name = "emergency_contact_number") val emergencyContactNumber: String? = null,
    @ColumnInfo(name = "home_zone_tag") val homeZoneTag: String? = null,
    @ColumnInfo(name = "work_zone_tag") val workZoneTag: String? = null,
    @ColumnInfo(name = "created_at_ms") val createdAtMs: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at_ms") val updatedAtMs: Long = System.currentTimeMillis()
) { companion object { const val SINGLETON_ID = 1 } }
