package com.aegis.ai.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aegis.ai.dashboard.theme.AegisPalette

@Composable
fun PrivacyCard(
    state: DashboardState,
    onCloud: (Boolean) -> Unit,
    onScreen: (Boolean) -> Unit,
    onCamera: (Boolean) -> Unit,
    onLocation: (Boolean) -> Unit,
    onRequestWipe: () -> Unit
) {
    AegisSectionCard {
        AegisSectionHeader("PRIVACY & SECURITY", "Capability controls and memory management")
        CapToggle(Icons.Filled.Cloud, "Cloud Reasoning", "Route complex queries to Gemini 1.5 Flash", state.privacyCloudEnabled, onCloud)
        CapToggle(Icons.Filled.ScreenShare, "Screen Vision", "Read what is on your screen", state.privacyScreenVisionEnabled, onScreen)
        CapToggle(Icons.Filled.PhotoCamera, "Camera Vision", "Describe what the camera sees", state.privacyCameraVisionEnabled, onCamera)
        CapToggle(Icons.Filled.LocationOn, "Location Routines", "Home / work zone triggers", state.privacyLocationRoutinesEnabled, onLocation)
        Spacer(Modifier.height(12.dp))
        DangerZone(onRequestWipe)
    }
}

@Composable
private fun CapToggle(icon: ImageVector, title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = if (checked) AegisPalette.Accent else AegisPalette.TextTertiary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = AegisPalette.TextPrimary)
            Text(desc, style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
        }
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = AegisPalette.Black, checkedTrackColor = AegisPalette.Accent, uncheckedThumbColor = AegisPalette.TextSecondary, uncheckedTrackColor = AegisPalette.SurfaceElevated))
    }
}

@Composable
private fun DangerZone(onRequestWipe: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(AegisPalette.Danger.copy(alpha = 0.08f)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = AegisPalette.Danger, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Wipe all memory", style = MaterialTheme.typography.bodyLarge, color = AegisPalette.Danger, fontWeight = FontWeight.SemiBold)
                Text("Erases stored facts, conversation history, and rotates encryption keys.", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = { show = true }, colors = ButtonDefaults.buttonColors(containerColor = AegisPalette.Danger, contentColor = AegisPalette.Black)) { Text("Wipe memory") }
    }
    if (show) {
        AlertDialog(
            onDismissRequest = { show = false }, containerColor = AegisPalette.SurfaceElevated,
            title = { Text("Wipe all memory?", style = MaterialTheme.typography.titleLarge, color = AegisPalette.Danger) },
            text = { Column {
                Text("This will permanently delete:", style = MaterialTheme.typography.bodyLarge, color = AegisPalette.TextPrimary)
                Spacer(Modifier.height(6.dp))
                Text("• Every fact you have taught Aegis\n• Every conversation turn\n• The Gemini API key\n• All encryption keys", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.TextSecondary)
                Spacer(Modifier.height(10.dp))
                Text("The data cannot be recovered. Your permission choices, routines, and voice settings are preserved.", style = MaterialTheme.typography.bodyMedium, color = AegisPalette.Warning)
            } },
            confirmButton = { TextButton(onClick = { show = false; onRequestWipe() }) { Text("Wipe", color = AegisPalette.Danger, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel", color = AegisPalette.TextSecondary) } }
        )
    }
}
