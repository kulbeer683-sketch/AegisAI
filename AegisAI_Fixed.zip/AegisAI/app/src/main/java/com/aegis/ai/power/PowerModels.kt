package com.aegis.ai.power

enum class ThrottleTier {
    NORMAL, THROTTLED, CRITICAL;
    fun isAtLeast(other: ThrottleTier) = this.ordinal >= other.ordinal
}

data class ThrottleTransition(
    val previous: ThrottleTier,
    val current: ThrottleTier,
    val reason: String,
    val temperatureC: Float,
    val batteryPercent: Int,
    val timestampMs: Long
) {
    val isEscalation: Boolean get() = current.ordinal > previous.ordinal
    val isRelaxation: Boolean get() = current.ordinal < previous.ordinal
}

data class PowerPosture(
    val tier: ThrottleTier,
    val temperatureC: Float,
    val batteryPercent: Int,
    val charging: Boolean,
    val activeWakeLocks: Int,
    val releasedLeaks: Long,
    val lastTransition: ThrottleTransition?
)

internal data class WakeLockRecord(
    val id: Long, val tag: String, val acquiredAtMs: Long,
    val timeoutMs: Long, val owner: String
) {
    fun ageMs(now: Long) = now - acquiredAtMs
    fun isExpired(now: Long) = ageMs(now) > timeoutMs
    fun isOrphaned(now: Long, orphan: Long) = ageMs(now) > orphan
}

data class LeakRelease(val tag: String, val owner: String, val heldMs: Long, val forced: Boolean)
