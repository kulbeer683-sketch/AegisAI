package com.aegis.ai.privacy

sealed class WipeOutcome {
    data class Success(val elapsedMs: Long) : WipeOutcome()
    data class Partial(val elapsedMs: Long, val errors: List<String>) : WipeOutcome()
    data object Cancelled : WipeOutcome()
    data object NoPendingRequest : WipeOutcome()
}
