package com.aegis.ai.memory.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.aegis.ai.memory.entity.ActionFrequencyEntity

@Dao
interface ActionFrequencyDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(entity: ActionFrequencyEntity): Long

    @Query("UPDATE action_frequency SET count = count + 1, last_invoked_at_ms = :nowMs WHERE action_type = :type AND target = :target")
    suspend fun bump(type: String, target: String, nowMs: Long): Int

    @Query("SELECT * FROM action_frequency WHERE action_type = :type ORDER BY count DESC, last_invoked_at_ms DESC LIMIT :limit")
    suspend fun topForType(type: String, limit: Int): List<ActionFrequencyEntity>

    @Query("DELETE FROM action_frequency")
    suspend fun clear()
}
