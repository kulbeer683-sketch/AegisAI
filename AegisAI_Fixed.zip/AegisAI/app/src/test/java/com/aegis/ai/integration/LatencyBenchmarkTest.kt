package com.aegis.ai.integration

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream
import com.aegis.ai.intent.IntentGrammar
import com.aegis.ai.pipeline.ActionClassifier
import org.junit.Assert.assertTrue
import org.junit.Test

class LatencyBenchmarkTest {

    private fun report(name: String, s: List<Double>) {
        val sorted = s.sorted()
        val p50 = sorted[sorted.size / 2]
        val p95 = sorted[(sorted.size * 95) / 100]
        println("[latency] %-40s p50=%7.3fms p95=%7.3fms n=%d".format(name, p50, p95, sorted.size))
    }

    @Test fun `single utterance grammar parse under 5ms p95`() {
        repeat(50) { IntentGrammar.parse("torch on") }
        val s = (1..500).map {
            val t0 = System.nanoTime(); IntentGrammar.parse("torch on"); (System.nanoTime() - t0) / 1_000_000.0
        }
        report("grammar.parse(single)", s)
        assertTrue(s.sorted()[(s.size * 95) / 100] < 5.0)
    }

    @Test fun `action classifier under 2ms p95`() {
        val acts = listOf(AegisAction.TorchOn, AegisAction.WifiOff, AegisAction.BluetoothOn, AegisAction.SetDnd(true), AegisAction.VolumeSet(AudioStream.MEDIA, 50))
        repeat(50) { acts.forEach { ActionClassifier.classify(it) } }
        val s = (1..500).map {
            val t0 = System.nanoTime(); acts.forEach { ActionClassifier.classify(it) }; (System.nanoTime() - t0) / 1_000_000.0
        }
        report("action_classifier.classify(5)", s)
        assertTrue(s.sorted()[(s.size * 95) / 100] < 2.0)
    }
}
