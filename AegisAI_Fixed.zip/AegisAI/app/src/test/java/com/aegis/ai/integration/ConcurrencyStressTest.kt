package com.aegis.ai.integration

import com.aegis.ai.pipeline.CompoundIntentParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConcurrencyStressTest {

    @Test fun `1000 compound parses without crashing`() {
        val p = CompoundIntentParser()
        val inputs = listOf(
            "torch on and volume 50",
            "टॉर्च जलाओ और वॉल्यूम 70 करो",
            "wifi off then bluetooth on",
            "dnd on, next song, go home",
            "single command",
            ""
        )
        repeat(1000) { i ->
            val s = p.parse(inputs[i % inputs.size])
            assertTrue(s.size >= 0)
        }
    }
}
