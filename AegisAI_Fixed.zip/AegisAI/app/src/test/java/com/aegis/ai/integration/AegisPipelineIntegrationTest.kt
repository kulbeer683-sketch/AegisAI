package com.aegis.ai.integration

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream
import com.aegis.ai.intent.IntentGrammar
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.pipeline.ActionClassifier
import com.aegis.ai.pipeline.CompoundIntentParser
import com.aegis.ai.pipeline.ExecutionMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AegisPipelineIntegrationTest {

    @Test fun `fast path grammar resolves common commands`() {
        val cases = listOf(
            "torch on" to AegisAction.TorchOn,
            "volume 50" to AegisAction.VolumeSet(AudioStream.MEDIA, 50),
            "wifi off" to AegisAction.WifiOff,
            "bluetooth on" to AegisAction.BluetoothOn,
            "dnd on" to AegisAction.SetDnd(true),
            "go home" to AegisAction.GoHome,
            "टॉर्च जलाओ" to AegisAction.TorchOn,
            "awaz kam karo" to AegisAction.VolumeAdjust(AudioStream.MEDIA, AegisAction.Direction.DOWN)
        )
        for ((u, e) in cases) {
            val m = IntentGrammar.parse(u)
            assertEquals("Mismatch for '$u'", e, m.actions.first())
            assertTrue("Should be fast path for '$u'", m.actions.first().isFastPath())
        }
    }

    @Test fun `action classifier is consistent`() {
        val fast = listOf(
            AegisAction.TorchOn, AegisAction.WifiOff, AegisAction.BluetoothOn,
            AegisAction.SetDnd(true), AegisAction.VolumeSet(AudioStream.MEDIA, 50),
            AegisAction.SystemDiagnostics, AegisAction.QueryPowerStatus
        )
        for (a in fast) assertEquals(ExecutionMode.CONCURRENT_FAST, ActionClassifier.classify(a))
    }

    @Test fun `compound parser splits Hindi Hinglish`() {
        val p = CompoundIntentParser()
        val acts = p.parseToActions("टॉर्च जलाओ और वॉल्यूम 70 करो")
        assertEquals(2, acts.size)
        assertTrue(acts[0] is AegisAction.TorchOn)
        assertTrue(acts[1] is AegisAction.VolumeSet)
    }

    @Test fun `compound parser handles parallel English`() {
        val p = CompoundIntentParser()
        val s = p.parse("torch on and volume 50 and wifi off")
        assertEquals(3, s.size)
        assertTrue(s.none { it.dependsOnPrevious })
    }

    @Test fun `compound parser word boundary`() {
        val p = CompoundIntentParser()
        val s = p.parse("open android settings")
        assertEquals(1, s.size)
    }
}
