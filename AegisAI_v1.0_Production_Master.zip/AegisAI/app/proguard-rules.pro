-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*, InnerClasses, Signature

-keep class kotlin.Metadata { *; }
-keepclassmembers class **$WhenMappings { <fields>; }

-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
-dontwarn kotlinx.coroutines.**

-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.aegis.ai.**$$serializer { *; }
-keepclassmembers class com.aegis.ai.** { *** Companion; }

-keep class * extends androidx.room.RoomDatabase { <init>(); }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao class * { *; }
-keep @androidx.room.Database class * { *; }

-keep class net.zetetic.database.** { *; }
-dontwarn net.zetetic.**

-keep class androidx.security.crypto.** { *; }
-dontwarn androidx.security.**

-keep class androidx.compose.runtime.** { *; }
-keep class androidx.compose.ui.** { *; }
-dontwarn androidx.compose.**

-dontwarn okhttp3.**
-dontwarn okio.**

-keep class com.aegis.ai.** { *; }
-dontwarn com.aegis.ai.**
