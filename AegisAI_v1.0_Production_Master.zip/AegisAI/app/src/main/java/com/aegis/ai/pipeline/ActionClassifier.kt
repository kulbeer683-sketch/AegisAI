package com.aegis.ai.pipeline

import com.aegis.ai.intent.AegisAction

object ActionClassifier {

    fun classify(action: AegisAction): ExecutionMode = when (action) {
        AegisAction.TorchOn, AegisAction.TorchOff, AegisAction.TorchToggle -> ExecutionMode.CONCURRENT_FAST
        is AegisAction.VolumeSet, is AegisAction.VolumeAdjust, is AegisAction.VolumeMute -> ExecutionMode.CONCURRENT_FAST
        AegisAction.WifiOn, AegisAction.WifiOff, AegisAction.WifiToggle -> ExecutionMode.CONCURRENT_FAST
        AegisAction.BluetoothOn, AegisAction.BluetoothOff, AegisAction.BluetoothToggle -> ExecutionMode.CONCURRENT_FAST
        is AegisAction.QueryVitals -> ExecutionMode.CONCURRENT_FAST
        is AegisAction.SetDnd, is AegisAction.SetAutoRotation, is AegisAction.SetScreenTimeout -> ExecutionMode.CONCURRENT_FAST
        is AegisAction.SystemDiagnostics -> ExecutionMode.CONCURRENT_FAST
        is AegisAction.QueryPowerStatus -> ExecutionMode.CONCURRENT_FAST
        is AegisAction.QueryLocation -> ExecutionMode.CONCURRENT_FAST
        else -> ExecutionMode.SEQUENTIAL_UI
    }
}
