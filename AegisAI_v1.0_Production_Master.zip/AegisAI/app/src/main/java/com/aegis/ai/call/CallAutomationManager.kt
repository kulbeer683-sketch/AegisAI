package com.aegis.ai.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioRouteHelper
import com.aegis.ai.hardware.ControllerResult
import com.aegis.ai.service.AegisInCallService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

class CallAutomationManager(
    context: Context,
    private val scope: CoroutineScope
) : AutoCloseable {

    private val appContext = context.applicationContext
    private val telephonyManager = appContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val telecomManager = appContext.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val callbackExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "aegis-telephony").apply { isDaemon = true }
    }

    private val _state = MutableStateFlow<CallState>(CallState.Idle)
    val state: StateFlow<CallState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<CallEvent>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<CallEvent> = _events.asSharedFlow()

    @Volatile private var lastNumber: String? = null
    @Volatile private var lastContactName: String? = null
    @Volatile private var registered = false
    private var contactLookupJob: Job? = null
    private var announcementJob: Job? = null

    private val modernCallback: TelephonyCallback? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) object : TelephonyCallback(), TelephonyCallback.CallStateListener {
            override fun onCallStateChanged(state: Int) { dispatchState(state, null) }
        } else null

    @Suppress("DEPRECATION")
    private val legacyListener: PhoneStateListener? =
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) object : PhoneStateListener() {
            override fun onCallStateChanged(state: Int, phoneNumber: String?) { dispatchState(state, phoneNumber) }
        } else null

    fun start() {
        if (registered) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modernCallback?.let { telephonyManager.registerTelephonyCallback(callbackExecutor, it) }
            } else {
                @Suppress("DEPRECATION")
                telephonyManager.listen(legacyListener, PhoneStateListener.LISTEN_CALL_STATE)
            }
            registered = true
        } catch (t: Throwable) { Log.e(TAG, "register callback failed", t) }
    }

    fun stop() {
        if (!registered) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modernCallback?.let { telephonyManager.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                telephonyManager.listen(legacyListener, PhoneStateListener.LISTEN_NONE)
            }
        } catch (_: Throwable) {} finally {
            registered = false
            contactLookupJob?.cancel()
            announcementJob?.cancel()
        }
    }

    override fun close() { stop(); callbackExecutor.shutdownNow() }

    suspend fun answerCall(): ControllerResult = withContext(Dispatchers.Main.immediate) {
        if (!hasAnswerPermission()) return@withContext ControllerResult.Failure("ANSWER_PHONE_CALLS not granted")
        if (_state.value !is CallState.Ringing) return@withContext ControllerResult.Failure("No ringing call")

        val result: ControllerResult = if (AegisInCallService.answerCurrentCall()) {
            ControllerResult.Success("Call answered")
        } else {
            try {
                @Suppress("DEPRECATION")
                telecomManager.acceptRingingCall()
                ControllerResult.Success("Call answered")
            } catch (e: SecurityException) { ControllerResult.Failure("SecurityException: ${e.message}") }
            catch (t: Throwable) { ControllerResult.Failure(t.message ?: "answer failed") }
        }
        if (result is ControllerResult.Success) applyHandsFreeRouting()
        result
    }

    suspend fun rejectCall(): ControllerResult = withContext(Dispatchers.Main.immediate) {
        if (!hasAnswerPermission()) return@withContext ControllerResult.Failure("ANSWER_PHONE_CALLS not granted")
        if (_state.value !is CallState.Ringing) return@withContext ControllerResult.Failure("No ringing call")

        if (AegisInCallService.rejectCurrentCall()) {
            _events.tryEmit(CallEvent.Rejected)
            return@withContext ControllerResult.Success("Call rejected")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                if (telecomManager.endCall()) {
                    _events.tryEmit(CallEvent.Rejected)
                    return@withContext ControllerResult.Success("Call rejected")
                }
            } catch (_: Throwable) {}
        }
        try {
            @Suppress("DEPRECATION") telecomManager.silenceRinger()
            _events.tryEmit(CallEvent.Rejected)
            ControllerResult.Success("Ringer silenced")
        } catch (t: Throwable) { ControllerResult.Failure("reject failed") }
    }

    private fun applyHandsFreeRouting() {
        runCatching {
            val hasHeadset = AudioRouteHelper.hasHeadsetConnected(audioManager)
            if (!hasHeadset) AudioRouteHelper.enableSpeakerphone(audioManager)
        }
    }

    private fun dispatchState(state: Int, number: String?) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> onRinging(number)
            TelephonyManager.CALL_STATE_OFFHOOK -> onOffHook()
            TelephonyManager.CALL_STATE_IDLE -> onIdle()
        }
    }

    private fun onRinging(rawNumber: String?) {
        val number = rawNumber?.takeIf { it.isNotBlank() } ?: AegisInCallService.currentCallNumber()
        lastNumber = number; lastContactName = null
        _state.value = CallState.Ringing(number, null)
        _events.tryEmit(CallEvent.IncomingStarted(number))

        contactLookupJob?.cancel()
        contactLookupJob = scope.launch {
            val name = number?.let { lookupContactName(it) }
            if (name != null && _state.value is CallState.Ringing) {
                val cur = _state.value as CallState.Ringing
                if (cur.number == number) {
                    lastContactName = name
                    _state.value = cur.copy(contactName = name)
                }
            }
        }

        announcementJob?.cancel()
        announcementJob = scope.launch {
            var waited = 0L
            while (waited < 450L && lastContactName == null && _state.value is CallState.Ringing && lastNumber == number) {
                delay(50L); waited += 50L
            }
            val cur = _state.value
            if (cur is CallState.Ringing && cur.number == number) {
                _events.tryEmit(CallEvent.IncomingAnnouncementReady(cur.displayIdentity(), cur.number))
            }
        }
    }

    private fun onOffHook() {
        contactLookupJob?.cancel(); announcementJob?.cancel()
        _state.value = CallState.OffHook(lastNumber, lastContactName)
        _events.tryEmit(CallEvent.Answered)
    }

    private fun onIdle() {
        contactLookupJob?.cancel(); announcementJob?.cancel()
        runCatching { AudioRouteHelper.disableSpeakerphone(audioManager) }
        val had = _state.value !is CallState.Idle
        lastNumber = null; lastContactName = null
        _state.value = CallState.Idle
        if (had) _events.tryEmit(CallEvent.Ended)
    }

    private suspend fun lookupContactName(number: String): String? = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return@withContext null
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        try {
            appContext.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                    if (i >= 0) return@withContext c.getString(i)
                }
            }
        } catch (t: Throwable) { Log.e(TAG, "contact lookup failed", t) }
        null
    }

    private fun hasAnswerPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED

    companion object { private const val TAG = AudioConfig.TAG }
}
