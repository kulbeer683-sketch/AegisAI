package com.aegis.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aegis.ai.service.AegisForegroundService

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AegisTheme { AegisDashboard() } }
    }
}

private val Accent = Color(0xFF2FE6A8)
private val Bg = Color(0xFF000000)
private val Surface = Color(0xFF0A0D12)
private val TextPrimary = Color(0xFFE7EEF5)
private val TextSecondary = Color(0xFF8A9AAB)

@Composable
private fun AegisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Surface,
            onPrimary = Color.Black,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        )
    ) { Surface(modifier = Modifier.fillMaxSize(), color = Bg) { content() } }
}

@Composable
private fun AegisDashboard() {
    val ctx = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "AEGIS AI",
            color = Accent,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 34.sp,
            letterSpacing = 8.sp
        )
        Text(
            "Phase 1 — Audio Pipeline & Core Intent Router",
            color = TextSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        )

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                ContextCompat.startForegroundService(
                    ctx,
                    AegisForegroundService.startIntent(ctx, preferBluetoothSco = true)
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Start Aegis", fontWeight = FontWeight.SemiBold) }

        Button(
            onClick = {
                ctx.startService(AegisForegroundService.stopIntent(ctx))
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF131A22), contentColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Stop Aegis") }

        Spacer(Modifier.height(8.dp))

        Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Text Command Test", color = Accent, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Use adb: am start-foreground-service -n com.aegis.ai/.service.AegisForegroundService -a com.aegis.ai.action.TEXT --es com.aegis.ai.extra.TEXT \"torch on\"",
                    color = TextSecondary, fontSize = 12.sp
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        Text(
            "AEGIS · PART 1 OF N · DAYS 1–30 SCAFFOLD",
            color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp
        )
    }
}
