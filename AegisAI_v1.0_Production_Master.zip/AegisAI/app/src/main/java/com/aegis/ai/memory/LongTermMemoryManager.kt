package com.aegis.ai.memory

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class UserProfileEntity(
    val id: Int = 1,
    val preferredName: String? = null,
    val languagePreference: String? = null,
    val emergencyContactName: String? = null,
    val emergencyContactNumber: String? = null,
    val homeZoneTag: String? = null,
    val workZoneTag: String? = null,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
) { companion object { const val SINGLETON_ID = 1 } }

data class KnowledgeMemoryEntity(
    val id: Long = 0L, val key: String, val displayKey: String, val value: String,
    val category: String = "general", val sourceUtterance: String? = null,
    val createdAtMs: Long = System.currentTimeMillis(), val updatedAtMs: Long = System.currentTimeMillis(),
    val hitCount: Long = 0L
)

class LongTermMemoryManager(
    private val database: Any? = null,
    private val scope: CoroutineScope
) {
    private val writeMutex = Mutex()
    private val factCache = ConcurrentHashMap<String, KnowledgeMemoryEntity>()
    @Volatile private var profileCache = UserProfileEntity()
    @Volatile private var cacheLoaded = false

    init { scope.launch { withContext(Dispatchers.IO) { cacheLoaded = true } } }

    suspend fun rememberFact(key: String, displayKey: String, value: String, sourceUtterance: String? = null): Boolean {
        val n = normalize(key)
        if (n.isBlank() || value.isBlank()) return false
        val now = System.currentTimeMillis()
        val prev = factCache[n]
        val e = KnowledgeMemoryEntity(
            id = prev?.id ?: 0L, key = n, displayKey = displayKey.trim().take(160),
            value = value.trim().take(400), category = infer(n),
            sourceUtterance = sourceUtterance?.take(400),
            createdAtMs = prev?.createdAtMs ?: now, updatedAtMs = now, hitCount = prev?.hitCount ?: 0L
        )
        return writeMutex.withLock { factCache[n] = e; true }
    }

    suspend fun forgetFacts(pattern: String): Int {
        val n = normalize(pattern)
        if (n.isBlank()) return 0
        return writeMutex.withLock {
            var c = 0
            val it = factCache.entries.iterator()
            while (it.hasNext()) { if (it.next().key.contains(n)) { it.remove(); c++ } }
            c
        }
    }

    fun getFactValue(key: String): String? = factCache[normalize(key)]?.value
    fun getFact(key: String): KnowledgeMemoryEntity? = factCache[normalize(key)]
    fun allFacts(): List<KnowledgeMemoryEntity> = factCache.values.sortedByDescending { it.updatedAtMs }
    fun factCount(): Int = factCache.size
    fun getProfile(): UserProfileEntity = profileCache

    suspend fun updatePreferredName(name: String): Boolean {
        val c = name.trim().take(80); if (c.isBlank()) return false
        return updateProfile { it.copy(preferredName = c) }
    }

    suspend fun updateLanguagePreference(tag: String?): Boolean = updateProfile { it.copy(languagePreference = tag?.take(16)) }

    private suspend fun updateProfile(t: (UserProfileEntity) -> UserProfileEntity): Boolean = writeMutex.withLock {
        profileCache = t(profileCache).copy(id = 1, updatedAtMs = System.currentTimeMillis()); true
    }

    fun buildMemoryBlock(): String? {
        val p = profileCache
        val facts = allFacts().sortedWith(compareByDescending<KnowledgeMemoryEntity> { it.hitCount }.thenByDescending { it.updatedAtMs }).take(PROMPT_FACT_LIMIT)
        if (p.preferredName == null && p.languagePreference == null && facts.isEmpty()) return null
        return buildString {
            append("[REMEMBERED_USER_CONTEXT]\n")
            p.preferredName?.let { append("preferred_name: ").append(it).append('\n') }
            p.languagePreference?.let { append("language_preference: ").append(it).append('\n') }
            if (facts.isNotEmpty()) {
                append("known_facts:\n")
                for (f in facts) append("- ").append(f.displayKey).append(" = ").append(f.value).append('\n')
            }
        }.trim().take(PROMPT_BLOCK_MAX_CHARS)
    }

    suspend fun wipe() = writeMutex.withLock { factCache.clear(); profileCache = UserProfileEntity() }

    private fun normalize(r: String) = r.trim().lowercase().replace(Regex("\\s+"), " ")

    private fun infer(key: String): String {
        val l = key.lowercase()
        return when {
            listOf("car", "bike", "vehicle", "parking", "gaadi", "गाड़ी").any { l.contains(it) } -> "vehicle"
            listOf("wifi", "password", "pin", "otp").any { l.contains(it) } -> "credentials"
            listOf("home", "ghar", "घर").any { l.contains(it) } -> "home"
            listOf("work", "office").any { l.contains(it) } -> "work"
            else -> "general"
        }
    }

    private companion object {
        const val TAG = AudioConfig.TAG
        const val PROMPT_FACT_LIMIT = 12
        const val PROMPT_BLOCK_MAX_CHARS = 900
    }
}
