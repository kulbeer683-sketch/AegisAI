package com.aegis.ai.pipeline

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.ActionExecutor
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.recovery.RecoveryRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicReference

class WorkflowPipelineCoordinator(
    private val scope: CoroutineScope,
    private val executor: ActionExecutor,
    private val inEar: InEarNotificationManager?,
    private val compoundParser: CompoundIntentParser = CompoundIntentParser()
) {

    private val mutex = Mutex()
    private val activeJob = AtomicReference<Job?>(null)

    init { RecoveryRegistry.register(RECOVERY_KEY) { activeJob.get()?.cancel(CancellationException("watchdog force-abort")) } }

    suspend fun executeWorkflow(
        actions: List<AegisAction>,
        language: IntentMatch.Language = IntentMatch.Language.ENGLISH,
        rawText: String? = null,
        voicePrefix: String? = null
    ): WorkflowOutcome = mutex.withLock {
        val t0 = SystemClock.elapsedRealtime()
        activeJob.set(scope.coroutineContext[Job])
        try {
            val tasks = actions.mapIndexed { i, a -> WorkflowTask(i, a, ActionClassifier.classify(a)) }
            val strict = rawText?.let { compoundParser.parse(it).any { s -> s.dependsOnPrevious } } ?: false
            val results = if (strict) runSequential(tasks) else runParallelAware(tasks)
            val total = SystemClock.elapsedRealtime() - t0
            val fast = results.filter { it.task.mode == ExecutionMode.CONCURRENT_FAST }.maxOfOrNull { it.elapsedMs } ?: 0L
            val synth = FeedbackSynthesizer.synthesize(results, language)
            val reply = buildString {
                val p = voicePrefix?.trim()
                if (!p.isNullOrEmpty()) { append(p); if (synth.isNotBlank()) { append(". "); append(synth) } }
                else append(synth)
            }
            if (reply.isNotBlank()) runCatching { inEar?.speak(reply) }
            WorkflowOutcome(tasks, results, total, fast, reply)
        } finally { activeJob.set(null) }
    }

    fun forceAbort(reason: String = "manual") { activeJob.get()?.cancel(CancellationException("force-abort: $reason")) }

    private suspend fun runParallelAware(tasks: List<WorkflowTask>): List<SubActionOutcome> = coroutineScope {
        val fast = tasks.filter { it.mode == ExecutionMode.CONCURRENT_FAST }
        val ui = tasks.filter { it.mode == ExecutionMode.SEQUENTIAL_UI }
        val fd = if (fast.isNotEmpty()) async(Dispatchers.Default) { fast.map { async(Dispatchers.Default) { execOne(it) } }.awaitAll() } else null
        val ud = if (ui.isNotEmpty()) async(Dispatchers.Default) { ui.map { execOne(it) } } else null
        val fr = fd?.await() ?: emptyList(); val ur = ud?.await() ?: emptyList()
        (fr + ur).sortedBy { it.task.index }
    }

    private suspend fun runSequential(tasks: List<WorkflowTask>): List<SubActionOutcome> {
        val out = ArrayList<SubActionOutcome>(tasks.size)
        for (t in tasks) out += execOne(t)
        return out
    }

    private suspend fun execOne(task: WorkflowTask): SubActionOutcome {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            val o = executor.execute(task.action, suppressAnnouncement = true)
            SubActionOutcome(task, o.success, o.message, o.elapsedMs)
        } catch (ce: CancellationException) { throw ce }
        catch (t: Throwable) { SubActionOutcome(task, false, t.message ?: "threw", SystemClock.elapsedRealtime() - t0, t) }
    }

    private companion object {
        const val TAG = AudioConfig.TAG
        const val RECOVERY_KEY = "workflow_pipeline_coordinator"
    }
}
