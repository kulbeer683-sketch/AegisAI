package com.aegis.ai.privacy

import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.conversation.ConversationContextManager
import com.aegis.ai.memory.AegisMemoryDatabase
import com.aegis.ai.memory.LongTermMemoryManager
import com.aegis.ai.memory.MemoryDatabaseKeyProvider
import com.aegis.ai.security.KeystoreRotationManager
import com.aegis.ai.security.SecureKeyStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class MemoryWipeManager(
    context: Context,
    private val memoryManager: LongTermMemoryManager,
    private val contextManager: ConversationContextManager,
    private val auditLog: PrivacyAuditLog
) {

    private val appContext = context.applicationContext
    private val keystore = KeystoreRotationManager(appContext)
    private val secureKeys = SecureKeyStorage(appContext)
    private val keyProvider = MemoryDatabaseKeyProvider(appContext)
    private val mutex = Mutex()

    @Volatile private var pendingAt = 0L

    fun requestConfirmation(): Boolean {
        val now = SystemClock.elapsedRealtime()
        val e = pendingAt
        if (e > 0L && now - e < TTL) return false
        pendingAt = now; return true
    }

    fun isConfirmationPending(): Boolean {
        val at = pendingAt
        if (at == 0L) return false
        if (SystemClock.elapsedRealtime() - at > TTL) { pendingAt = 0L; return false }
        return true
    }

    suspend fun handleConfirmationResponse(text: String): WipeOutcome {
        if (!isConfirmationPending()) return WipeOutcome.NoPendingRequest
        val n = text.trim().lowercase()
        val isYes = YES.any { n == it || n.startsWith("$it ") }
        val isNo = NO.any { n == it || n.startsWith("$it ") }
        if (isNo) { pendingAt = 0L; return WipeOutcome.Cancelled }
        if (!isYes) { pendingAt = 0L; return WipeOutcome.Cancelled }
        pendingAt = 0L
        return executeConfirmedWipe()
    }

    fun cancelPending() { pendingAt = 0L }

    private suspend fun executeConfirmedWipe(): WipeOutcome = mutex.withLock {
        val started = SystemClock.elapsedRealtime()
        Log.w(TAG, "== NUCLEAR WIPE INITIATED ==")
        val errors = mutableListOf<String>()

        runCatching { withContext(Dispatchers.IO) { memoryManager.wipe(); contextManager.clear() } }
            .onFailure { errors += "caches: ${it.message}" }

        runCatching { withContext(Dispatchers.IO) { AegisMemoryDatabase.close() } }
            .onFailure { errors += "db-close: ${it.message}" }

        runCatching {
            withContext(Dispatchers.IO) {
                val db = appContext.getDatabasePath("aegis_memory.db")
                if (db.exists() && db.delete()) Log.i(TAG, "db file deleted")
                listOf("-journal", "-wal", "-shm").forEach { s -> java.io.File(db.absolutePath + s).takeIf { it.exists() }?.delete() }
            }
        }.onFailure { errors += "db-file: ${it.message}" }

        runCatching { secureKeys.clearGeminiApiKey() }.onFailure { errors += "gemini: ${it.message}" }
        runCatching { keystore.rotateAll() }.onFailure { errors += "keystore: ${it.message}" }
        runCatching { keyProvider.clearPassphrase() }.onFailure { errors += "passphrase: ${it.message}" }

        runCatching { auditLog.record(PrivacyAuditLog.Kind.WIPE, if (errors.isEmpty()) "complete" else "partial") }

        val elapsed = SystemClock.elapsedRealtime() - started
        Log.w(TAG, "== WIPE COMPLETE in ${elapsed}ms errors=$errors ==")
        if (errors.isEmpty()) WipeOutcome.Success(elapsed) else WipeOutcome.Partial(elapsed, errors)
    }

    internal suspend fun forceWipe(): WipeOutcome { pendingAt = 0L; return executeConfirmedWipe() }

    companion object {
        private const val TAG = AudioConfig.TAG
        const val TTL = 12_000L
        private val YES = setOf("yes", "confirm", "do it", "haan", "han", "ha", "ok", "okay", "हाँ", "हां", "ठीक है")
        private val NO = setOf("no", "cancel", "stop", "nahi", "na", "नहीं", "ना", "मत करो")
    }
}

sealed class WipeOutcome {
    data class Success(val elapsedMs: Long) : WipeOutcome()
    data class Partial(val elapsedMs: Long, val errors: List<String>) : WipeOutcome()
    data object Cancelled : WipeOutcome()
    data object NoPendingRequest : WipeOutcome()
}
