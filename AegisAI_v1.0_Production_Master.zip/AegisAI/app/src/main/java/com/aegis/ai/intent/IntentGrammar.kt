package com.aegis.ai.intent

internal object IntentGrammar {

    private const val SPLIT = "\u0001"

    private val LATIN_CONJ = Regex("""\b(and|aur|phir|then|also)\b""")
    private val DEV_CONJ = Regex("और|फिर|तथा")
    private val PUNCT_SPLIT = Regex("""[,;+]""")
    private val NUMBER = Regex("""(\d{1,3})""")
    private val DEVANAGARI = Regex("[\\u0900-\\u097F]")
    private val LATIN = Regex("[A-Za-z]")

    private val TORCH = setOf("torch", "flashlight", "light", "lamp", "batti", "टॉर्च", "लाइट", "बत्ती")
    private val VOLUME = setOf("volume", "vol", "sound", "audio", "awaz", "aawaz", "awaaz", "वॉल्यूम", "आवाज़", "आवाज", "ध्वनि", "साउंड")
    private val WIFI = setOf("wifi", "wi", "fi", "wireless", "वाईफाई", "वाईफ़ाई", "वाई")
    private val BLUETOOTH = setOf("bluetooth", "bt", "ब्लूटूथ")
    private val LOCK = setOf("lock", "लॉक")
    private val SCREEN = setOf("screen", "display", "phone", "device", "स्क्रीन", "डिस्प्ले", "फोन")
    private val ON = setOf("on", "enable", "chalu", "chaalu", "chalao", "jalao", "jala", "start", "शुरू", "ऑन", "चालू", "जलाओ", "जला")
    private val OFF = setOf("off", "disable", "band", "bujhao", "bujha", "stop", "बंद", "ऑफ", "बुझाओ", "बुझा", "रोको")
    private val TOGGLE = setOf("toggle", "flip", "switch", "बदलो")
    private val UP = setOf("up", "increase", "raise", "louder", "tez", "badhao", "badha", "बढ़ाओ", "बढ़ा", "तेज", "ऊपर", "ज्यादा")
    private val DOWN = setOf("down", "decrease", "lower", "quieter", "kam", "ghatao", "ghata", "कम", "घटाओ", "घटा", "नीचे")
    private val MUTE = setOf("mute", "silent", "silence", "म्यूट", "साइलेंट", "चुप")
    private val UNMUTE = setOf("unmute", "अनम्यूट")
    private val CALL = setOf("call", "phone", "कॉल", "फोन")
    private val RING = setOf("ring", "ringer", "ringtone", "रिंग", "रिंगटोन")
    private val ALARM = setOf("alarm", "अलार्म")
    private val NOTIF = setOf("notification", "notifications", "नोटिफिकेशन", "सूचना")
    private val OPEN = setOf("open", "launch", "kholo", "खोलो")
    private val HOME = setOf("home", "homescreen", "launcher", "होम", "मुख्य")
    private val BACK = setOf("back", "backward", "वापस", "बैक", "पीछे")
    private val RECENTS = setOf("recents", "recent", "overview", "रीसेंट")
    private val SHOW = setOf("show", "open", "dikhao", "dikha", "kholo", "दिखाओ", "दिखा", "खोलो")
    private val GO = setOf("go", "navigate", "jao", "ja", "चलो", "जाओ", "करो", "कर", "karo", "kar")
    private val DND = setOf("dnd", "zen", "silent", "साइलेंट", "ज़ेन", "डीएनडी", "शांत")
    private val DISTURB = setOf("disturb", "interruption", "डिस्टर्ब", "परेशानी")
    private val DARK = setOf("dark", "night", "डार्क", "नाइट")
    private val LIGHT = setOf("light", "day", "bright", "लाइट", "दे", "दिन")
    private val MODE = setOf("mode", "theme", "मोड", "थीम")
    private val ROTATION = setOf("rotate", "rotation", "autorotate", "auto-rotate", "रोटेशन", "घुमाओ")
    private val TIMEOUT = setOf("timeout", "time-out", "sleep", "टाइमआउट", "स्लीप")
    private val SECONDS = setOf("second", "seconds", "sec", "सेकंड", "सेकण्ड")
    private val MINUTES = setOf("minute", "minutes", "min", "मिनट")
    private val AIRPLANE = setOf("airplane", "flight", "एयरप्लेन", "फ्लाइट")
    private val LOCATION = setOf("location", "gps", "लोकेशन", "जीपीएस", "स्थान")
    private val BATTERY = setOf("battery", "charge", "charging", "बैटरी", "चार्ज", "चार्जिंग")
    private val TEMP = setOf("temperature", "temp", "heat", "hot", "तापमान", "गर्मी", "गर्म", "टेम्परेचर")
    private val THERMAL = setOf("thermal", "थर्मल")
    private val NETWORK = setOf("network", "signal", "connectivity", "नेटवर्क", "सिग्नल")
    private val VITALS = setOf("vitals", "health", "स्वास्थ्य", "वाइटल्स")
    private val POWER = setOf("power", "energy", "drain", "पावर", "ऊर्जा", "खपत")
    private val DIAGNOSTICS = setOf("diagnostic", "diagnostics", "self", "test", "status",
        "डायग्नोस्टिक", "स्टेटस", "जाँच", "जांच")
    private val SYSTEM_OK = setOf("सब", "ठीक", "sab", "theek")

    private val HINGLISH_HINTS = setOf("karo", "kar", "chalu", "band", "jalao", "badhao", "kam", "kholo", "awaz", "batti", "tez", "jao", "dikhao")
    private val ARTICLE = setOf("the", "a", "an", "app", "application", "please", "मुझे", "को", "का", "की", "के")
    private val CATEGORY = TORCH + VOLUME + WIFI + BLUETOOTH + LOCK + OPEN + HOME + BACK + RECENTS + NOTIF

    fun parse(text: String): IntentMatch {
        val normalized = normalize(text)
        val language = detectLanguage(text, normalized)
        val clauses = splitClauses(normalized).ifEmpty { listOf(normalized) }
        val actions = ArrayList<AegisAction>(clauses.size)
        var resolved = 0
        for (clause in clauses) {
            val action = matchClause(clause)
            if (action != null) { actions += action; resolved++ }
            else if (clause.isNotBlank()) actions += AegisAction.Unresolved(clause)
        }
        val confidence = if (clauses.isEmpty()) 0f else resolved.toFloat() / clauses.size
        return IntentMatch(text, normalized, language, clauses, actions, confidence)
    }

    private fun normalize(text: String) = text.lowercase().replace(Regex("\\s+"), " ").trim()

    private fun detectLanguage(raw: String, normalized: String): IntentMatch.Language {
        val dev = DEVANAGARI.containsMatchIn(raw)
        val lat = LATIN.containsMatchIn(raw)
        val hin = HINGLISH_HINTS.any { normalized.contains(it) }
        return when {
            dev && lat -> IntentMatch.Language.MIXED
            dev -> IntentMatch.Language.HINDI
            hin -> IntentMatch.Language.HINGLISH
            lat -> IntentMatch.Language.ENGLISH
            else -> IntentMatch.Language.UNKNOWN
        }
    }

    private fun splitClauses(normalized: String): List<String> {
        var w = normalized
        w = w.replace(LATIN_CONJ, SPLIT)
        w = w.replace(DEV_CONJ, SPLIT)
        w = w.replace(PUNCT_SPLIT, SPLIT)
        return w.split(SPLIT).map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun tokenize(clause: String): Set<String> =
        clause.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()

    private fun matchClause(clause: String): AegisAction? {
        val tokens = tokenize(clause)
        if (tokens.isEmpty()) return null

        if (tokens.any { it in DIAGNOSTICS } || tokens.any { it in SYSTEM_OK }) return AegisAction.SystemDiagnostics
        if (tokens.any { it in POWER }) return AegisAction.QueryPowerStatus
        if (tokens.any { it in BATTERY } && tokens.any { it in TEMP }) return AegisAction.QueryVitals(VitalsQuery.BATTERY_TEMP)
        if (tokens.any { it in BATTERY }) return AegisAction.QueryVitals(VitalsQuery.BATTERY_STATUS)
        if (tokens.any { it in THERMAL } || tokens.any { it in TEMP }) return AegisAction.QueryVitals(VitalsQuery.THERMAL_STATUS)
        if (tokens.any { it in NETWORK }) return AegisAction.QueryVitals(VitalsQuery.NETWORK_STATUS)
        if (tokens.any { it in VITALS }) return AegisAction.QueryVitals(VitalsQuery.FULL_REPORT)

        if (tokens.any { it in DND } || tokens.any { it in DISTURB }) {
            return when {
                tokens.any { it in OFF } || tokens.any { it in MUTE } -> AegisAction.SetDnd(false)
                tokens.any { it in ON } -> AegisAction.SetDnd(true)
                else -> AegisAction.SetDnd(true)
            }
        }
        if (tokens.any { it in DARK } && tokens.any { it in MODE }) return AegisAction.SetNightMode(true)
        if (tokens.any { it in LIGHT } && tokens.any { it in MODE }) return AegisAction.SetNightMode(false)
        if (tokens.any { it in ROTATION }) return AegisAction.SetAutoRotation(!tokens.any { it in OFF })
        if (tokens.any { it in TIMEOUT }) {
            val num = NUMBER.find(clause)?.groupValues?.get(1)?.toLongOrNull()
            if (num != null) {
                val ms = when {
                    tokens.any { it in MINUTES } -> num * 60_000L
                    tokens.any { it in SECONDS } -> num * 1_000L
                    num < 100L -> num * 1_000L
                    else -> num * 60_000L
                }
                return AegisAction.SetScreenTimeout(ms)
            }
        }
        if (tokens.any { it in AIRPLANE }) return AegisAction.RequestAirplanePanel
        if (tokens.any { it in LOCATION }) return AegisAction.RequestLocationPanel

        if (tokens.any { it in VOLUME }) {
            val num = NUMBER.find(clause)?.groupValues?.get(1)?.toIntOrNull()
            if (num != null) return AegisAction.VolumeSet(detectStream(tokens), num.coerceIn(0, 100))
            if (tokens.any { it in UNMUTE }) return AegisAction.VolumeMute(detectStream(tokens), false)
            if (tokens.any { it in MUTE }) return AegisAction.VolumeMute(detectStream(tokens), true)
            if (tokens.any { it in UP }) return AegisAction.VolumeAdjust(detectStream(tokens), AegisAction.Direction.UP)
            if (tokens.any { it in DOWN }) return AegisAction.VolumeAdjust(detectStream(tokens), AegisAction.Direction.DOWN)
        }
        if (tokens.any { it in TORCH }) {
            return when {
                tokens.any { it in OFF } -> AegisAction.TorchOff
                tokens.any { it in ON } -> AegisAction.TorchOn
                else -> AegisAction.TorchToggle
            }
        }
        if (tokens.any { it in WIFI }) {
            return when {
                tokens.any { it in OFF } -> AegisAction.WifiOff
                tokens.any { it in ON } -> AegisAction.WifiOn
                else -> AegisAction.WifiToggle
            }
        }
        if (tokens.any { it in BLUETOOTH }) {
            return when {
                tokens.any { it in OFF } -> AegisAction.BluetoothOff
                tokens.any { it in ON } -> AegisAction.BluetoothOn
                else -> AegisAction.BluetoothToggle
            }
        }
        if (tokens.any { it in HOME }) return AegisAction.GoHome
        if (tokens.any { it in RECENTS }) return AegisAction.ShowRecents
        if (tokens.any { it in NOTIF } && tokens.any { it in SHOW }) return AegisAction.ShowNotifications
        if (tokens.any { it in BACK }) return AegisAction.GoBack
        if (tokens.any { it in LOCK } && (tokens.any { it in SCREEN } || tokens.size <= 3)) return AegisAction.LockScreen
        if (tokens.any { it in OPEN }) {
            val app = tokens.filter { it !in ARTICLE && it !in CATEGORY && it !in ON && it !in OFF && it !in TOGGLE && it !in SHOW && it !in GO }.joinToString(" ")
            if (app.isNotBlank()) return AegisAction.OpenApp(app)
        }
        return null
    }

    private fun detectStream(tokens: Set<String>): AudioStream = when {
        tokens.any { it in CALL } -> AudioStream.CALL
        tokens.any { it in RING } -> AudioStream.RING
        tokens.any { it in ALARM } -> AudioStream.ALARM
        tokens.any { it in NOTIF } -> AudioStream.NOTIFICATION
        else -> AudioStream.MEDIA
    }
}
