package com.aegis.ai.conversation

import android.os.SystemClock
import com.aegis.ai.cognitive.DialogTurn
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

data class ConversationTurn(
    val id: Long, val userText: String, val assistantText: String?,
    val actions: List<AegisAction>, val resolvedEntities: Map<String, String>,
    val timestampMs: Long, val language: IntentMatch.Language
)

data class EntityMemory(
    val activeContact: String?,
    val lastTargetApp: String?,
    val lastInspectedVisualEntity: String?,
    val pendingAction: PendingAction?
) {
    companion object { val EMPTY = EntityMemory(null, null, null, null) }
}

data class PendingAction(
    val type: PendingActionType, val originalUtterance: String,
    val filledSlots: Map<String, String>, val missingSlots: List<String>,
    val createdAtMs: Long
)

enum class PendingActionType { SEND_WHATSAPP, PLAY_YOUTUBE }

data class ConversationSnapshot(
    val turns: List<ConversationTurn>,
    val entities: EntityMemory,
    val lastActivityMs: Long
) {
    companion object { val EMPTY = ConversationSnapshot(emptyList(), EntityMemory.EMPTY, 0L) }
}

class ConversationContextManager(
    private val memoryManager: com.aegis.ai.memory.LongTermMemoryManager? = null
) {
    private val writeMutex = Mutex()
    private val ref = AtomicReference(ConversationSnapshot.EMPTY)
    private val counter = AtomicLong(0L)

    fun current(): ConversationSnapshot {
        val raw = ref.get()
        if (raw.lastActivityMs == 0L) return ConversationSnapshot.EMPTY
        return if (SystemClock.elapsedRealtime() - raw.lastActivityMs > EXPIRATION_MS) ConversationSnapshot.EMPTY else raw
    }

    fun recentTurns(count: Int = MAX_TURNS): List<ConversationTurn> = current().turns.takeLast(count.coerceAtLeast(1))
    fun lastTurn(): ConversationTurn? = current().turns.lastOrNull()
    fun entities(): EntityMemory = current().entities
    fun pendingAction(): PendingAction? = current().entities.pendingAction

    fun dialogHistory(): List<DialogTurn> {
        val snap = current()
        if (snap.turns.isEmpty()) return emptyList()
        val h = ArrayList<DialogTurn>(snap.turns.size * 2)
        for (t in snap.turns) {
            h += DialogTurn("user", t.userText)
            t.assistantText?.takeIf { it.isNotBlank() }?.let { h += DialogTurn("model", it) }
        }
        return h
    }

    suspend fun recordTurn(
        userText: String, assistantText: String?, actions: List<AegisAction>,
        resolvedEntities: Map<String, String> = emptyMap(),
        language: IntentMatch.Language = IntentMatch.Language.ENGLISH
    ) = writeMutex.withLock {
        val now = SystemClock.elapsedRealtime()
        val base = physicalOrExpired(now)
        val t = ConversationTurn(counter.incrementAndGet(), userText.trim(), assistantText?.trim()?.takeIf { it.isNotEmpty() }, actions, resolvedEntities, now, language)
        ref.set(base.copy(turns = (base.turns + t).takeLast(MAX_TURNS), lastActivityMs = now))
    }

    suspend fun updateEntities(block: (EntityMemory) -> EntityMemory) = writeMutex.withLock {
        val now = SystemClock.elapsedRealtime()
        val base = physicalOrExpired(now)
        ref.set(base.copy(entities = block(base.entities), lastActivityMs = now))
    }

    suspend fun clear() = writeMutex.withLock { ref.set(ConversationSnapshot.EMPTY); counter.set(0L) }

    private fun physicalOrExpired(now: Long): ConversationSnapshot {
        val raw = ref.get()
        if (raw.lastActivityMs == 0L) return ConversationSnapshot.EMPTY
        return if (now - raw.lastActivityMs > EXPIRATION_MS) ConversationSnapshot.EMPTY else raw
    }

    companion object {
        const val MAX_TURNS = 6
        const val EXPIRATION_MS = 60_000L
    }
}
