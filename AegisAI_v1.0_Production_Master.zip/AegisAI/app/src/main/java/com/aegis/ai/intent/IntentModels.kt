package com.aegis.ai.intent

import android.content.Intent
import android.media.AudioManager

sealed interface AegisAction {
    data object TorchOn : AegisAction
    data object TorchOff : AegisAction
    data object TorchToggle : AegisAction
    data class VolumeSet(val stream: AudioStream, val percent: Int) : AegisAction
    data class VolumeAdjust(val stream: AudioStream, val direction: Direction) : AegisAction
    data class VolumeMute(val stream: AudioStream, val mute: Boolean?) : AegisAction
    data object BluetoothOn : AegisAction
    data object BluetoothOff : AegisAction
    data object BluetoothToggle : AegisAction
    data object WifiOn : AegisAction
    data object WifiOff : AegisAction
    data object WifiToggle : AegisAction
    data object LockScreen : AegisAction
    data object GoHome : AegisAction
    data object GoBack : AegisAction
    data object ShowRecents : AegisAction
    data object ShowNotifications : AegisAction
    data object MediaPlay : AegisAction
    data object MediaPause : AegisAction
    data object MediaTogglePlayPause : AegisAction
    data object MediaNext : AegisAction
    data object MediaPrevious : AegisAction
    data object MediaStop : AegisAction
    data class SetDnd(val enabled: Boolean) : AegisAction
    data class SetAutoRotation(val enabled: Boolean) : AegisAction
    data class SetNightMode(val enabled: Boolean) : AegisAction
    data class SetScreenTimeout(val timeoutMs: Long) : AegisAction
    data object RequestAirplanePanel : AegisAction
    data object RequestLocationPanel : AegisAction
    data class QueryVitals(val query: VitalsQuery) : AegisAction
    data object SystemDiagnostics : AegisAction
    data object QueryPowerStatus : AegisAction
    data object QueryLocation : AegisAction
    data object OpenApp(val query: String) : AegisAction
    data class Unresolved(val text: String) : AegisAction

    enum class Direction { UP, DOWN }

    fun isFastPath(): Boolean = when (this) {
        is Unresolved -> false
        is OpenApp -> false
        else -> true
    }

    fun isAutomation(): Boolean = false
    fun isLocal(): Boolean = isFastPath() || isAutomation()
    fun requiresSlotFilling(): Boolean = false
}

enum class AudioStream(val androidStream: Int) {
    MEDIA(AudioManager.STREAM_MUSIC),
    CALL(AudioManager.STREAM_VOICE_CALL),
    RING(AudioManager.STREAM_RING),
    ALARM(AudioManager.STREAM_ALARM),
    NOTIFICATION(AudioManager.STREAM_NOTIFICATION)
}

enum class VitalsQuery {
    BATTERY_LEVEL, BATTERY_STATUS, BATTERY_TEMP,
    THERMAL_STATUS, NETWORK_STATUS, FULL_REPORT
}

data class IntentMatch(
    val rawText: String,
    val normalizedText: String,
    val language: Language,
    val clauses: List<String>,
    val actions: List<AegisAction>,
    val confidence: Float
) {
    enum class Language { ENGLISH, HINDI, HINGLISH, MIXED, UNKNOWN }

    val isFullyResolved: Boolean
        get() = actions.isNotEmpty() && actions.none { it is AegisAction.Unresolved }
    val isFastPath: Boolean
        get() = actions.isNotEmpty() && actions.all { it.isFastPath() }
    val isMultiAction: Boolean get() = actions.size > 1
}

data class ActionOutcome(
    val action: AegisAction,
    val success: Boolean,
    val message: String,
    val pendingIntent: Intent? = null,
    val elapsedMs: Long = 0L
)

data class RouteOutcome(
    val path: Path,
    val source: IntentMatch,
    val executed: List<ActionOutcome>,
    val forwardedPrompt: String? = null,
    val elapsedMs: Long = 0L
) {
    enum class Path { FAST, AUTOMATION, COGNITIVE, MIXED, SLOT_FILLING, UNKNOWN }
    val allSucceeded: Boolean get() = executed.isNotEmpty() && executed.all { it.success }
}

interface AsrTranscriber {
    suspend fun transcribe(pcm: ShortArray, sampleRate: Int): String?
    object NoOp : AsrTranscriber {
        override suspend fun transcribe(pcm: ShortArray, sampleRate: Int): String? = null
    }
}
