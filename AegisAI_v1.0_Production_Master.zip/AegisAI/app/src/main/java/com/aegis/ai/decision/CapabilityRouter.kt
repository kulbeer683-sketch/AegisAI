package com.aegis.ai.decision

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch
import com.aegis.ai.privacy.PrivacyPreferences

class CapabilityRouter(
    private val isCloudAvailable: () -> Boolean,
    private val isScreenVisionAvailable: () -> Boolean,
    private val isCameraVisionAvailable: () -> Boolean,
    private val privacy: () -> PrivacyPreferences? = { null }
) {

    fun route(match: IntentMatch?): ExecutionCapability {
        if (match == null || match.actions.isEmpty()) return ExecutionCapability.BLOCKED
        val acts = match.actions
        val pol = privacy()

        if (acts.any { it is AegisAction.Unresolved || it is AegisAction.OpenApp }) {
            val allowed = pol?.isCloudReasoningEnabled() ?: true
            return when { !allowed -> ExecutionCapability.BLOCKED; isCloudAvailable() -> ExecutionCapability.CLOUD_LLM; else -> ExecutionCapability.BLOCKED }
        }
        if (acts.any { it is AegisAction.InspectScreen }) {
            val allowed = pol?.isScreenVisionEnabled() ?: true
            return when { !allowed -> ExecutionCapability.BLOCKED; isScreenVisionAvailable() -> ExecutionCapability.SCREEN_VISION; else -> ExecutionCapability.BLOCKED }
        }
        if (acts.any { it is AegisAction.InspectRealWorld }) {
            val allowed = pol?.isCameraVisionEnabled() ?: true
            return when { !allowed -> ExecutionCapability.BLOCKED; isCameraVisionAvailable() -> ExecutionCapability.CAMERA_VISION; else -> ExecutionCapability.BLOCKED }
        }

        val allFast = acts.all { it.isFastPath() }
        if (allFast) {
            val needsCtx = acts.any {
                it is AegisAction.QueryLocation || it is AegisAction.QueryVitals ||
                it is AegisAction.SystemDiagnostics || it is AegisAction.QueryPowerStatus
            }
            return if (needsCtx) ExecutionCapability.CONTEXTUAL_LOCAL else ExecutionCapability.FAST_PATH
        }
        val allowed = pol?.isCloudReasoningEnabled() ?: true
        return when { !allowed -> ExecutionCapability.BLOCKED; isCloudAvailable() -> ExecutionCapability.CLOUD_LLM; else -> ExecutionCapability.BLOCKED }
    }
}
