package com.aegis.ai.accessibility

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.aegis.ai.audio.AudioConfig

object UiNodeResolver {

    private const val MAX_NODES = 5_000

    fun findByText(root: AccessibilityNodeInfo, needle: String): AccessibilityNodeInfo? {
        if (needle.isBlank()) return null
        return search(root) { n ->
            val t = n.text?.toString()
            val d = n.contentDescription?.toString()
            (t?.contains(needle, ignoreCase = true) == true) || (d?.contains(needle, ignoreCase = true) == true)
        }
    }

    fun findByViewId(root: AccessibilityNodeInfo, viewId: String): AccessibilityNodeInfo? {
        if (viewId.isBlank()) return null
        return search(root) { n -> n.viewIdResourceName == viewId }
    }

    fun findByPredicate(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? =
        search(root, predicate)

    fun findClickableAncestor(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var c = node
        var g = 0
        while (c != null && g++ < 32) {
            if (c.isClickable && c.isEnabled) return c
            c = c.parent
        }
        return null
    }

    fun clickByText(root: AccessibilityNodeInfo, text: String): Boolean {
        val m = findByText(root, text) ?: return false
        try {
            val t = findClickableAncestor(m) ?: return false
            return t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } finally {
            if (m != root) m.recycleSafe()
        }
    }

    fun clickByViewId(root: AccessibilityNodeInfo, viewId: String): Boolean {
        val m = findByViewId(root, viewId) ?: return false
        try {
            val t = findClickableAncestor(m) ?: return false
            return t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } finally {
            if (m != root) m.recycleSafe()
        }
    }

    fun setTextOnFocused(root: AccessibilityNodeInfo, text: String): Boolean {
        val f = findFocusedEditable(root) ?: return false
        return try {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } finally { f.recycleSafe() }
    }

    fun typeIntoField(root: AccessibilityNodeInfo, fieldMatch: String, content: String): Boolean {
        val t = findByText(root, fieldMatch) ?: return false
        try {
            val f = findFocusable(t) ?: t
            f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, content)
            }
            return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } finally { if (t != root) t.recycleSafe() }
    }

    fun extractTextSnapshot(root: AccessibilityNodeInfo, maxChars: Int = 2_000): String {
        val sb = StringBuilder()
        val q = ArrayDeque<AccessibilityNodeInfo>()
        val owned = ArrayList<AccessibilityNodeInfo>(64)
        val rc = AccessibilityNodeInfo.obtain(root)
        q.addLast(rc); owned.add(rc)
        try {
            var v = 0
            while (q.isNotEmpty() && sb.length < maxChars && v++ < MAX_NODES) {
                val n = q.removeFirst()
                val t = n.text?.toString()
                if (!t.isNullOrBlank()) sb.append(t).append('\n')
                for (i in 0 until n.childCount) {
                    n.getChild(i)?.let { q.addLast(it); owned.add(it) }
                }
            }
        } finally { owned.forEach { it.recycleSafe() } }
        return sb.toString().trim()
    }

    private fun search(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val q = ArrayDeque<AccessibilityNodeInfo>()
        val owned = ArrayList<AccessibilityNodeInfo>(64)
        val rc = AccessibilityNodeInfo.obtain(root)
        q.addLast(rc); owned.add(rc)
        try {
            var v = 0
            while (q.isNotEmpty() && v++ < MAX_NODES) {
                val n = q.removeFirst()
                val ok = try { predicate(n) } catch (_: Throwable) { false }
                if (ok) { owned.remove(n); return n }
                for (i in 0 until n.childCount) {
                    n.getChild(i)?.let { q.addLast(it); owned.add(it) }
                }
            }
            return null
        } finally { owned.forEach { it.recycleSafe() } }
    }

    private fun findFocusedEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        search(root) { it.isFocused && it.isEditable && it.isEnabled }

    private fun findFocusable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var c = node
        var g = 0
        while (c != null && g++ < 16) {
            if (c.isFocusable && c.isEnabled) return c
            c = c.parent
        }
        return null
    }

    fun AccessibilityNodeInfo?.recycleSafe() {
        val n = this ?: return
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                @Suppress("DEPRECATION") n.recycle()
            }
        } catch (_: Throwable) {}
    }

    @Suppress("unused")
    private const val TAG = AudioConfig.TAG
}
