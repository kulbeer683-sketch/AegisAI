package com.aegis.ai.intent

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.hardware.ConnectivityController
import com.aegis.ai.hardware.ControllerResult
import com.aegis.ai.hardware.FlashlightController
import com.aegis.ai.hardware.VolumeController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class ActionExecutor(
    private val flashlight: FlashlightController,
    private val volume: VolumeController,
    private val connectivity: ConnectivityController
) {
    suspend fun execute(action: AegisAction): ActionOutcome {
        val t0 = SystemClock.elapsedRealtime()
        val (ok, msg, pending) = try { dispatch(action) } catch (t: Throwable) {
            Log.e(AudioConfig.TAG, "dispatch threw $action", t)
            Triple(false, "${t.javaClass.simpleName}: ${t.message}", null)
        }
        return ActionOutcome(action, ok, msg, pending, SystemClock.elapsedRealtime() - t0)
    }

    private suspend fun dispatch(action: AegisAction): Triple<Boolean, String, Intent?> = when (action) {
        AegisAction.TorchOn -> flashlight.setTorch(true).toTriple()
        AegisAction.TorchOff -> flashlight.setTorch(false).toTriple()
        AegisAction.TorchToggle -> flashlight.toggle().toTriple()

        is AegisAction.VolumeSet -> volume.setVolume(action.stream, action.percent).toTriple()
        is AegisAction.VolumeAdjust -> volume.adjustVolume(action.stream, action.direction).toTriple()
        is AegisAction.VolumeMute -> volume.setMute(action.stream, action.mute).toTriple()

        AegisAction.BluetoothOn -> connectivity.setBluetooth(true).toTriple()
        AegisAction.BluetoothOff -> connectivity.setBluetooth(false).toTriple()
        AegisAction.BluetoothToggle -> connectivity.toggleBluetooth().toTriple()
        AegisAction.WifiOn -> connectivity.setWifi(true).toTriple()
        AegisAction.WifiOff -> connectivity.setWifi(false).toTriple()
        AegisAction.WifiToggle -> connectivity.toggleWifi().toTriple()

        else -> Triple(false, "Not wired in PART 1: ${action::class.simpleName}", null)
    }

    private fun ControllerResult.toTriple(): Triple<Boolean, String, Intent?> = when (this) {
        is ControllerResult.Success -> Triple(true, message, null)
        is ControllerResult.Failure -> Triple(false, message, null)
        is ControllerResult.NeedsUserIntent -> Triple(false, message, intent)
    }
}

class FastIntentRouter(
    private val executor: ActionExecutor,
    private val scope: CoroutineScope
) {
    private val execMutex = Mutex()
    private val _outcomes = MutableSharedFlow<RouteOutcome>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val outcomes: SharedFlow<RouteOutcome> = _outcomes.asSharedFlow()

    suspend fun route(match: IntentMatch): RouteOutcome = execMutex.withLock {
        val t0 = SystemClock.elapsedRealtime()
        if (match.actions.isEmpty()) {
            return@withLock finish(RouteOutcome.Path.UNKNOWN, match, emptyList(), null, t0)
        }
        val cognitive = match.actions.any { it is AegisAction.Unresolved || it is AegisAction.OpenApp }
        if (cognitive) {
            return@withLock finish(RouteOutcome.Path.COGNITIVE, match, emptyList(), match.rawText, t0)
        }
        val results = ArrayList<ActionOutcome>(match.actions.size)
        for (a in match.actions) results += executor.execute(a)
        val allOk = results.all { it.success }
        val path = if (allOk) RouteOutcome.Path.FAST else RouteOutcome.Path.MIXED
        Log.i(AudioConfig.TAG, "ROUTE[$path] ${match.actions.size} actions in ${SystemClock.elapsedRealtime() - t0}ms")
        finish(path, match, results, null, t0)
    }

    fun routeAsync(match: IntentMatch) { scope.launch { route(match) } }

    private fun finish(p: RouteOutcome.Path, m: IntentMatch, e: List<ActionOutcome>, f: String?, start: Long): RouteOutcome {
        val o = RouteOutcome(p, m, e, f, SystemClock.elapsedRealtime() - start)
        _outcomes.tryEmit(o)
        return o
    }
}
