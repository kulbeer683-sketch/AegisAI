package com.aegis.ai.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.aegis.ai.audio.AudioConfig
import java.io.File
import java.security.KeyStore
import java.security.UnrecoverableEntryException
import java.security.UnrecoverableKeyException
import javax.crypto.IllegalBlockSizeException

class SecureKeyStorage(context: Context) {

    private val appContext = context.applicationContext
    @Volatile private var prefs: SharedPreferences? = createStore()
    private val recoveryLock = Any()

    fun getGeminiApiKey(): String? = readString(KEY_GEMINI, true)
    fun setGeminiApiKey(key: String?) = writeString(KEY_GEMINI, key?.trim(), true)
    fun hasGeminiApiKey(): Boolean = !getGeminiApiKey().isNullOrBlank()
    fun clearGeminiApiKey() = writeString(KEY_GEMINI, null, true)

    fun clearAll() {
        runCatching { prefs?.edit()?.clear()?.apply() }
    }

    fun isHealthy(): Boolean = prefs != null

    private fun readString(key: String, sanitize: Boolean): String? {
        val p = ensureStore() ?: return null
        return try {
            val raw = p.getString(key, null) ?: return null
            val t = if (sanitize) raw.trim() else raw
            if (t.isEmpty()) null else t
        } catch (t: Throwable) {
            if (isInvalidation(t)) { recover() } else Log.w(TAG, "read '$key' failed", t)
            null
        }
    }

    private fun writeString(key: String, value: String?, sanitize: Boolean) {
        var p = ensureStore() ?: run { recover(); ensureStore() } ?: return
        try {
            val e = p.edit()
            if (value.isNullOrEmpty()) e.remove(key) else e.putString(key, if (sanitize) value.trim() else value)
            e.apply()
        } catch (t: Throwable) {
            if (isInvalidation(t)) {
                recover()
                val fresh = ensureStore()
                if (fresh != null && !value.isNullOrEmpty()) {
                    runCatching { fresh.edit().putString(key, if (sanitize) value.trim() else value).apply() }
                }
            } else Log.e(TAG, "write '$key' failed", t)
        }
    }

    private fun ensureStore(): SharedPreferences? {
        prefs?.let { return it }
        synchronized(recoveryLock) { prefs?.let { return it }; return createStore().also { prefs = it } }
    }

    private fun createStore(): SharedPreferences? = try {
        val mk = MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            appContext, PREFS_FILE, mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (t: Throwable) {
        if (isInvalidation(t)) {
            deleteAlias(); deletePrefs()
            try {
                val mk = MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
                EncryptedSharedPreferences.create(
                    appContext, PREFS_FILE, mk,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (r: Throwable) { Log.e(TAG, "retry failed", r); null }
        } else { Log.e(TAG, "EncryptedSharedPreferences init failed", t); null }
    }

    private fun recover() {
        synchronized(recoveryLock) {
            runCatching { deleteAlias(); deletePrefs(); prefs = null; prefs = createStore() }
        }
    }

    private fun deleteAlias() {
        runCatching {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
        }
    }

    private fun deletePrefs() {
        runCatching { File(appContext.dataDir, "shared_prefs/${PREFS_FILE}.xml").delete() }
    }

    private fun isInvalidation(t: Throwable): Boolean {
        var c: Throwable? = t
        var d = 0
        while (c != null && d++ < 8) {
            when (c) {
                is UnrecoverableEntryException, is UnrecoverableKeyException, is IllegalBlockSizeException -> return true
            }
            val n = c.javaClass.simpleName
            if (n.contains("KeyPermanentlyInvalidated", true) ||
                n.contains("UserNotAuthenticated", true) ||
                n.contains("KeyStoreException", true)) return true
            c = c.cause
        }
        return false
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val PREFS_FILE = "aegis_secure_keys"
        private const val KEY_GEMINI = "gemini_api_key_v1"
        private const val ALIAS = "_androidx_security_master_key_"
    }
}
