package com.aegis.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.aegis.ai.MainActivity
import com.aegis.ai.R
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioDspPipeline
import com.aegis.ai.hardware.ConnectivityController
import com.aegis.ai.hardware.FlashlightController
import com.aegis.ai.hardware.VolumeController
import com.aegis.ai.intent.ActionExecutor
import com.aegis.ai.intent.FastIntentRouter
import com.aegis.ai.intent.SpeechIntentEngine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class AegisForegroundService : LifecycleService() {

    private lateinit var pipeline: AudioDspPipeline
    private lateinit var intentEngine: SpeechIntentEngine
    private lateinit var flashlight: FlashlightController
    private lateinit var volume: VolumeController
    private lateinit var connectivity: ConnectivityController
    private lateinit var router: FastIntentRouter

    private var isForeground = false

    override fun onCreate() {
        super.onCreate()

        pipeline = AudioDspPipeline(applicationContext)
        intentEngine = SpeechIntentEngine(lifecycleScope)
        flashlight = FlashlightController(applicationContext)
        volume = VolumeController(applicationContext)
        connectivity = ConnectivityController(applicationContext)

        val executor = ActionExecutor(flashlight, volume, connectivity)
        router = FastIntentRouter(executor, lifecycleScope)

        createChannel()

        intentEngine.bindTo(pipeline)

        intentEngine.matches
            .onEach { match ->
                Log.i(AudioConfig.TAG, "MATCH ${match.actions.size} actions lang=${match.language}")
                val outcome = router.route(match)
                outcome.executed.forEach { o ->
                    Log.i(AudioConfig.TAG, "  ${if (o.success) "✓" else "✗"} ${o.action::class.simpleName} (${o.elapsedMs}ms) — ${o.message}")
                }
            }
            .launchIn(lifecycleScope)

        pipeline.stats
            .onEach { s -> Log.d(AudioConfig.TAG, "Pipeline: ${s.state} frames=${s.framesCaptured}") }
            .launchIn(lifecycleScope)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_STOP -> {
                lifecycleScope.launch { pipeline.stop(); stopForegroundAndSelf() }
                return START_NOT_STICKY
            }
            ACTION_TEXT -> {
                promoteToForeground()
                val text = intent.getStringExtra(EXTRA_TEXT).orEmpty()
                if (text.isNotBlank()) {
                    lifecycleScope.launch { intentEngine.submitText(text) }
                }
                return START_STICKY
            }
            ACTION_START, null -> {
                promoteToForeground()
                lifecycleScope.launch {
                    val ok = pipeline.start(preferBluetoothSco = false)
                    if (!ok) { Log.e(AudioConfig.TAG, "Pipeline failed"); stopForegroundAndSelf() }
                }
                return START_STICKY
            }
        }
        promoteToForeground()
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    override fun onDestroy() {
        intentEngine.shutdown()
        flashlight.close()
        pipeline.shutdown()
        isForeground = false
        super.onDestroy()
    }

    private fun promoteToForeground() {
        if (isForeground) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
        isForeground = true
    }

    private fun stopForegroundAndSelf() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        isForeground = false
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val m = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (m.getNotificationChannel(CHANNEL_ID) != null) return
        m.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.notif_channel_desc)
                setShowBadge(false)
            }
        )
    }

    private fun buildNotification(): Notification {
        val content = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AegisForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(R.drawable.ic_aegis_notification)
            .setContentIntent(content)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val ACTION_START = "com.aegis.ai.action.START"
        const val ACTION_STOP = "com.aegis.ai.action.STOP"
        const val ACTION_TEXT = "com.aegis.ai.action.TEXT"
        const val EXTRA_TEXT = "com.aegis.ai.extra.TEXT"
        private const val CHANNEL_ID = "aegis_foreground_service"
        private const val NOTIFICATION_ID = 0xA361

        fun startIntent(context: Context, preferBluetoothSco: Boolean = false): Intent =
            Intent(context, AegisForegroundService::class.java).apply {
                action = ACTION_START
                putExtra("prefer_sco", preferBluetoothSco)
            }

        fun stopIntent(context: Context): Intent =
            Intent(context, AegisForegroundService::class.java).apply { action = ACTION_STOP }

        fun textIntent(context: Context, text: String): Intent =
            Intent(context, AegisForegroundService::class.java).apply {
                action = ACTION_TEXT
                putExtra(EXTRA_TEXT, text)
            }
    }
}
