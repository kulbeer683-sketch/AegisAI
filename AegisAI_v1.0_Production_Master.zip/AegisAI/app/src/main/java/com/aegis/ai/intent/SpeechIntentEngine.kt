package com.aegis.ai.intent

import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioDspPipeline
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

class SpeechIntentEngine(
    private val scope: CoroutineScope,
    private val asr: AsrTranscriber = AsrTranscriber.NoOp
) {
    data class Utterance(val pcm: ShortArray, val startedAtMs: Long, val endedAtMs: Long, val avgSnrDb: Double) {
        override fun equals(other: Any?): Boolean = this === other
        override fun hashCode(): Int = pcm.contentHashCode()
    }

    enum class Mode { IDLE, CALL_COMMAND }

    private val _utterances = MutableSharedFlow<Utterance>(extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val utterances: SharedFlow<Utterance> = _utterances.asSharedFlow()

    private val _matches = MutableSharedFlow<IntentMatch>(extraBufferCapacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val matches: SharedFlow<IntentMatch> = _matches.asSharedFlow()

    private val _mode = MutableStateFlow(Mode.IDLE)
    val mode: StateFlow<Mode> = _mode.asStateFlow()

    private val frameCounter = AtomicLong(0L)
    val framesObserved: Long get() = frameCounter.get()

    private var boundJob: Job? = null
    private var speaking = false
    private var uttStart = 0L
    private var uttSnrSum = 0.0
    private var uttFrames = 0
    private val buffer = ArrayList<Short>(AudioConfig.FRAME_SIZE * 128)

    fun bindTo(pipeline: AudioDspPipeline): Job {
        boundJob?.cancel()
        val job = pipeline.frames.onEach { ingest(it) }.launchIn(scope)
        boundJob = job
        return job
    }

    fun shutdown() {
        boundJob?.cancel(); boundJob = null
        speaking = false; buffer.clear(); uttSnrSum = 0.0; uttFrames = 0
        _mode.value = Mode.IDLE
    }

    fun enterCallCommandMode() { _mode.value = Mode.CALL_COMMAND }
    fun exitCallCommandMode() { _mode.value = Mode.IDLE }

    fun submitText(text: String): IntentMatch {
        val match = IntentGrammar.parse(text)
        if (match.normalizedText.isNotBlank()) _matches.tryEmit(match)
        return match
    }

    suspend fun ingest(frame: AudioDspPipeline.AudioFrame) {
        frameCounter.incrementAndGet()
        val vad = frame.vad
        if (vad.isSpeech) {
            if (!speaking) {
                speaking = true; uttStart = frame.timestampMs
                buffer.clear(); uttSnrSum = 0.0; uttFrames = 0
            }
            for (s in frame.pcm) buffer.add(s)
            uttSnrSum += vad.snrDb; uttFrames++
        } else if (speaking) {
            speaking = false
            if (uttFrames == 0) return
            val pcm = buffer.toShortArray()
            val end = frame.timestampMs
            val avg = uttSnrSum / uttFrames
            buffer.clear(); uttSnrSum = 0.0; uttFrames = 0
            val u = Utterance(pcm, uttStart, end, avg)
            _utterances.tryEmit(u)
            Log.d(AudioConfig.TAG, "Utterance ${u.endedAtMs - u.startedAtMs}ms snr=${"%.1f".format(avg)}dB")
            transcribeAndMatch(u)
        }
    }

    private fun transcribeAndMatch(utterance: Utterance) {
        scope.launch {
            val text = try { asr.transcribe(utterance.pcm, AudioConfig.SAMPLE_RATE) } catch (t: Throwable) { null }
            if (text.isNullOrBlank()) return@launch
            val match = IntentGrammar.parse(text)
            _matches.tryEmit(match)
        }
    }
}
