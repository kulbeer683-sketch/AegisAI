package com.aegis.ai

import android.app.Application
import android.util.Log
import com.aegis.ai.audio.AudioConfig

class AegisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        installCrashTrap()
        Log.i(
            AudioConfig.TAG,
            "Aegis AI booting · SR=${AudioConfig.SAMPLE_RATE}Hz " +
                "frame=${AudioConfig.FRAME_SIZE} band=" +
                "${AudioConfig.BANDPASS_LOW_HZ.toInt()}-${AudioConfig.BANDPASS_HIGH_HZ.toInt()}Hz"
        )
    }

    private fun installCrashTrap() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e(AudioConfig.TAG, "Uncaught exception on ${thread.name}", throwable)
            previous?.uncaughtException(thread, throwable)
        }
    }
}
