package com.aegis.ai.conversation

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.call.InEarNotificationManager
import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.IntentMatch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SlotFillingCoordinator(
    private val scope: CoroutineScope,
    private val contextManager: ConversationContextManager,
    private val inEar: InEarNotificationManager?,
    private val onEnterAwaitingSlot: () -> Unit,
    private val onExitAwaitingSlot: () -> Unit
) {

    fun interface ActionRunner {
        suspend fun run(action: AegisAction): SlotActionOutcome
    }
    data class SlotActionOutcome(val success: Boolean, val message: String)

    private val mutex = Mutex()
    private var session: Session? = null
    private var timeoutJob: Job? = null
    private var runner: ActionRunner? = null

    fun setActionRunner(r: ActionRunner) { runner = r }

    private data class Session(
        val type: PendingActionType, val utterance: String,
        val language: IntentMatch.Language, val startedAtMs: Long,
        val filled: MutableMap<String, String> = mutableMapOf(),
        val remaining: MutableList<String>
    )

    suspend fun startFor(
        action: AegisAction,
        language: IntentMatch.Language = IntentMatch.Language.ENGLISH,
        originalUtterance: String = ""
    ): Boolean {
        val plan = planFor(action, language) ?: return false
        mutex.withLock {
            timeoutJob?.cancel()
            session = Session(plan.type, originalUtterance, language, SystemClock.elapsedRealtime(), remaining = plan.missing.toMutableList())
        }
        onEnterAwaitingSlot()
        speak(plan.firstPrompt, language)

        timeoutJob = scope.launch {
            val deadline = SystemClock.elapsedRealtime() + TIMEOUT_MS
            while (isActive) {
                delay(500L)
                if (SystemClock.elapsedRealtime() > deadline) { cancelInternal("timeout"); return@launch }
                if (session == null) return@launch
            }
        }
        return true
    }

    suspend fun provideSlot(text: String): Boolean {
        val s = mutex.withLock { session } ?: return false
        val clean = text.trim()
        if (clean.isBlank()) { speak(promptFor(s), s.language); return true }
        val next: String?
        mutex.withLock {
            if (session !== s) return@withLock
            val slot = s.remaining.firstOrNull() ?: return@withLock
            s.filled[slot] = clean; s.remaining.removeAt(0)
            next = s.remaining.firstOrNull()
        }
        if (next != null) { speak(promptFor(s), s.language); return true }

        val completed = buildCompleted(s)
        if (completed == null) { speak("समझ नहीं आया", s.language); cancelInternal("build"); return true }
        mutex.withLock { session = null }
        timeoutJob?.cancel(); timeoutJob = null
        onExitAwaitingSlot()
        val r = runner ?: return true
        scope.launch {
            val out = runCatching { r.run(completed) }.getOrDefault(SlotActionOutcome(false, "failed"))
            if (!completed.isAutomation()) speak(if (out.success) out.message else out.message.ifBlank { "समझ नहीं आया" }, s.language)
        }
        return true
    }

    suspend fun cancel() { cancelInternal("explicit") }
    fun isActive() = session != null

    private suspend fun cancelInternal(reason: String) {
        val had = mutex.withLock { val h = session != null; session = null; h }
        timeoutJob?.cancel(); timeoutJob = null
        if (had) onExitAwaitingSlot()
    }

    private data class Plan(val type: PendingActionType, val missing: List<String>, val firstPrompt: String)

    private fun planFor(a: AegisAction, l: IntentMatch.Language): Plan? = when (a) {
        is AegisAction.IncompleteWhatsApp -> {
            val m = buildList { if (a.recipient.isNullOrBlank()) add(SLOT_RECIPIENT); if (a.message.isNullOrBlank()) add(SLOT_MESSAGE) }
            if (m.isEmpty()) null else Plan(PendingActionType.SEND_WHATSAPP, m, promptForSlot(m.first(), l))
        }
        is AegisAction.IncompleteYouTube -> if (!a.query.isNullOrBlank()) null else Plan(PendingActionType.PLAY_YOUTUBE, listOf(SLOT_QUERY), promptForSlot(SLOT_QUERY, l))
        else -> null
    }

    private fun promptFor(s: Session) = promptForSlot(s.remaining.firstOrNull() ?: return "समझ नहीं आया", s.language)
    private fun promptForSlot(slot: String, l: IntentMatch.Language): String {
        val h = l == IntentMatch.Language.HINDI || l == IntentMatch.Language.HINGLISH
        return when (slot) {
            SLOT_RECIPIENT -> if (h) "किसे भेजना है?" else "Who should I send it to?"
            SLOT_MESSAGE -> if (h) "क्या संदेश भेजना है?" else "What's the message?"
            SLOT_QUERY -> if (h) "कौन सा वीडियो चलाऊँ?" else "Which video?"
            else -> if (h) "कृपया बताएं" else "Please tell me"
        }
    }

    private fun buildCompleted(s: Session): AegisAction? = when (s.type) {
        PendingActionType.SEND_WHATSAPP -> {
            val r = s.filled[SLOT_RECIPIENT]?.trim().orEmpty()
            val m = s.filled[SLOT_MESSAGE]?.trim().orEmpty()
            if (r.isBlank() || m.isBlank()) null else AegisAction.SendWhatsApp(r, m)
        }
        PendingActionType.PLAY_YOUTUBE -> {
            val q = s.filled[SLOT_QUERY]?.trim().orEmpty()
            if (q.isBlank()) null else AegisAction.PlayYouTube(q)
        }
    }

    private suspend fun speak(t: String, l: IntentMatch.Language) { runCatching { inEar?.speak(t, priority = true) } }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val TIMEOUT_MS = 15_000L
        const val SLOT_RECIPIENT = "recipient"
        const val SLOT_MESSAGE = "message"
        const val SLOT_QUERY = "query"
    }
}
