package com.aegis.ai.pipeline

import com.aegis.ai.intent.AegisAction
import com.aegis.ai.intent.AudioStream
import com.aegis.ai.intent.IntentMatch

object FeedbackSynthesizer {

    fun synthesize(results: List<SubActionOutcome>, language: IntentMatch.Language): String {
        if (results.isEmpty()) return ""
        val hindi = language == IntentMatch.Language.HINDI || language == IntentMatch.Language.HINGLISH || language == IntentMatch.Language.MIXED
        val ok = results.filter { it.success }.map { successPhrase(it.task.action, hindi) }.filter { it.isNotBlank() }
        val fail = results.filter { !it.success }.map { failurePhrase(it.task.action, hindi) }.filter { it.isNotBlank() }
        if (ok.isEmpty() && fail.isEmpty()) return ""
        return buildString {
            when {
                ok.isEmpty() -> append(fail.joinToString(", "))
                fail.isEmpty() -> append(ok.joinToString(", "))
                else -> { append(ok.joinToString(", ")); append(if (hindi) ", पर " else ", but "); append(fail.joinToString(", ")) }
            }
        }
    }

    private fun successPhrase(a: AegisAction, h: Boolean): String = when (a) {
        AegisAction.TorchOn -> if (h) "टॉर्च चालू कर दी" else "Torch on"
        AegisAction.TorchOff -> if (h) "टॉर्च बंद कर दी" else "Torch off"
        AegisAction.TorchToggle -> if (h) "टॉर्च बदल दी" else "Torch toggled"
        is AegisAction.VolumeSet -> if (h) "वॉल्यूम ${a.percent}% किया" else "Volume set to ${a.percent}%"
        is AegisAction.VolumeAdjust -> if (h) "वॉल्यूम बदल दी" else "Volume adjusted"
        is AegisAction.VolumeMute -> if (a.mute) (if (h) "म्यूट कर दिया" else "Muted") else (if (h) "अनम्यूट कर दिया" else "Unmuted")
        AegisAction.WifiOn -> if (h) "वाईफाई चालू कर दी" else "Wi-Fi on"
        AegisAction.WifiOff -> if (h) "वाईफाई बंद कर दी" else "Wi-Fi off"
        AegisAction.WifiToggle -> if (h) "वाईफाई बदल दी" else "Wi-Fi toggled"
        AegisAction.BluetoothOn -> if (h) "ब्लूटूथ चालू कर दिया" else "Bluetooth on"
        AegisAction.BluetoothOff -> if (h) "ब्लूटूथ बंद कर दिया" else "Bluetooth off"
        AegisAction.BluetoothToggle -> if (h) "ब्लूटूथ बदल दिया" else "Bluetooth toggled"
        AegisAction.MediaPlay -> if (h) "संगीत चालू किया" else "Music playing"
        AegisAction.MediaPause -> if (h) "संगीत रोक दिया" else "Music paused"
        AegisAction.MediaTogglePlayPause -> if (h) "संगीत बदल दिया" else "Playback toggled"
        AegisAction.MediaNext -> if (h) "अगला गाना लगाया" else "Next track"
        AegisAction.MediaPrevious -> if (h) "पिछला गाना लगाया" else "Previous track"
        AegisAction.MediaStop -> if (h) "संगीत बंद किया" else "Music stopped"
        AegisAction.GoHome -> if (h) "होम पर गया" else "Went home"
        AegisAction.GoBack -> if (h) "पीछे गया" else "Went back"
        AegisAction.ShowRecents -> if (h) "रीसेंट खोले" else "Recents opened"
        AegisAction.ShowNotifications -> if (h) "नोटिफिकेशन खोले" else "Notifications opened"
        AegisAction.LockScreen -> if (h) "स्क्रीन लॉक कर दी" else "Screen locked"
        is AegisAction.SetDnd -> if (a.enabled) (if (h) "साइलेंट मोड चालू किया" else "DND on") else (if (h) "साइलेंट मोड बंद किया" else "DND off")
        is AegisAction.SetAutoRotation -> if (a.enabled) (if (h) "ऑटो-रोटेशन चालू किया" else "Auto-rotate on") else (if (h) "ऑटो-रोटेशन बंद किया" else "Auto-rotate off")
        is AegisAction.SetNightMode -> if (a.enabled) (if (h) "डार्क मोड लगा दिया" else "Dark mode on") else (if (h) "लाइट मोड लगा दिया" else "Light mode on")
        is AegisAction.SetScreenTimeout -> if (h) "स्क्रीन टाइमआउट बदल दिया" else "Screen timeout changed"
        AegisAction.RequestAirplanePanel -> if (h) "एयरप्लेन सेटिंग खोल रहा हूँ" else "Opening airplane settings"
        AegisAction.RequestLocationPanel -> if (h) "लोकेशन सेटिंग खोल रहा हूँ" else "Opening location settings"
        is AegisAction.QueryVitals -> ""
        is AegisAction.SystemDiagnostics -> if (h) "सिस्टम जाँच पूरी" else "Diagnostics complete"
        is AegisAction.QueryPowerStatus -> ""
        is AegisAction.QueryLocation -> ""
        else -> ""
    }

    private fun failurePhrase(a: AegisAction, h: Boolean): String = when (a) {
        AegisAction.TorchOn, AegisAction.TorchOff, AegisAction.TorchToggle -> if (h) "टॉर्च नहीं बदल सका" else "Couldn't toggle torch"
        is AegisAction.VolumeSet, is AegisAction.VolumeAdjust, is AegisAction.VolumeMute -> if (h) "वॉल्यूम नहीं बदल सका" else "Couldn't change volume"
        AegisAction.WifiOn, AegisAction.WifiOff, AegisAction.WifiToggle -> if (h) "वाईफाई नहीं बदल सका" else "Couldn't toggle Wi-Fi"
        AegisAction.BluetoothOn, AegisAction.BluetoothOff, AegisAction.BluetoothToggle -> if (h) "ब्लूटूथ नहीं बदल सका" else "Couldn't toggle Bluetooth"
        AegisAction.MediaPlay, AegisAction.MediaPause, AegisAction.MediaTogglePlayPause, AegisAction.MediaNext, AegisAction.MediaPrevious, AegisAction.MediaStop -> if (h) "मीडिया नहीं चला सका" else "Couldn't control media"
        AegisAction.GoHome, AegisAction.GoBack, AegisAction.ShowRecents, AegisAction.ShowNotifications, AegisAction.LockScreen -> if (h) "नेविगेशन नहीं हो सका" else "Couldn't navigate"
        is AegisAction.SetDnd -> if (h) "साइलेंट मोड नहीं बदल सका" else "Couldn't change DND"
        is AegisAction.SetAutoRotation -> if (h) "रोटेशन नहीं बदल सका" else "Couldn't change rotation"
        is AegisAction.SetNightMode -> if (h) "डार्क मोड नहीं बदल सका" else "Couldn't change dark mode"
        is AegisAction.SetScreenTimeout -> if (h) "स्क्रीन टाइमआउट नहीं बदल सका" else "Couldn't change timeout"
        AegisAction.RequestAirplanePanel, AegisAction.RequestLocationPanel -> if (h) "सेटिंग नहीं खुल सकी" else "Couldn't open setting"
        is AegisAction.SystemDiagnostics -> if (h) "जाँच नहीं हो सकी" else "Diagnostics failed"
        is AegisAction.QueryPowerStatus -> if (h) "पावर की जानकारी नहीं मिली" else "Couldn't read power"
        else -> if (h) "कुछ नहीं हो सका" else "Something didn't work"
    }

    @Suppress("unused")
    private fun streamLabel(s: AudioStream, h: Boolean) = s.name
}
