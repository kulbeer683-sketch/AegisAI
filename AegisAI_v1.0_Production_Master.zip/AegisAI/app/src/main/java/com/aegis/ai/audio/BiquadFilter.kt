package com.aegis.ai.audio

import kotlin.math.cos
import kotlin.math.sin

class BiquadFilter private constructor(
    private val b0: Double,
    private val b1: Double,
    private val b2: Double,
    private val a1: Double,
    private val a2: Double
) {
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    fun process(input: Double): Double {
        val output = b0 * input + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = input; y2 = y1; y1 = output
        if (output.isNaN() || output.isInfinite()) { reset(); return 0.0 }
        return output
    }

    fun reset() {
        x1 = 0.0; x2 = 0.0; y1 = 0.0; y2 = 0.0
    }

    companion object {
        fun lowPass(sampleRate: Int, cutoffHz: Double, q: Double = AudioConfig.BANDPASS_Q): BiquadFilter {
            val w0 = 2.0 * Math.PI * cutoffHz / sampleRate.toDouble()
            val cosW0 = cos(w0); val sinW0 = sin(w0); val alpha = sinW0 / (2.0 * q)
            val a0 = 1.0 + alpha
            return BiquadFilter(
                ((1.0 - cosW0) / 2.0) / a0, (1.0 - cosW0) / a0,
                ((1.0 - cosW0) / 2.0) / a0, (-2.0 * cosW0) / a0, (1.0 - alpha) / a0
            )
        }

        fun highPass(sampleRate: Int, cutoffHz: Double, q: Double = AudioConfig.BANDPASS_Q): BiquadFilter {
            val w0 = 2.0 * Math.PI * cutoffHz / sampleRate.toDouble()
            val cosW0 = cos(w0); val sinW0 = sin(w0); val alpha = sinW0 / (2.0 * q)
            val a0 = 1.0 + alpha
            return BiquadFilter(
                ((1.0 + cosW0) / 2.0) / a0, (-(1.0 + cosW0)) / a0,
                ((1.0 + cosW0) / 2.0) / a0, (-2.0 * cosW0) / a0, (1.0 - alpha) / a0
            )
        }
    }
}
