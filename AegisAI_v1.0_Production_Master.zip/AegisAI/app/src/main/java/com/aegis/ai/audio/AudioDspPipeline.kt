package com.aegis.ai.audio

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean

class AudioDspPipeline(private val context: Context) {

    data class AudioFrame(
        val pcm: ShortArray,
        val vad: VoiceActivityDetector.VadResult,
        val timestampMs: Long
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is AudioFrame) return false
            return pcm.contentEquals(other.pcm) && vad == other.vad &&
                timestampMs == other.timestampMs
        }
        override fun hashCode(): Int {
            var r = pcm.contentHashCode()
            r = 31 * r + vad.hashCode()
            r = 31 * r + timestampMs.hashCode()
            return r
        }
    }

    enum class State { STOPPED, STARTING, RUNNING, STOPPING, ERROR }

    data class PipelineStats(
        val state: State,
        val sampleRate: Int,
        val frameSize: Int,
        val audioSessionId: Int,
        val noiseSuppressorActive: Boolean,
        val echoCancelerActive: Boolean,
        val agcActive: Boolean,
        val bluetoothScoActive: Boolean,
        val framesCaptured: Long,
        val framesWithSpeech: Long
    )

    private val audioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val highPass = BiquadFilter.highPass(AudioConfig.SAMPLE_RATE, AudioConfig.BANDPASS_LOW_HZ)
    private val lowPass = BiquadFilter.lowPass(AudioConfig.SAMPLE_RATE, AudioConfig.BANDPASS_HIGH_HZ)
    private val vad = VoiceActivityDetector(AudioConfig.SAMPLE_RATE, AudioConfig.FRAME_SIZE)

    private var audioRecord: AudioRecord? = null
    private var ns: NoiseSuppressor? = null
    private var aec: AcousticEchoCanceler? = null
    private var agc: AutomaticGainControl? = null

    private var audioSessionId: Int = AudioManager.ERROR
    private var scoRequestedByUs = false

    private val lifecycleMutex = Mutex()
    private val running = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var captureJob: Job? = null

    private val _frames = MutableSharedFlow<AudioFrame>(
        replay = 0, extraBufferCapacity = 64, onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val frames: SharedFlow<AudioFrame> = _frames.asSharedFlow()

    private val _stats = MutableStateFlow(
        PipelineStats(
            State.STOPPED, AudioConfig.SAMPLE_RATE, AudioConfig.FRAME_SIZE,
            AudioManager.ERROR, false, false, false, false, 0L, 0L
        )
    )
    val stats: StateFlow<PipelineStats> = _stats.asStateFlow()

    suspend fun start(preferBluetoothSco: Boolean = false): Boolean = lifecycleMutex.withLock {
        if (running.get()) return@withLock true
        if (!hasRecordPermission()) {
            Log.e(AudioConfig.TAG, "RECORD_AUDIO not granted")
            publish(State.ERROR); return@withLock false
        }
        publish(State.STARTING)

        if (preferBluetoothSco) requestSco()

        val record = buildRecord() ?: run {
            releaseSco(); publish(State.ERROR); return@withLock false
        }
        audioSessionId = record.audioSessionId
        attachEffects(audioSessionId)

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            releaseInternal(); publish(State.ERROR); return@withLock false
        }
        try {
            record.startRecording()
        } catch (t: Throwable) {
            Log.e(AudioConfig.TAG, "startRecording failed", t)
            releaseInternal(); publish(State.ERROR); return@withLock false
        }
        if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            releaseInternal(); publish(State.ERROR); return@withLock false
        }

        audioRecord = record
        highPass.reset(); lowPass.reset(); vad.reset()
        running.set(true)
        captureJob = scope.launch { captureLoop(record) }
        publish(State.RUNNING)
        Log.i(AudioConfig.TAG, "Pipeline RUNNING session=$audioSessionId")
        true
    }

    suspend fun stop() = lifecycleMutex.withLock {
        if (!running.get() && audioRecord == null) return@withLock
        publish(State.STOPPING)
        running.set(false)
        captureJob?.let { it.cancel(); runCatching { it.join() } }
        captureJob = null
        releaseInternal()
        releaseSco()
        publish(State.STOPPED)
        Log.i(AudioConfig.TAG, "Pipeline STOPPED")
    }

    fun shutdown() {
        running.set(false)
        captureJob?.cancel(); captureJob = null
        releaseInternal(); releaseSco()
        scope.coroutineContext[Job]?.cancel()
    }

    private suspend fun captureLoop(record: AudioRecord) {
        val raw = ShortArray(AudioConfig.FRAME_SIZE)
        val filtered = ShortArray(AudioConfig.FRAME_SIZE)
        var captured = 0L; var speech = 0L

        while (running.get() && scope.isActive) {
            val read = try { record.read(raw, 0, raw.size, AudioRecord.READ_BLOCKING) } catch (t: Throwable) {
                Log.e(AudioConfig.TAG, "read threw", t); -1
            }
            if (read <= 0) {
                if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION) {
                    running.set(false); publish(State.ERROR); return
                }
                continue
            }
            for (i in 0 until read) {
                val s = raw[i].toDouble()
                val hp = highPass.process(s)
                val lp = lowPass.process(hp)
                filtered[i] = lp.coerceIn(-32768.0, 32767.0).toInt().toShort()
            }
            val frame = if (read == AudioConfig.FRAME_SIZE) filtered else filtered.copyOf(read)
            val vadResult = vad.process(frame)
            captured++; if (vadResult.isSpeech) speech++
            _frames.tryEmit(AudioFrame(filtered.copyOf(read), vadResult, SystemClock.elapsedRealtime()))
            if (captured % 250L == 0L) {
                _stats.value = _stats.value.copy(framesCaptured = captured, framesWithSpeech = speech)
            }
        }
        _stats.value = _stats.value.copy(framesCaptured = captured, framesWithSpeech = speech)
    }

    @SuppressLint("MissingPermission")
    private fun buildRecord(): AudioRecord? {
        val minBuf = AudioRecord.getMinBufferSize(
            AudioConfig.SAMPLE_RATE, AudioConfig.CHANNEL_MASK, AudioConfig.ENCODING
        )
        if (minBuf <= 0) return null
        return try {
            AudioRecord.Builder()
                .setAudioSource(AudioConfig.AUDIO_SOURCE)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioConfig.ENCODING)
                        .setSampleRate(AudioConfig.SAMPLE_RATE)
                        .setChannelMask(AudioConfig.CHANNEL_MASK)
                        .build()
                )
                .setBufferSizeInBytes(AudioConfig.bufferSizeBytes(minBuf))
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .build()
        } catch (t: Throwable) { Log.e(AudioConfig.TAG, "AudioRecord build failed", t); null }
    }

    private fun attachEffects(sessionId: Int) {
        if (sessionId == AudioManager.ERROR) return
        ns = runCatching {
            if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sessionId)?.apply { enabled = true } else null
        }.getOrNull()
        aec = runCatching {
            if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sessionId)?.apply { enabled = true } else null
        }.getOrNull()
        agc = runCatching {
            if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sessionId)?.apply { enabled = true } else null
        }.getOrNull()
        _stats.value = _stats.value.copy(
            audioSessionId = sessionId,
            noiseSuppressorActive = ns != null,
            echoCancelerActive = aec != null,
            agcActive = agc != null
        )
    }

    private fun detachEffects() {
        runCatching { ns?.enabled = false; ns?.release() }; ns = null
        runCatching { aec?.enabled = false; aec?.release() }; aec = null
        runCatching { agc?.enabled = false; agc?.release() }; agc = null
    }

    private suspend fun requestSco() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) !=
            PackageManager.PERMISSION_GRANTED
        ) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val d = audioManager.availableCommunicationDevices
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                if (d != null) scoRequestedByUs = audioManager.setCommunicationDevice(d)
            } else {
                @Suppress("DEPRECATION") audioManager.startBluetoothSco()
                @Suppress("DEPRECATION") audioManager.isBluetoothScoOn = true
                scoRequestedByUs = true
                val deadline = SystemClock.elapsedRealtime() + 3_000L
                while (SystemClock.elapsedRealtime() < deadline) {
                    @Suppress("DEPRECATION") if (audioManager.isBluetoothScoOn) break
                    delay(50L)
                }
            }
        } catch (t: Throwable) { Log.w(AudioConfig.TAG, "SCO request failed", t) }
        _stats.value = _stats.value.copy(bluetoothScoActive = scoRequestedByUs)
    }

    private fun releaseSco() {
        if (!scoRequestedByUs) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) audioManager.clearCommunicationDevice()
            else { @Suppress("DEPRECATION") audioManager.stopBluetoothSco(); @Suppress("DEPRECATION") audioManager.isBluetoothScoOn = false }
        } catch (t: Throwable) { Log.w(AudioConfig.TAG, "SCO release failed", t) }
        finally { scoRequestedByUs = false; _stats.value = _stats.value.copy(bluetoothScoActive = false) }
    }

    private fun releaseInternal() {
        audioRecord?.let { r ->
            runCatching { if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) r.stop() }
            runCatching { r.release() }
        }
        audioRecord = null
        detachEffects()
        audioSessionId = AudioManager.ERROR
        _stats.value = _stats.value.copy(
            audioSessionId = AudioManager.ERROR,
            noiseSuppressorActive = false, echoCancelerActive = false, agcActive = false
        )
    }

    private fun publish(s: State) { _stats.value = _stats.value.copy(state = s) }

    private fun hasRecordPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
}
