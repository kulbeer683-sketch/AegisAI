package com.aegis.ai.call

internal object CallCommandParser {

    private val ACCEPT = setOf(
        "pick up", "pickup", "pick-up", "answer", "accept", "yes", "yeah", "yep", "ok", "okay", "sure",
        "uthao", "utha lo", "kholo", "haan", "han", "ha", "lo"
    )
    private val REJECT = setOf(
        "reject", "cut", "cut the call", "hang up", "hangup", "disconnect", "decline", "no", "nope", "nah",
        "kaat do", "kaato", "kaat", "nahi", "nahin", "na", "mat uthao"
    )
    private val ACCEPT_DEV = setOf("कॉल उठाओ", "उठाओ", "उठा लो", "हाँ", "हां", "हा", "लो", "कॉल लो", "जवाब दो")
    private val REJECT_DEV = setOf("काट दो", "काटो", "काट", "मत उठाओ", "नहीं", "ना", "कॉल काटो", "रिजेक्ट")

    fun parse(rawText: String): CallCommand? {
        val n = normalize(rawText)
        if (n.isEmpty()) return null
        if (matches(n, ACCEPT, ACCEPT_DEV)) return CallCommand.ACCEPT
        if (matches(n, REJECT, REJECT_DEV)) return CallCommand.REJECT
        return null
    }

    private fun matches(n: String, latin: Set<String>, dev: Set<String>): Boolean {
        if (n in latin || n in dev) return true
        for (p in latin) {
            if (p.length < 3) { if (stripFiller(n) == p) return true }
            else if (containsWholeWord(n, p)) return true
        }
        for (p in dev) if (n.contains(p)) return true
        return false
    }

    private fun stripFiller(t: String) = t.removePrefix("the ").removePrefix("a ").removePrefix("an ").trim()

    private fun containsWholeWord(h: String, needle: String): Boolean {
        var start = 0
        while (true) {
            val i = h.indexOf(needle, start); if (i < 0) return false
            val b = if (i == 0) null else h[i - 1]
            val ai = i + needle.length
            val a = if (ai >= h.length) null else h[ai]
            val bo = b == null || !b.isLetterOrDigit()
            val ao = a == null || !a.isLetterOrDigit()
            if (bo && ao) return true
            start = i + 1
        }
    }

    private fun normalize(t: String) = t.lowercase().replace(Regex("[\\p{Punct}&&[^\\u0900-\\u097F]]"), " ").replace(Regex("\\s+"), " ").trim()
}
