package com.aegis.ai.audio

import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

class VoiceActivityDetector(
    private val sampleRate: Int,
    private val frameSize: Int,
    private val thresholdDb: Double = 6.0,
    private val hangoverFrames: Int = 10,
    private val noiseAdaptDown: Double = 0.10,
    private val noiseAdaptUp: Double = 0.001,
    private val zcrCeiling: Double = 0.45
) {
    data class VadResult(
        val isSpeech: Boolean,
        val rmsDbfs: Double,
        val noiseFloorDbfs: Double,
        val zcr: Double,
        val snrDb: Double
    )

    private var noiseFloorRms: Double = 0.0
    private var initialized = false
    private var hangover = 0

    fun process(frame: ShortArray): VadResult {
        require(frame.size == frameSize)
        var sumSquares = 0.0
        var zc = 0
        var prevSign = frame[0] >= 0
        for (i in frame.indices) {
            val s = frame[i].toInt()
            val d = s.toDouble()
            sumSquares += d * d
            if (i > 0) {
                val sign = s >= 0
                if (sign != prevSign) zc++
                prevSign = sign
            }
        }
        val rms = sqrt(sumSquares / frameSize.toDouble())
        val zcr = zc.toDouble() / (frameSize - 1).toDouble()

        if (!initialized) {
            noiseFloorRms = rms.coerceAtLeast(MIN_RMS)
            initialized = true
        } else if (rms < noiseFloorRms) {
            noiseFloorRms = (1.0 - noiseAdaptDown) * noiseFloorRms + noiseAdaptDown * rms
        } else {
            noiseFloorRms = (1.0 - noiseAdaptUp) * noiseFloorRms + noiseAdaptUp * rms
        }
        noiseFloorRms = noiseFloorRms.coerceAtLeast(MIN_RMS)

        val thresh = noiseFloorRms * 10.0.pow(thresholdDb / 20.0)
        var speech = rms > thresh && zcr < zcrCeiling
        if (speech) hangover = hangoverFrames
        else if (hangover > 0) { hangover--; speech = true }

        val rmsDbfs = 20.0 * log10(rms / FULL_SCALE + EPS)
        val nfDbfs = 20.0 * log10(noiseFloorRms / FULL_SCALE + EPS)

        return VadResult(speech, rmsDbfs, nfDbfs, zcr, rmsDbfs - nfDbfs)
    }

    fun reset() {
        noiseFloorRms = 0.0
        initialized = false
        hangover = 0
    }

    private companion object {
        const val FULL_SCALE = 32768.0
        const val EPS = 1e-9
        const val MIN_RMS = 1.0
    }
}
