package com.aegis.ai.call

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import com.aegis.ai.audio.AudioRouteHelper
import com.aegis.ai.media.AudioFocusCoordinator
import com.aegis.ai.voice.NeuralVoiceProvider
import com.aegis.ai.voice.VoicePcmProcessor
import com.aegis.ai.voice.VoicePersonaEngine
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.UUID

class InEarNotificationManager(
    context: Context,
    private val audioFocus: AudioFocusCoordinator? = null,
    private val voicePersonaEngine: VoicePersonaEngine? = null,
    private val neuralVoiceProvider: NeuralVoiceProvider? = null
) : AutoCloseable {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val speakMutex = Mutex()
    private val audioTrackMutex = Mutex()
    private val readyDeferred = CompletableDeferred<Boolean>()

    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var ownsScoSession = false
    @Volatile private var currentUtterance: CompletableDeferred<Unit>? = null

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private val progressListener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {}
        override fun onDone(id: String?) { currentUtterance?.complete(Unit) }
        @Deprecated("Deprecated") override fun onError(id: String?) { currentUtterance?.completeExceptionally(IllegalStateException("TTS error")) }
        override fun onError(id: String?, code: Int) { currentUtterance?.completeExceptionally(IllegalStateException("TTS error $code")) }
    }

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.let { e ->
                    val r = e.setLanguage(Locale.getDefault())
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        e.setLanguage(Locale("en", "IN"))
                    }
                    e.setOnUtteranceProgressListener(progressListener)
                    readyDeferred.complete(true)
                } ?: readyDeferred.complete(false)
            } else readyDeferred.complete(false)
        }
    }

    fun hasHeadset(): Boolean = AudioRouteHelper.hasHeadsetConnected(audioManager)

    suspend fun announceIncomingCall(identity: String): Boolean = speak("Incoming call from $identity", priority = true)

    suspend fun speak(
        text: String,
        priority: Boolean = false,
        streamOverride: Int? = null,
        preferNeural: Boolean = false
    ): Boolean {
        if (text.isBlank()) return true
        _speaking.value = true
        try {
            if (preferNeural && neuralVoiceProvider != null && streamOverride == null) {
                if (tryNeuralPath(text)) return true
            }
            return speakInternal(text, priority, streamOverride)
        } finally { _speaking.value = false }
    }

    fun stop() {
        runCatching { tts?.stop() }
        currentUtterance?.completeExceptionally(IllegalStateException("stopped"))
        currentUtterance = null
    }

    override fun close() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
        releaseScoIfOwned()
    }

    private suspend fun speakInternal(text: String, priority: Boolean, streamOverride: Int?): Boolean = speakMutex.withLock {
        val ready = try { withTimeout(TTS_READY_TIMEOUT_MS) { readyDeferred.await() } } catch (_: TimeoutCancellationException) { false }
        if (!ready) return@withLock false
        val engine = tts ?: return@withLock false

        try { voicePersonaEngine?.applyTo(engine, text) } catch (_: Throwable) {}

        val ducked = audioFocus?.duck() == true
        try {
            val headset = hasHeadset()
            val stream = streamOverride ?: if (headset) AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_RING
            val scoAcquired = if (headset && streamOverride == null) tryAcquireSco() else false

            if (!headset && streamOverride == null) {
                runCatching { if (audioManager.mode != AudioManager.MODE_NORMAL) audioManager.mode = AudioManager.MODE_NORMAL }
            }

            try {
                val done = CompletableDeferred<Unit>()
                currentUtterance = done
                val params = Bundle().apply {
                    putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, stream)
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
                }
                val id = UUID.randomUUID().toString()
                val mode = if (priority) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val r = engine.speak(text, mode, params, id)
                if (r != TextToSpeech.SUCCESS) return@withLock false
                try {
                    withTimeout(SPEAK_TIMEOUT_MS) { done.await() }
                    true
                } catch (_: Throwable) { false }
                finally { currentUtterance = null }
            } finally { if (scoAcquired) releaseScoIfOwned() }
        } finally { if (ducked) runCatching { audioFocus?.release() } }
    }

    private suspend fun tryNeuralPath(text: String): Boolean {
        val provider = neuralVoiceProvider ?: return false
        val tag = if (text.any { it.code in 0x0900..0x097F }) "hi-IN" else "en-IN"
        val audio = try { provider.synthesize(text, tag) } catch (t: Throwable) { null } ?: return false
        if (audio.pcm.isEmpty()) return false

        val ducked = audioFocus?.duck() == true
        val headset = hasHeadset()
        val sco = if (headset) tryAcquireSco() else false
        try {
            val processed = VoicePcmProcessor.applyGainAndLimit(audio.pcm)
            return playPcm(processed, audio.sampleRate, audio.channelCount)
        } finally {
            if (sco) releaseScoIfOwned()
            if (ducked) runCatching { audioFocus?.release() }
        }
    }

    private suspend fun playPcm(pcm: ShortArray, sampleRate: Int, channelCount: Int): Boolean = audioTrackMutex.withLock {
        if (pcm.isEmpty()) return@withLock false
        val mask = if (channelCount >= 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val minBuf = runCatching { AudioTrack.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT) }.getOrDefault(-1)
        if (minBuf <= 0) return@withLock false

        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(mask).build())
                .setBufferSizeInBytes(maxOf(minBuf, pcm.size * 2))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        } catch (_: Throwable) { return@withLock false }

        try {
            val frames = pcm.size / channelCount.coerceAtLeast(1)
            val done = CompletableDeferred<Unit>()
            runCatching {
                track.setNotificationMarkerPosition(frames)
                track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                    override fun onMarkerReached(t: AudioTrack?) { if (!done.isCompleted) done.complete(Unit) }
                    override fun onPeriodicNotification(t: AudioTrack?) {}
                }, Handler(Looper.getMainLooper()))
            }
            track.play()
            var off = 0
            while (off < pcm.size) {
                val c = minOf(2048, pcm.size - off)
                val w = runCatching { track.write(pcm, off, c, AudioTrack.WRITE_BLOCKING) }.getOrDefault(-1)
                if (w <= 0) break
                off += w
            }
            val dur = (frames.toLong() * 1000L) / sampleRate
            withTimeoutOrNull(dur + 500L) { done.await() }
            delay(80L)
            true
        } finally {
            runCatching { track.stop(); track.flush(); track.release() }
        }
    }

    private fun tryAcquireSco(): Boolean {
        if (isScoActive()) return false
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val d = audioManager.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                if (d == null) { audioManager.mode = AudioManager.MODE_IN_COMMUNICATION; return false }
                if (audioManager.setCommunicationDevice(d)) { audioManager.mode = AudioManager.MODE_IN_COMMUNICATION; ownsScoSession = true; true }
                else false
            } else {
                @Suppress("DEPRECATION") audioManager.startBluetoothSco()
                @Suppress("DEPRECATION") audioManager.isBluetoothScoOn = true
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                ownsScoSession = true; true
            }
        } catch (_: Throwable) { false }
    }

    private fun releaseScoIfOwned() {
        if (!ownsScoSession) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) audioManager.clearCommunicationDevice()
            else { @Suppress("DEPRECATION") audioManager.stopBluetoothSco(); @Suppress("DEPRECATION") audioManager.isBluetoothScoOn = false }
        } catch (_: Throwable) {} finally { ownsScoSession = false }
    }

    private fun isScoActive(): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) audioManager.communicationDevice?.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
        else { @Suppress("DEPRECATION") audioManager.isBluetoothScoOn }
    } catch (_: Throwable) { false }

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val TTS_READY_TIMEOUT_MS = 2_000L
        private const val SPEAK_TIMEOUT_MS = 6_000L
    }
}
