package com.aegis.ai.decision

import android.os.SystemClock
import android.util.Log
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

class AutonomousDecisionMatrix(
    private val scope: CoroutineScope,
    private val executor: Executor
) {

    fun interface Executor {
        suspend fun execute(request: DecisionRequest, capability: ExecutionCapability): Boolean
    }

    private val mutex = Mutex()
    private var active: Holder? = null
    private val queue = ArrayDeque<DecisionRequest>()

    private val _outcomes = MutableSharedFlow<DecisionOutcome>(extraBufferCapacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val outcomes: SharedFlow<DecisionOutcome> = _outcomes.asSharedFlow()

    private val _preemptions = MutableSharedFlow<PreemptionEvent>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val preemptions: SharedFlow<PreemptionEvent> = _preemptions.asSharedFlow()

    private val admitted = AtomicLong(0L); private val rejected = AtomicLong(0L); private val preemptions = AtomicLong(0L)

    suspend fun submit(
        origin: DecisionOrigin, match: IntentMatch?, label: String,
        capability: ExecutionCapability, correlationId: String? = null,
        priorityOverride: DecisionPriority? = null
    ): DecisionOutcome = mutex.withLock {
        val pr = priorityOverride ?: DecisionPriority.forOrigin(origin)
        val req = DecisionRequest(UUID.randomUUID().toString(), origin, pr, match, label, correlationId)
        val h = active

        if (h == null) { launchHolder(req, capability); admitted.incrementAndGet(); return@withLock DecisionOutcome(req, true, capability, "no-active", false) }

        if (pr.canPreempt(h.priority)) {
            cancelHolder(h, "preempted-by-$pr"); preemptions.incrementAndGet()
            _preemptions.tryEmit(PreemptionEvent(h.request, pr, label))
            launchHolder(req, capability); admitted.incrementAndGet()
            return@withLock DecisionOutcome(req, true, capability, "preempted-$pr", true)
        }

        if (pr == DecisionPriority.P0_CRITICAL) {
            cancelHolder(h, "p0-collision"); launchHolder(req, capability); admitted.incrementAndGet()
            return@withLock DecisionOutcome(req, true, capability, "p0-collision", true)
        }

        if (queue.size >= MAX_QUEUE) queue.removeLastOrNull()?.let { rejected.incrementAndGet() }
        queue.addLast(req)
        return@withLock DecisionOutcome(req, false, capability, "queued", false)
    }

    fun queueDepth(): Int = queue.size
    fun activeLabel(): String? = active?.label
    fun activePriority(): DecisionPriority? = active?.priority

    fun counters(): Counters = Counters(admitted.get(), rejected.get(), preemptions.get(), queue.size, activeLabel(), activePriority())

    suspend fun shutdown() = mutex.withLock { active?.let { cancelHolder(it, "shutdown") }; queue.clear() }

    data class Counters(val admitted: Long, val rejected: Long, val preemptions: Long, val queueDepth: Int, val activeLabel: String?, val activePriority: DecisionPriority?)

    private data class Holder(val request: DecisionRequest, val priority: DecisionPriority, val label: String, val job: Job, val startedAtMs: Long)

    private fun launchHolder(req: DecisionRequest, cap: ExecutionCapability) {
        val job = scope.launch(Dispatchers.Default) {
            try { executor.execute(req, cap) }
            catch (ce: CancellationException) { throw ce }
            catch (_: Throwable) {}
        }
        active = Holder(req, req.priority, req.label, job, SystemClock.elapsedRealtime())
        scope.launch {
            runCatching { job.join() }
            mutex.withLock { if (active?.job === job) { active = null; promoteNextLocked() } }
        }
    }

    private fun cancelHolder(h: Holder, reason: String) {
        runCatching { h.job.cancel(CancellationException(reason)) }
        if (active?.job === h.job) active = null
    }

    private suspend fun promoteNextLocked() {
        val next = queue.removeFirstOrNull() ?: return
        scope.launch { submit(next.origin, next.match, next.label, ExecutionCapability.FAST_PATH, next.correlationId, next.priority) }
    }

    private companion object {
        const val TAG = AudioConfig.TAG
        const val MAX_QUEUE = 8
    }
}
