package com.aegis.ai.vitals

object VitalsResponder {

    fun respond(query: VitalsQuery, snapshot: VitalsSnapshot): String = when (query) {
        VitalsQuery.BATTERY_LEVEL -> "बैटरी ${snapshot.batteryPercent}% है"
        VitalsQuery.BATTERY_STATUS -> {
            val state = when {
                snapshot.batteryStatus == BatteryStatus.FULL -> "फुल चार्ज"
                snapshot.batteryStatus == BatteryStatus.CHARGING -> "चार्जिंग पर"
                snapshot.batteryPlugged == Plugged.AC -> "AC पर चार्जिंग"
                snapshot.batteryPlugged == Plugged.USB -> "USB पर चार्जिंग"
                snapshot.batteryPlugged == Plugged.WIRELESS -> "वायरलेस चार्जिंग"
                else -> "चार्जिंग पर नहीं"
            }
            "बैटरी ${snapshot.batteryPercent}% है, $state"
        }
        VitalsQuery.BATTERY_TEMP -> "बैटरी का तापमान ${"%.1f".format(snapshot.batteryTempC)} डिग्री है"
        VitalsQuery.THERMAL_STATUS -> {
            val temp = if (snapshot.batteryTempC.isNaN()) null else snapshot.batteryTempC
            val tempText = temp?.let { "तापमान ${"%.1f".format(it)} डिग्री, " } ?: ""
            val status = when (snapshot.thermalStatus) {
                ThermalStatus.NONE -> "सामान्य"
                ThermalStatus.LIGHT -> "हल्की गर्मी"
                ThermalStatus.MODERATE -> "मध्यम गर्मी"
                ThermalStatus.SEVERE -> "अधिक गर्मी"
                ThermalStatus.CRITICAL -> "गंभीर गर्मी"
                ThermalStatus.EMERGENCY -> "आपातकालीन गर्मी"
                ThermalStatus.SHUTDOWN -> "डिवाइस बंद होने वाला है"
                ThermalStatus.UNKNOWN -> "जानकारी उपलब्ध नहीं"
            }
            "$tempText$status"
        }
        VitalsQuery.NETWORK_STATUS -> {
            val type = when (snapshot.networkType) {
                NetworkType.WIFI -> "वाईफाई कनेक्टेड"
                NetworkType.ETHERNET -> "ईथरनेट कनेक्टेड"
                NetworkType.NR_5G -> "5G नेटवर्क"
                NetworkType.LTE -> "4G LTE नेटवर्क"
                NetworkType.HSPA -> "HSPA नेटवर्क"
                NetworkType.UMTS -> "3G नेटवर्क"
                NetworkType.GSM -> "2G नेटवर्क"
                NetworkType.UNKNOWN -> "नेटवर्क अज्ञात"
                NetworkType.NONE -> "नेटवर्क बंद है"
            }
            val sig = if (snapshot.networkType == NetworkType.WIFI || snapshot.networkType == NetworkType.ETHERNET) "" else ", सिग्नल ${snapshot.signalLevel} बार"
            "$type$sig"
        }
        VitalsQuery.FULL_REPORT -> buildString {
            append("बैटरी ").append(snapshot.batteryPercent).append("%, ")
            append(if (snapshot.batteryStatus == BatteryStatus.FULL) "फुल चार्ज, " else if (snapshot.isCharging) "चार्जिंग, " else "चार्जिंग पर नहीं, ")
            append("तापमान ").append("%.0f".format(snapshot.batteryTempC)).append(" डिग्री, ")
            append(when (snapshot.networkType) {
                NetworkType.WIFI -> "वाईफाई"
                NetworkType.ETHERNET -> "ईथरनेट"
                NetworkType.NR_5G -> "5G"
                NetworkType.LTE -> "LTE"
                NetworkType.HSPA -> "HSPA"
                NetworkType.UMTS -> "3G"
                NetworkType.GSM -> "2G"
                NetworkType.UNKNOWN -> "नेटवर्क अज्ञात"
                NetworkType.NONE -> "नेटवर्क बंद"
            })
        }
    }
}
