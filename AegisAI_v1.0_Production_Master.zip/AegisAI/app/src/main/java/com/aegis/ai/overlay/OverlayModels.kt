package com.aegis.ai.overlay

enum class OverlayMode { HIDDEN, LISTENING, SPEAKING, ERROR }

object OverlayConfig {
    const val WIDTH_DP = 100
    const val HEIGHT_DP = 44
    const val DEFAULT_X_DP = 12
    const val DEFAULT_Y_DP = 96
    const val ACTIVE_ALPHA = 0.96f
    const val HIDDEN_ALPHA = 0f
    const val FADE_MS = 180L
    const val DISMISS_VELOCITY = 900f
    const val ERROR_DURATION_MS = 700L
}
