package com.aegis.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aegis.ai.accessibility.UiNodeResolver
import com.aegis.ai.accessibility.UiNodeResolver.recycleSafe
import com.aegis.ai.audio.AudioConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.coroutines.resume

class AegisAccessibilityService : AccessibilityService() {

    @Volatile var foregroundPackage: String? = null; private set
    @Volatile var foregroundWindowTitle: String? = null; private set

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
        Log.i(TAG, "AegisAccessibilityService connected")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val p = e.packageName?.toString()
                val t = e.text?.joinToString(" ")?.takeIf { it.isNotBlank() } ?: e.contentDescription?.toString()
                if (p != null && p != foregroundPackage) foregroundPackage = p
                if (t != null) foregroundWindowTitle = t
            }
        }
    }

    override fun onInterrupt() { Log.w(TAG, "interrupted") }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    suspend fun goHome() = performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME, "HOME")
    suspend fun goBack() = performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK, "BACK")
    suspend fun showRecents() = performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS, "RECENTS")
    suspend fun openNotifications() = performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "NOTIFICATIONS")
    suspend fun performLockScreen(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
        return performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "LOCK_SCREEN")
    }

    suspend fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatchPath(p, 50L, "tap($x,$y)")
    }

    suspend fun longPress(x: Float, y: Float, durationMs: Long = 600L): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatchPath(p, durationMs.coerceIn(500L, 3000L), "longPress($x,$y)")
    }

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long = 280L): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatchPath(p, dur.coerceIn(50L, 3000L), "swipe")
    }

    suspend fun swipeUp() = verticalSwipe(0.75f, 0.25f)
    suspend fun swipeDown() = verticalSwipe(0.25f, 0.75f)
    suspend fun swipeLeft() = horizontalSwipe(0.80f, 0.20f)
    suspend fun swipeRight() = horizontalSwipe(0.20f, 0.80f)

    private suspend fun verticalSwipe(s: Float, e: Float): Boolean {
        val b = screenBounds()
        val x = b.exactCenterX()
        val y1 = b.top + b.height() * s
        val y2 = b.top + b.height() * e
        return swipe(x, y1, x, y2)
    }

    private suspend fun horizontalSwipe(s: Float, e: Float): Boolean {
        val b = screenBounds()
        val y = b.exactCenterY()
        val x1 = b.left + b.width() * s
        val x2 = b.left + b.width() * e
        return swipe(x1, y, x2, y)
    }

    suspend fun findNode(predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? =
        withContext(Dispatchers.Main.immediate) {
            val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext null
            try { UiNodeResolver.findByPredicate(root, predicate) } finally { root.recycleSafe() }
        }

    suspend fun awaitNode(
        timeoutMs: Long,
        pollIntervalMs: Long = 100L,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? = withContext(Dispatchers.Main.immediate) {
        withTimeoutOrNull(timeoutMs) {
            while (isActive) {
                val root = runCatching { rootInActiveWindow }.getOrNull()
                if (root != null) {
                    val m = try { UiNodeResolver.findByPredicate(root, predicate) } catch (_: Throwable) { null }
                    finally { root.recycleSafe() }
                    if (m != null) return@withTimeoutOrNull m
                }
                delay(pollIntervalMs.coerceAtLeast(40L))
            }
            null
        }
    }

    suspend fun clickNode(node: AccessibilityNodeInfo?): Boolean = withContext(Dispatchers.Main.immediate) {
        val n = node ?: return@withContext false
        try {
            val t = UiNodeResolver.findClickableAncestor(n) ?: n
            t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (_: Throwable) { false }
    }

    suspend fun clickByText(text: String): Boolean = withContext(Dispatchers.Main.immediate) {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext false
        try { UiNodeResolver.clickByText(root, text) } finally { root.recycleSafe() }
    }

    suspend fun setTextOnFocused(text: String): Boolean = withContext(Dispatchers.Main.immediate) {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext false
        try { UiNodeResolver.setTextOnFocused(root, text) } finally { root.recycleSafe() }
    }

    suspend fun typeIntoField(fieldMatch: String, content: String): Boolean = withContext(Dispatchers.Main.immediate) {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext false
        try { UiNodeResolver.typeIntoField(root, fieldMatch, content) } finally { root.recycleSafe() }
    }

    suspend fun snapshotText(maxChars: Int = 2000): String = withContext(Dispatchers.Main.immediate) {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return@withContext ""
        try { UiNodeResolver.extractTextSnapshot(root, maxChars) } finally { root.recycleSafe() }
    }

    fun currentPackage(): String? = foregroundPackage
    fun currentWindowTitle(): String? = foregroundWindowTitle

    private suspend fun performGlobal(action: Int, label: String): Boolean = withContext(Dispatchers.Main.immediate) {
        runCatching { performGlobalAction(action) }.getOrDefault(false)
    }

    private suspend fun dispatchPath(path: Path, durationMs: Long, label: String): Boolean =
        withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { cont ->
                val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
                val desc = GestureDescription.Builder().addStroke(stroke).build()
                val cb = object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                    override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
                }
                val ok = runCatching { dispatchGesture(desc, cb, null) }.getOrDefault(false)
                if (!ok && cont.isActive) cont.resume(false)
            }
        }

    private fun screenBounds(): Rect = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val wm = getSystemService(WindowManager::class.java)
            wm.currentWindowMetrics.bounds
        } else {
            val dm = resources.displayMetrics
            Rect(0, 0, dm.widthPixels, dm.heightPixels)
        }
    } catch (_: Throwable) {
        val dm = resources.displayMetrics
        Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    companion object {
        private const val TAG = AudioConfig.TAG
        @Volatile private var instance: AegisAccessibilityService? = null
        fun get(): AegisAccessibilityService? = instance
        fun isConnected(): Boolean = instance != null
    }
}
