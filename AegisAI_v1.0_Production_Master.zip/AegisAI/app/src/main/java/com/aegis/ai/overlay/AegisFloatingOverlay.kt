package com.aegis.ai.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.view.WindowManager
import com.aegis.ai.audio.AudioConfig
import kotlin.math.abs

class AegisFloatingOverlay(context: Context) {

    private val appContext = context.applicationContext
    private val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var view: WaveformVisualizerView? = null
    private var params: WindowManager.LayoutParams? = null
    private var attached = false

    @Volatile private var dismissed = false
    private val vt: VelocityTracker = VelocityTracker.obtain()
    private val minFling = ViewConfiguration.get(appContext).scaledMinimumFlingVelocity

    fun isAttached(): Boolean = attached
    fun hasPermission(): Boolean = runCatching { Settings.canDrawOverlays(appContext) }.getOrDefault(false)

    fun attach(): Boolean {
        if (attached) return true
        if (dismissed) return false
        if (!hasPermission()) return false
        return try {
            val p = buildParams()
            val v = WaveformVisualizerView(appContext).apply {
                alpha = OverlayConfig.HIDDEN_ALPHA
                setOnTouchListener(makeTouch())
            }
            wm.addView(v, p); view = v; params = p; attached = true
            true
        } catch (t: Throwable) { attached = false; view = null; params = null; false }
    }

    fun detach() {
        if (!attached) return
        val v = view
        try { if (v != null) wm.removeViewImmediate(v) } catch (_: Throwable) {}
        finally { view = null; params = null; attached = false; runCatching { vt.recycle() } }
    }

    fun resetDismissal() { dismissed = false }

    fun setMode(mode: OverlayMode) {
        val v = view ?: return
        if (v.mode == mode) return
        v.mode = mode
        val a = if (mode == OverlayMode.HIDDEN) OverlayConfig.HIDDEN_ALPHA else OverlayConfig.ACTIVE_ALPHA
        v.animate().alpha(a).setDuration(OverlayConfig.FADE_MS).start()
    }

    fun setListeningAmplitude(l: Float) { view?.setListeningAmplitude(l) }
    fun setSpeakingAmplitude(l: Float) { view?.setSpeakingAmplitude(l) }
    fun setSpeakingActive(a: Boolean) { view?.setSpeakingActive(a) }

    fun suspendForPower() {
        val v = view ?: return
        v.mode = OverlayMode.HIDDEN
        v.alpha = OverlayConfig.HIDDEN_ALPHA
    }

    fun resumeFromPower() {
        view?.alpha = OverlayConfig.ACTIVE_ALPHA
    }

    private fun buildParams(): WindowManager.LayoutParams {
        val d = appContext.resources.displayMetrics
        return WindowManager.LayoutParams(
            (OverlayConfig.WIDTH_DP * d.density).toInt(),
            (OverlayConfig.HEIGHT_DP * d.density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (OverlayConfig.DEFAULT_X_DP * d.density).toInt()
            y = (OverlayConfig.DEFAULT_Y_DP * d.density).toInt()
        }
    }

    private fun makeTouch(): View.OnTouchListener {
        var initX = 0; var initY = 0; var downX = 0f; var downY = 0f
        return View.OnTouchListener { _, e ->
            val p = params ?: return@OnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { initX = p.x; initY = p.y; downX = e.rawX; downY = e.rawY; vt.clear(); vt.addMovement(e); true }
                MotionEvent.ACTION_MOVE -> {
                    vt.addMovement(e)
                    p.x = initX + (e.rawX - downX).toInt()
                    p.y = initY + (e.rawY - downY).toInt()
                    runCatching { wm.updateViewLayout(view, p) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt.addMovement(e); vt.computeCurrentVelocity(1000, minFling * 4f)
                    val vx = vt.xVelocity; val vy = vt.yVelocity
                    if (abs(vx) > OverlayConfig.DISMISS_VELOCITY && abs(vx) > abs(vy) * 1.4f) {
                        dismissed = true; setMode(OverlayMode.HIDDEN)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private companion object { const val TAG = AudioConfig.TAG }
}
