package com.aegis.ai.voice

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.aegis.ai.audio.AudioConfig

class VoicePersonaPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getPitch(): Float = prefs.getFloat(KEY_PITCH, DEFAULT_PITCH).coerceIn(MIN_PITCH, MAX_PITCH)
    fun getRate(): Float = prefs.getFloat(KEY_RATE, DEFAULT_RATE).coerceIn(MIN_RATE, MAX_RATE)

    fun setPitch(v: Float) { prefs.edit().putFloat(KEY_PITCH, v.coerceIn(MIN_PITCH, MAX_PITCH)).apply() }
    fun setRate(v: Float) { prefs.edit().putFloat(KEY_RATE, v.coerceIn(MIN_RATE, MAX_RATE)).apply() }

    fun adjustPitch(delta: Float): Float {
        val n = (getPitch() + delta).coerceIn(MIN_PITCH, MAX_PITCH)
        prefs.edit().putFloat(KEY_PITCH, n).apply(); return n
    }
    fun adjustRate(delta: Float): Float {
        val n = (getRate() + delta).coerceIn(MIN_RATE, MAX_RATE)
        prefs.edit().putFloat(KEY_RATE, n).apply(); return n
    }

    fun getPreferredVoiceName(tag: String): String? = prefs.getString(voiceKey(tag), null)
    fun setPreferredVoiceName(tag: String, name: String?) {
        prefs.edit().apply {
            if (name.isNullOrBlank()) remove(voiceKey(tag)) else putString(voiceKey(tag), name)
        }.apply()
    }

    fun resetPitchAndRate() { prefs.edit().putFloat(KEY_PITCH, DEFAULT_PITCH).putFloat(KEY_RATE, DEFAULT_RATE).apply() }
    fun clearAll() { prefs.edit().clear().apply() }

    private fun voiceKey(tag: String) = "voice_name_${tag.replace('-', '_').lowercase()}"

    companion object {
        private const val TAG = AudioConfig.TAG
        private const val FILE = "aegis_voice_persona"
        private const val KEY_PITCH = "pitch_multiplier"
        private const val KEY_RATE = "rate_multiplier"
        const val DEFAULT_PITCH = 0.88f
        const val DEFAULT_RATE = 1.04f
        const val MIN_PITCH = 0.55f
        const val MAX_PITCH = 1.45f
        const val MIN_RATE = 0.70f
        const val MAX_RATE = 1.50f
        const val PITCH_STEP = 0.04f
        const val RATE_STEP = 0.05f
    }
}
